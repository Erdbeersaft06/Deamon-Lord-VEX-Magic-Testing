import json, base64, io, math, sys
from PIL import Image
S = 0.5   # Modellskalierung (bb-Pixel -> Modellpixel)
SRC = '/tmp/work/v2/Daemonenlord_Episch.bbmodel'
d = json.load(open(SRC))
els = {e['uuid']: e for e in d['elements']}
texs = []
for t in d['textures']:
    b = base64.b64decode(t['source'].split(',', 1)[1])
    texs.append(Image.open(io.BytesIO(b)).convert('RGBA'))
def find(o, n):
    for x in o:
        if isinstance(x, dict):
            if x['name'] == n: return x
            r = find(x['children'], n)
            if r: return r
def cubes_of(g):
    for c in g['children']:
        if isinstance(c, str): yield els[c]
        elif not c['name'].startswith('fluegel_'): yield from cubes_of(c)
def r3(v): return round(v, 3)

# ---------- Atlas ----------
regions = {}   # key -> (img, w, h)
def swatch(face):
    if not face or face.get('texture') is None: return None
    u1, v1, u2, v2 = face['uv']
    t = face['texture']
    return (t, int(min(u1,u2)), int(min(v1,v2)), int(max(u1,u2)), int(max(v1,v2)))
def region_key(c, dims):
    f = c['faces']
    sw = {k: swatch(f.get(k)) for k in ('north','east','south','west','up','down')}
    first = next((v for v in sw.values() if v), None)
    if first is None: return None
    for k in sw:
        if sw[k] is None: sw[k] = first
    return (dims, tuple(sw[k] for k in ('north','east','south','west','up','down')))
def paint_region(key):
    (w, h, dd), sws = key
    W = math.ceil(2*(dd+w)) + 1; H = math.ceil(dd+h) + 1
    im = Image.new('RGBA', (W, H), (0,0,0,0))
    north, east, south, west, up, down = sws
    # Layout (Part-Raum, Flaeche -> Region):  down[u+d,v] up[u+d+w,v] west[u,v+d] north[u+d,v+d] east[u+d+w,v+d] south[u+2d+w,v+d]
    # bb east -> Part WEST (x gespiegelt), bb west -> Part EAST
    lay = [(down, dd, 0, w, dd), (up, dd+w, 0, w, dd), (east, 0, dd, dd, h), (north, dd, dd, w, h),
           (west, dd+w, dd, dd, h), (south, 2*dd+w, dd, w, h)]
    for sw, x, y, ww, hh in lay:
        t, a, b, c2, d2 = sw
        sub = texs[t].crop((a, b, c2, d2)).convert('RGBA')
        x0, y0 = int(math.floor(x)), int(math.floor(y))
        x1, y1 = max(x0+1, int(math.ceil(x+ww))), max(y0+1, int(math.ceil(y+hh)))
        sub = sub.resize((x1-x0, y1-y0), Image.BOX if (x1-x0) < 16 else Image.NEAREST)
        px = sub.load()
        for yy in range(sub.height):
            for xx in range(sub.width):
                r, g, bl, al = px[xx, yy]
                if al < 255:  # Glow-Flaechen: opak, heller
                    k = al/255
                    r, g, bl = min(255, int(r*0.6+160*k)), min(255, int(g*0.6+130*k)), min(255, int(bl*0.6+60*k))
                px[xx, yy] = (r, g, bl, 255)
        im.paste(sub, (x0, y0))
    return im


class Node:
    def __init__(s, name, origin, rot=None):
        s.name, s.origin, s.rot, s.cubes, s.kids = name, origin, rot or [0,0,0], [], []
def tree(grp, name=None, pivot=None, skip_rot=False):
    n = Node(name, pivot if pivot else grp['origin'], None if skip_rot else grp.get('rotation'))
    for c in grp['children']:
        if isinstance(c, str): n.cubes.append(els[c])
        else:
            k = tree(c)
            n.kids.append(k)
    return n
def merge(name, groups, pivot):
    n = Node(name, pivot)
    for g in groups:
        k = tree(find(d['outliner'], g)); k.name = None
        n.kids.append(k)
    return n
def collect(n):
    for c in n.cubes: yield c
    for k in n.kids: yield from collect(k)

def build(nodes, root_name, out_json, out_png, AW=1024):
    keys = {}
    for n in nodes:
        for c in collect(n):
            w, h, dd = [r3(abs(c['to'][i]-c['from'][i])*S) for i in (0,1,2)]
            c['_dims'] = (w, h, dd)
            c['_key'] = region_key(c, (w, h, dd))
            if c['_key']: keys[c['_key']] = None
    items = sorted(keys, key=lambda k: -(math.ceil(k[0][2]+k[0][1])+1))
    x = y = rowh = 0; pos = {}; imgs = {}
    for k in items:
        im = paint_region(k)
        if x + im.width > AW: x, y, rowh = 0, y+rowh, 0
        pos[k] = (x, y); imgs[k] = im
        x += im.width; rowh = max(rowh, im.height)
    AH = y + rowh; H2 = 1
    while H2 < AH: H2 *= 2
    atlas = Image.new('RGBA', (AW, H2), (0,0,0,0))
    for k, im in imgs.items(): atlas.paste(im, pos[k])
    import os; os.makedirs(os.path.dirname(out_png), exist_ok=True); os.makedirs(os.path.dirname(out_json), exist_ok=True)
    atlas.save(out_png, optimize=True)
    def emit(n, parent_origin, top=False):
        o = n.origin
        node = {}
        if n.name: node['n'] = n.name
        node['p'] = [0,0,0] if top else [r3(-(o[0]-parent_origin[0])*S), r3(-(o[1]-parent_origin[1])*S), r3((o[2]-parent_origin[2])*S)]
        if any(abs(a) > 1e-4 for a in n.rot):
            node['r'] = [r3(math.radians(-n.rot[0])), r3(math.radians(-n.rot[1])), r3(math.radians(n.rot[2]))]
        cl = []; kids = []
        for c in n.cubes:
            if not c['_key']: continue
            u, v = pos[c['_key']]; w, h, dd = c['_dims']
            rot = c.get('rotation') or [0,0,0]
            if any(abs(a) > 1e-4 for a in rot):
                co = c['origin']
                kids.append({'p': [r3(-(co[0]-o[0])*S), r3(-(co[1]-o[1])*S), r3((co[2]-o[2])*S)],
                    'r': [r3(math.radians(-rot[0])), r3(math.radians(-rot[1])), r3(math.radians(rot[2]))],
                    'c': [[u, v, r3(-(c['to'][0]-co[0])*S), r3(-(c['to'][1]-co[1])*S), r3((c['from'][2]-co[2])*S), w, h, dd]]})
            else:
                cl.append([u, v, r3(-(c['to'][0]-o[0])*S), r3(-(c['to'][1]-o[1])*S), r3((c['from'][2]-o[2])*S), w, h, dd])
        if cl: node['c'] = cl
        for k in n.kids: kids.append(emit(k, o))
        if kids: node['k'] = kids
        return node
    root = {'n': root_name, 'p': [0, 24, 0], 'k': [emit(n, [0,0,0], top=True) for n in nodes]}
    json.dump({'tex': [AW, H2], 'root': root}, open(out_json, 'w'), separators=(',', ':'))
    print(out_json, 'regions', len(items), 'atlas', AW, H2, 'cubes', sum(1 for n in nodes for _ in collect(n)), file=sys.stderr)

BASE = '/tmp/mod/src/client/resources/assets/daemonenlord/'
# --- Boss ---
def boss_tree(name, g):
    n = tree(find(d['outliner'], g), name=name, pivot=[0,0,0], skip_rot=True)
    for k in n.kids:
        if k.name is None and k.origin != [0,0,0] and False: pass
    return n
body = tree(find(d['outliner'], 'boss_koerper'), name='body', pivot=[0,0,0])
# Fluegel benennen, restliche Untergruppen von body bleiben unbenannt (eindeutige Namen automatisch)
for k in body.kids:
    k.name = 'wing_l' if k.origin[0] < 0 else 'wing_r'
halo = merge('halo', ['halo_ring','halo_strahlen','halo_innen'], [0,0,0])
build([body, halo], 'all', BASE+'boss_model.json', BASE+'textures/entity/daemonenlord.png')
# --- FX ---
fx = [merge('ring', ['welle_gold','welle_weiss'], [0,0,0]),
      merge('seal', ['siegel_zentrum','siegel_innen','siegel_oktagramm','siegel_runen','siegel_mitte','siegel_dunkel','siegel_aussen'], [0,0,0]),
      merge('blade', ['klinge_0'], [190,210,0]),
      merge('pillar', ['strahl_saeulen','bodensaeule'], [0,205,0]),
      merge('core', ['kern'], [0,205,0]),
      merge('bladering', ['klingen'], [0,193,0])]
build(fx, 'fx', BASE+'fx_model.json', BASE+'textures/entity/daemonenlord_fx.png')
