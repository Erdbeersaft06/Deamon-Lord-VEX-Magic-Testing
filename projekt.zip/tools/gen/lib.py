"""Mini-Modellbau: Part-Baum + Cubes + gemalte Texturen -> JsonModel-JSON, PNG-Atlas, .bbmodel, Vorschau."""
import math, json, io, base64, uuid, colorsys
import numpy as np
from PIL import Image, ImageDraw

# ------------------------------------------------------------------ Farben / Materialien
def rgb(h):
    if isinstance(h, str):
        h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    return tuple(h)

def mix(a, b, t):
    a, b = rgb(a), rgb(b); return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))

def hsh(*v):
    x = 0
    for i in v: x = (x * 1315423911 + int(i) * 2654435761 + 97) & 0xFFFFFFFF
    x ^= x >> 13; x = (x * 1274126177) & 0xFFFFFFFF; x ^= x >> 16
    return (x & 0xFFFF) / 65535.0


class Mat:
    """Material. base: Farbe; grad: (oben, unten) Helligkeitsfaktor; noise: Pixelrauschen; edge: Kantenabdunklung.
    pat: weave|stripe|plate|feather|scale|stars|runes|brush|rays|none; pc: Musterfarbe; tip: Alpha-Spitze (v=unten, u=oben, r=rund, c=beide)
    trim: Randfarbe (1px); glow: Mittelleuchten (Farbe); custom: {face: callable(arr)}"""
    _n = 0

    def __init__(s, base, grad=(1.12, 0.86), noise=7, edge=0.20, pat='none', pc=None, tip='none', trim=None, glow=None, custom=None, name=None):
        s.base = rgb(base); s.grad = grad; s.noise = noise; s.edge = edge; s.pat = pat
        s.pc = rgb(pc) if pc is not None else None
        s.tip = tip; s.trim = rgb(trim) if trim is not None else None; s.glow = rgb(glow) if glow is not None else None
        s.custom = custom or {}
        Mat._n += 1; s.seed = Mat._n

    def paint(s, face, w, h):
        W, H = max(1, w), max(1, h)
        yy, xx = np.mgrid[0:H, 0:W]
        base = np.array(s.base, float)
        t = (yy / max(1, H - 1))[..., None]
        g = (s.grad[0] + (s.grad[1] - s.grad[0]) * t)
        if face in ('U', 'D'): g = np.ones_like(g) * (1.10 if face == 'U' else 0.72)
        img = base[None, None, :] * g
        # Rauschen
        rng = np.random.RandomState((s.seed * 7919 + ord(face) * 31 + W * 13 + H) & 0x7FFFFFFF)
        img = img + rng.randint(-s.noise, s.noise + 1, size=(H, W, 1))
        pc = np.array(s.pc if s.pc is not None else tuple(min(255, c * 1.3 + 25) for c in s.base), float)
        dk = np.array(tuple(c * 0.55 for c in s.base), float)
        p = s.pat
        if p == 'weave':
            m = (((xx + yy) % 4) < 2)[..., None]; img = np.where(m, img * 0.90, img * 1.05)
        elif p == 'stripe':
            m = (xx % 4 == 0)[..., None]; img = np.where(m, img * 0.82, img)
        elif p == 'plate':
            img[H // 2:H // 2 + 1, :, :] *= 0.70
            for (cx, cy) in ((1, 1), (W - 2, 1), (1, H - 2), (W - 2, H - 2)):
                if 0 <= cx < W and 0 <= cy < H: img[cy, cx] = pc
        elif p == 'brush':
            m = (yy % 3 == 0)[..., None]; img = np.where(m, img * 1.10, img * 0.96)
        elif p == 'scale':
            m = ((((xx + (yy // 2) % 2 * 2) % 4) == 0) | ((yy % 4) == 3))[..., None]; img = np.where(m, img * 0.78, img * 1.04)
        elif p == 'feather':
            cx = (W - 1) / 2.0
            d = np.abs(xx - cx)
            bar = ((d + yy * 0.6) % 3 < 1)[..., None]
            img = np.where(bar, img * 0.86, img * 1.06)
            img = np.where((d < 0.6)[..., None], pc[None, None, :], img)
        elif p == 'stars':
            m = rng.rand(H, W) > 0.965
            img = np.where(m[..., None], pc[None, None, :], img)
        elif p == 'runes':
            m = ((yy % 6 == 2) & (rng.rand(H, W) > 0.45)) | ((xx % 7 == 3) & (yy % 6 > 0) & (rng.rand(H, W) > 0.7))
            img = np.where(m[..., None], pc[None, None, :], img)
        elif p == 'rays':
            cx = (W - 1) / 2.0; ang = np.arctan2(xx - cx, yy + 1.0)
            m = (np.sin(ang * 9) > 0.6)[..., None]
            img = np.where(m, img * 1.12, img)
        # Randlicht: oben heller, unten/seitlich dunkler
        if s.edge > 0 and W > 2 and H > 2:
            e = np.ones((H, W, 1))
            e[0, :, :] *= 1.0 + s.edge * 0.8
            e[-1, :, :] *= 1.0 - s.edge
            e[:, 0, :] *= 1.0 - s.edge * 0.6
            e[:, -1, :] *= 1.0 - s.edge * 0.8
            img = img * e
        if s.trim is not None and W > 2 and H > 2:
            tr = np.array(s.trim, float)
            img[0, :, :] = tr; img[-1, :, :] = tr; img[:, 0, :] = tr; img[:, -1, :] = tr
        if s.glow is not None:
            cx, cy = (W - 1) / 2.0, (H - 1) / 2.0
            r = np.sqrt(((xx - cx) / max(1, W / 2)) ** 2 + ((yy - cy) / max(1, H / 2)) ** 2)
            k = np.clip(1.0 - r, 0, 1)[..., None] ** 1.5
            img = img * (1 - k) + np.array(s.glow, float)[None, None, :] * k
        img = np.clip(img, 0, 255)
        a = np.full((H, W), 255, float)
        tp = s.tip
        if tp in ('v', 'c'):   # Spitze unten
            cx = (W - 1) / 2.0; ys0 = H * 0.62
            lim = np.where(yy > ys0, (H - yy) / max(1.0, H - ys0) * (W / 2.0), W)
            a = np.where(np.abs(xx - cx) > lim, 0, a)
        if tp in ('u', 'c'):   # Spitze oben
            cx = (W - 1) / 2.0; ys0 = H * 0.38
            lim = np.where(yy < ys0, (yy + 1) / max(1.0, ys0) * (W / 2.0), W)
            a = np.where(np.abs(xx - cx) > lim, 0, a)
        if tp == 'r':
            cx, cy = (W - 1) / 2.0, (H - 1) / 2.0
            a = np.where(((xx - cx) / (W / 2.0)) ** 2 + ((yy - cy) / (H / 2.0)) ** 2 > 1.05, 0, a)
        out = np.dstack([img, a]).astype(np.uint8)
        if face in s.custom: s.custom[face](out)
        return out


# ------------------------------------------------------------------ Modell
class Cube:
    def __init__(s, a, b, mat, name=None):
        s.a = a; s.b = b; s.mat = mat; s.name = name
        s.uv = None


class Part:
    _n = 0

    def __init__(s, name, piv, rot=(0.0, 0.0, 0.0)):
        if name is None:
            Part._n += 1; name = 'f%d' % Part._n
        s.name = name; s.piv = tuple(piv); s.rot = tuple(rot); s.cubes = []; s.kids = []

    def add(s, name, piv, rot=(0.0, 0.0, 0.0)):
        k = Part(name, piv, rot); s.kids.append(k); return k

    def cube(s, a, b, mat, name=None, clip=None):
        """a,b: absolute (unrotierte) Koordinaten, y nach oben. clip: 'neg'|'pos' schneidet an x=0."""
        a = list(a); b = list(b)
        if a[0] > b[0]: a[0], b[0] = b[0], a[0]
        if a[1] > b[1]: a[1], b[1] = b[1], a[1]
        if a[2] > b[2]: a[2], b[2] = b[2], a[2]
        if clip == 'neg': b[0] = min(b[0], 0.0)
        elif clip == 'pos': a[0] = max(a[0], 0.0)
        if b[0] - a[0] < 0.01: return None
        c = Cube(tuple(a), tuple(b), mat, name); s.cubes.append(c); return c

    def walk(s):
        yield s
        for k in s.kids:
            yield from k.walk()


def scale_tree(root, S):
    for p in root.walk():
        p.piv = tuple(v * S for v in p.piv)
        for c in p.cubes:
            c.a = tuple(v * S for v in c.a); c.b = tuple(v * S for v in c.b)


# ------------------------------------------------------------------ Atlas
def pack(root, width=1024):
    """Vergibt (u,v) fuer jede Box (Standard-Box-UV) per Regalpackung."""
    cubes = [c for p in root.walk() for c in p.cubes]
    items = []
    for c in cubes:
        w, h, d = c.b[0] - c.a[0], c.b[1] - c.a[1], c.b[2] - c.a[2]
        c.dim = (w, h, d)
        c.sz = (2 * int(math.ceil(d)) + 2 * int(math.ceil(w)) + 1, int(math.ceil(d)) + int(math.ceil(h)) + 1)
        items.append(c)
    items.sort(key=lambda c: -c.sz[1])
    x = y = rowh = 0
    for c in items:
        if x + c.sz[0] > width: x = 0; y += rowh; rowh = 0
        c.uv = (x, y); x += c.sz[0]; rowh = max(rowh, c.sz[1])
    H = y + rowh
    H = int(math.ceil(H / 16.0) * 16)
    return width, H


def face_rects(c):
    u, v = c.uv; w, h, d = c.dim
    iw, ih, idd = int(math.ceil(w)), int(math.ceil(h)), int(math.ceil(d))
    # Region je Flaeche (u0,v0,pw,ph) in Pixeln; entspricht Vanilla-Layout bei ganzzahligen Massen
    return {
        'W': (u, v + idd, idd, ih), 'N': (u + idd, v + idd, iw, ih), 'E': (u + idd + iw, v + idd, idd, ih),
        'S': (u + 2 * idd + iw, v + idd, iw, ih), 'U': (u + idd, v, iw, idd), 'D': (u + idd + iw, v, iw, idd)}


def paint_atlas(root, W, H):
    atl = np.zeros((H, W, 4), np.uint8)
    for p in root.walk():
        for c in p.cubes:
            for f, (u0, v0, pw, ph) in face_rects(c).items():
                if pw <= 0 or ph <= 0: continue
                tile = c.mat.paint(f, pw, ph)
                atl[v0:v0 + ph, u0:u0 + pw] = tile
    return Image.fromarray(atl, 'RGBA')


# ------------------------------------------------------------------ Export (JsonModel)
def r3(x): return round(float(x), 3)


def to_json(root, W, H):
    """root: Part 'all' mit piv (0,0,0) in bb-Raum (y oben, Fuesse y=0)."""
    def conv(p, parent_piv):
        dx, dy, dz = p.piv[0] - parent_piv[0], p.piv[1] - parent_piv[1], p.piv[2] - parent_piv[2]
        n = {'n': p.name, 'p': [r3(dx), r3(-dy), r3(dz)]}
        if any(abs(a) > 1e-9 for a in p.rot): n['r'] = [r3(a) for a in p.rot]
        if p.cubes:
            n['c'] = []
            for c in p.cubes:
                w, h, d = c.dim
                n['c'].append([c.uv[0], c.uv[1], r3(c.a[0] - p.piv[0]), r3(p.piv[1] - c.b[1]), r3(c.a[2] - p.piv[2]), r3(w), r3(h), r3(d)])
        if p.kids: n['k'] = [conv(k, p.piv) for k in p.kids]
        return n
    out = conv(root, (0, 0, 0))
    out['p'] = [0, 24, 0]
    return {'tex': [W, H], 'root': out}


# ------------------------------------------------------------------ Export (.bbmodel, Bedrock, Box-UV)
def to_bbmodel(root, W, H, atlas, name):
    elements = []; uid = {}
    def conv(p):
        node_uuid = str(uuid.uuid4())
        children = []
        for c in p.cubes:
            e_id = str(uuid.uuid4())
            elements.append({'name': c.name or 'cube', 'box_uv': True, 'rescale': False, 'locked': False,
                             'from': [r3(-c.b[0]), r3(c.a[1]), r3(c.a[2])], 'to': [r3(-c.a[0]), r3(c.b[1]), r3(c.b[2])],
                             'autouv': 0, 'color': 1, 'origin': [r3(-p.piv[0]), r3(p.piv[1]), r3(p.piv[2])],
                             'uv_offset': [c.uv[0], c.uv[1]], 'type': 'cube', 'uuid': e_id})
            children.append(e_id)
        for k in p.kids: children.append(conv(k))
        g = {'name': p.name, 'origin': [r3(-p.piv[0]), r3(p.piv[1]), r3(p.piv[2])], 'color': 0, 'uuid': node_uuid, 'export': True,
             'isOpen': False, 'locked': False, 'visibility': True, 'autouv': 0, 'children': children}
        if any(abs(a) > 1e-9 for a in p.rot):
            g['rotation'] = [r3(math.degrees(-p.rot[0])), r3(math.degrees(-p.rot[1])), r3(math.degrees(p.rot[2]))]
        return g
    outl = [conv(root)]
    buf = io.BytesIO(); atlas.save(buf, 'PNG')
    return {'meta': {'format_version': '4.5', 'model_format': 'bedrock', 'box_uv': True}, 'name': name + '.geo', 'model_identifier': name,
            'visible_box': [4, 4, 1.5], 'variable_placeholders': '', 'variable_placeholder_buttons': [], 'timeline_setups': [],
            'resolution': {'width': W, 'height': H}, 'elements': elements, 'outliner': outl,
            'textures': [{'path': '', 'name': name + '.png', 'folder': 'block', 'namespace': '', 'id': '0', 'particle': False,
                          'render_mode': 'default', 'frame_time': 1, 'frame_order_type': 'loop', 'frame_order': '', 'frame_interpolate': False,
                          'visible': True, 'mode': 'bitmap', 'saved': True, 'uuid': str(uuid.uuid4()), 'relative_path': '',
                          'source': 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()}],
            'animations': []}


# ------------------------------------------------------------------ Vorschau (texturiert, z-Buffer)
def rotzyx(rx, ry, rz):
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]]); Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]]); Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def collect_quads(M, pose=None, extra=None):
    """liefert Liste (quad[4x3], uvrect(u0,v0,pw,ph), face) in Modellraum (y nach unten)."""
    pose = pose or {}
    out = []
    def walk(n, Mat_, T):
        T2 = T + Mat_ @ np.array(n['p'])
        rr = list(n.get('r', [0, 0, 0]))
        nm = n.get('n')
        sc = 1.0
        if nm in pose:
            pv = pose[nm]
            for i in range(3): rr[i] += pv[i]
        R = Mat_ @ rotzyx(*rr) if any(abs(a) > 1e-9 for a in rr) else Mat_
        for u, v, x, y, z, w, h, d in n.get('c', []):
            x1, y1, z1 = x + w, y + h, z + d
            P = lambda a, b, c: T2 + R @ np.array([a, b, c])
            q = {'N': [P(x, y, z), P(x1, y, z), P(x1, y1, z), P(x, y1, z)], 'S': [P(x1, y, z1), P(x, y, z1), P(x, y1, z1), P(x1, y1, z1)],
                 'W': [P(x, y, z1), P(x, y, z), P(x, y1, z), P(x, y1, z1)], 'E': [P(x1, y, z), P(x1, y, z1), P(x1, y1, z1), P(x1, y1, z)],
                 'U': [P(x, y, z), P(x1, y, z), P(x1, y, z1), P(x, y, z1)], 'D': [P(x, y1, z1), P(x1, y1, z1), P(x1, y1, z), P(x, y1, z)]}
            iw, ih, idd = int(math.ceil(w)), int(math.ceil(h)), int(math.ceil(d))
            reg = {'W': (u, v + idd, idd, ih), 'N': (u + idd, v + idd, iw, ih), 'E': (u + idd + iw, v + idd, idd, ih),
                   'S': (u + 2 * idd + iw, v + idd, iw, ih), 'U': (u + idd, v, iw, idd), 'D': (u + idd + iw, v, iw, idd)}
            for f in q: out.append((q[f], reg[f], f))
        for k in n.get('k', []): walk(k, R, T2)
    walk(M['root'], np.eye(3), np.zeros(3))
    return out


def render(M, atlas, pose=None, yaw=0.0, pitch=0.0, W=640, H=820, bg=(34, 30, 52), ymin=None, ymax=None, xc=0.0):
    a = np.array(atlas.convert('RGBA'))
    quads = collect_quads(M, pose)
    ca, sa = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    pts = []
    for q, reg, f in quads:
        w = []
        for p in q:
            x, y, z = -p[0], 24 - p[1], p[2]          # y nach oben, x gespiegelt (Betrachter vor der Figur)
            x, z = x * ca + z * sa, -x * sa + z * ca
            y, z = y * cp - z * sp, y * sp + z * cp
            w.append((x, y, z))
        pts.append((np.array(w), reg, f))
    allp = np.concatenate([p[0] for p in pts])
    lo = ymin if ymin is not None else allp[:, 1].min(); hi = ymax if ymax is not None else allp[:, 1].max()
    sc = (H - 40) / (hi - lo)
    img = np.zeros((H, W, 3), np.float32); img[:] = bg
    zb = np.full((H, W), 1e9, np.float32)
    L = np.array([0.35, 0.55, -0.75]); L /= np.linalg.norm(L)
    for w, reg, f in pts:
        n = np.cross(w[1] - w[0], w[2] - w[0]); nn = np.linalg.norm(n)
        if nn < 1e-9: continue
        n /= nn
        if n[2] > 0: n = -n   # zur Kamera drehen (Kamera schaut entlang +z, Flaechen sind zweiseitig)
        sh = 0.55 + 0.45 * max(0.0, float(-n @ L))
        sx = W / 2 + (w[:, 0] - xc) * sc; sy = H - 20 - (w[:, 1] - lo) * sc; sz = w[:, 2]
        u0, v0, pw, ph = reg
        uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]
        for tri in ((0, 1, 2), (0, 2, 3)):
            X = sx[list(tri)]; Y = sy[list(tri)]; Z = sz[list(tri)]
            x0, x1 = int(max(0, math.floor(X.min()))), int(min(W - 1, math.ceil(X.max())))
            y0, y1 = int(max(0, math.floor(Y.min()))), int(min(H - 1, math.ceil(Y.max())))
            if x1 < x0 or y1 < y0: continue
            den = (Y[1] - Y[2]) * (X[0] - X[2]) + (X[2] - X[1]) * (Y[0] - Y[2])
            if abs(den) < 1e-9: continue
            gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
            l0 = ((Y[1] - Y[2]) * (gx - X[2]) + (X[2] - X[1]) * (gy - Y[2])) / den
            l1 = ((Y[2] - Y[0]) * (gx - X[2]) + (X[0] - X[2]) * (gy - Y[2])) / den
            l2 = 1 - l0 - l1
            m = (l0 >= -0.01) & (l1 >= -0.01) & (l2 >= -0.01)
            if not m.any(): continue
            uu = l0 * uvs[tri[0]][0] + l1 * uvs[tri[1]][0] + l2 * uvs[tri[2]][0]
            vv = l0 * uvs[tri[0]][1] + l1 * uvs[tri[1]][1] + l2 * uvs[tri[2]][1]
            tx = np.clip((u0 + uu * pw).astype(int), 0, a.shape[1] - 1); ty = np.clip((v0 + vv * ph).astype(int), 0, a.shape[0] - 1)
            tex = a[ty, tx]
            zz = l0 * Z[0] + l1 * Z[1] + l2 * Z[2]
            sub = zb[y0:y1 + 1, x0:x1 + 1]
            ok = m & (tex[..., 3] > 40) & (zz < sub)
            if not ok.any(): continue
            sub[ok] = zz[ok]
            region = img[y0:y1 + 1, x0:x1 + 1]
            region[ok] = tex[..., :3][ok] * sh
    return Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)), (lo, hi)
