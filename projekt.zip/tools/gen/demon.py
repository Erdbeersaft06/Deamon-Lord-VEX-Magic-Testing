"""Dämonenlord – schwer gepanzerter Höllenfürst mit Hörnern, Fledermausflügeln und Großschwert."""
import math
from lib import *

PI = math.pi

DPAL = {
    'normal': dict(armor='#2A2733', armor2='#3C3848', armor3='#18161F', trim='#E0AE3A', trim_hi='#FFE08A', trim_dk='#9A6C1C', glow='#FF8A1E', glow2='#FFD27A',
                   skin='#7C4A48', mem='#5E1424', mem2='#8E2236', bone='#CFC3A6', blade='#B8BCC8', blade_hi='#F2F4FA', eye='#FF7A18', cape='#1E1A24', cape2='#43202C'),
    'red': dict(armor='#3C1014', armor2='#5C1A20', armor3='#220A0C', trim='#FF6A2A', trim_hi='#FFC08A', trim_dk='#A03210', glow='#FF3A2A', glow2='#FFAA70',
                skin='#8E4040', mem='#7E1212', mem2='#B02222', bone='#D8B8A0', blade='#D0A8A0', blade_hi='#FFE8E0', eye='#FF2A20', cape='#2E0C10', cape2='#661A22'),
    'blue': dict(armor='#122140', armor2='#1C3566', armor3='#0A1428', trim='#74D6FF', trim_hi='#D4F4FF', trim_dk='#2C78B0', glow='#4AA8FF', glow2='#B8E4FF',
                 skin='#3C5C88', mem='#10306E', mem2='#2056B4', bone='#B8CCE6', blade='#A8C4E4', blade_hi='#EAF6FF', eye='#7AE6FF', cape='#0C1630', cape2='#1C3A78'),
}


def helm_face(P):
    gl = rgb(P['eye']); gl2 = rgb(P['glow2']); dk = rgb(P['armor3']); tr = rgb(P['trim'])
    def face(a):
        H, W = a.shape[:2]
        a[:, :, :3] = dk
        def px(x, y, c):
            if 0 <= x < W and 0 <= y < H: a[y, x, :3] = c; a[y, x, 3] = 255
        for x in range(0, W): px(x, 0, tr); px(x, H - 1, tr)
        for y in range(H): px(0, y, tr); px(W - 1, y, tr)
        # schraege Augen
        for i in range(3):
            px(2 + i, 3 if i == 0 else 4, gl); px(W - 3 - i, 3 if i == 0 else 4, gl)
        px(3, 4, gl2); px(W - 4, 4, gl2)
        px(3, 5, gl); px(W - 4, 5, gl)
        # Zaehne
        for x in range(2, W - 2):
            px(x, H - 3, gl2 if x % 2 == 0 else dk)
        px(W // 2, 6, tr); px(W // 2 - 1, 6, tr)
    return face


class D:
    def __init__(s, variant):
        s.P = P = DPAL[variant]
        s.root = Part('all', (0, 0, 0)); s.parts = {}
        M = {}
        M['armor'] = Mat(P['armor'], pat='plate', pc=P['trim'], grad=(1.15, 0.82), edge=0.28)
        M['armor2'] = Mat(P['armor2'], pat='brush', grad=(1.14, 0.82), edge=0.25)
        M['armor3'] = Mat(P['armor3'], pat='weave', grad=(1.1, 0.85))
        M['trim'] = Mat(P['trim'], pat='plate', pc=P['trim_hi'], grad=(1.15, 0.80), edge=0.25)
        M['trimhi'] = Mat(P['trim_hi'], grad=(1.05, 0.9), edge=0.15)
        M['trimdk'] = Mat(P['trim_dk'], pat='plate', pc=P['trim'], grad=(1.1, 0.8))
        M['glow'] = Mat(P['glow'], glow=P['glow2'], grad=(1.05, 0.95), edge=0.08, noise=4)
        M['skin'] = Mat(P['skin'], pat='scale', grad=(1.1, 0.85))
        M['mem'] = Mat(P['mem'], pat='stripe', pc=P['mem2'], tip='v', grad=(1.12, 0.78), edge=0.12, noise=8)
        M['mem2'] = Mat(P['mem2'], pat='stripe', pc=P['mem'], tip='v', grad=(1.12, 0.78), edge=0.12, noise=8)
        M['bone'] = Mat(P['bone'], pat='plate', pc='#FFFFFF', grad=(1.12, 0.8), edge=0.2)
        M['horn'] = Mat(P['bone'], pat='stripe', grad=(1.2, 0.75), edge=0.2)
        M['hornt'] = Mat(P['trim_hi'], grad=(1.1, 0.8), edge=0.15)
        M['blade'] = Mat(P['blade'], pat='brush', grad=(1.2, 0.85), edge=0.2)
        M['bladehi'] = Mat(P['blade_hi'], grad=(1.05, 0.9), edge=0.1, noise=3)
        M['cape'] = Mat(P['cape'], pat='weave', pc=P['cape2'], grad=(1.1, 0.7), edge=0.15)
        M['cape2'] = Mat(P['cape2'], pat='stripe', grad=(1.1, 0.75), edge=0.15, tip='v')
        M['capetorn'] = Mat(P['cape'], pat='weave', tip='v', grad=(1.1, 0.7), edge=0.15)
        M['head'] = Mat(P['armor'], pat='plate', pc=P['trim'], grad=(1.15, 0.82), edge=0.25, custom={'N': helm_face(P)})
        s.M = M

    def part(s, parent, name, piv, rot=(0, 0, 0)):
        q = parent.add(name, piv, rot); s.parts[name] = q; return q

    def build(s):
        M = s.M; all_ = s.root
        # ---- Beine
        for side, sx in (('l', -1), ('r', 1)):
            lx = sx * 4.2
            leg = s.part(all_, 'leg_' + side, (lx, 30, 0))
            leg.cube((lx - 2.9, 17, -2.9), (lx + 2.9, 30.6, 2.9), M['armor'])
            leg.cube((lx - 3.3, 22.5, -3.5), (lx + 3.3, 25.5, 3.1), M['trim'])                 # Knieschutz-Band
            leg.cube((lx - 1.0, 18.0, -5.0), (lx + 1.0, 24.5, -3.4), M['trimhi'])             # Knie-Stachel
            shin = s.part(leg, 'shin_' + side, (lx, 17.5, 0))
            shin.cube((lx - 2.5, 4, -2.6), (lx + 2.5, 18, 3.0), M['armor2'])
            shin.cube((lx - 2.9, 5, -3.2), (lx + 2.9, 9.0, 3.4), M['trim'])
            shin.cube((lx - 3.0, 0, -5.8), (lx + 3.0, 4.2, 3.2), M['armor'])                    # Stiefel
            shin.cube((lx - 3.0, 0, -7.4), (lx - 0.2, 2.6, -5.8), M['trimhi'])                  # Huf links
            shin.cube((lx + 0.2, 0, -7.4), (lx + 3.0, 2.6, -5.8), M['trimhi'])                  # Huf rechts
            shin.cube((lx - 0.8, 0, 3.2), (lx + 0.8, 5.0, 5.0), M['trimhi'])                     # Sporn
        # ---- Koerper
        body = s.part(all_, 'body', (0, 30, 0))
        body.cube((-5.6, 26, -3.4), (5.6, 33, 3.4), M['armor2'])                               # Becken
        body.cube((-4.8, 33, -3.0), (4.8, 41, 3.0), M['armor3'])                               # Bauch
        for k in range(3): body.cube((-4.9, 34 + k * 2.6, -3.4), (4.9, 35.2 + k * 2.6, -2.9), M['trim'])   # Rippenplatten
        body.cube((-7.4, 41, -4.6), (7.4, 53, 4.4), M['armor'])                                 # Brustpanzer
        body.cube((-7.8, 49.5, -5.0), (7.8, 51.8, 4.8), M['trim'])                              # Schulterband
        body.cube((-2.4, 43.5, -5.4), (2.4, 48.5, -4.6), M['glow'])                            # Dämonenkern
        body.cube((-3.6, 42.5, -5.0), (3.6, 49.5, -4.7), M['trim']) if False else None
        for sx in (-1, 1):
            body.cube((sx * 4.0 - 1.2, 42.0, -5.2), (sx * 4.0 + 1.2, 49.0, -4.7), M['trimdk'])  # Kernrahmen-Streben
            body.cube((sx * 5.6 - 0.8, 44, -5.3), (sx * 5.6 + 0.8, 50.5, -4.7), M['trimhi'])
        body.cube((-6.2, 41.0, 4.4), (6.2, 52.0, 5.2), M['armor3'])                             # Rueckenplatte
        body.cube((-5.0, 53, -3.2), (5.0, 55.2, 3.0), M['trimdk'])                              # Halsberge
        for k, sx in enumerate((-3.4, -1.1, 1.1, 3.4)):
            body.cube((sx - 0.6, 52.0, 5.0), (sx + 0.6, 57.5 - abs(sx) * 0.6, 6.4), M['trimhi'])  # Ruecken-Stacheln
        # Lendenschurz (Fahnen)
        for sx, w in ((-3.3, 2.7), (0.0, 2.7), (3.3, 2.7)):
            body.cube((sx - w, 14.0 + abs(sx) * 0.7, -4.2), (sx + w, 27, -3.5), M['cape2'])
            body.cube((sx - w - 0.2, 26.0, -4.4), (sx + w + 0.2, 27.6, -3.3), M['trim'])
        body.cube((-4.8, 13.0, 3.4), (4.8, 27, 4.1), M['cape'])
        # ---- Kopf
        head = s.part(body, 'head', (0, 54.5, 0))
        head.cube((-4.3, 54.5, -4.3), (4.3, 63.3, 4.3), M['head'])
        head.cube((-4.7, 62.4, -4.7), (4.7, 64.2, 4.7), M['trim'])
        head.cube((-0.8, 63.5, -5.0), (0.8, 68.8, 3.5), M['armor2'])                            # Helmkamm
        head.cube((-0.5, 66.8, -3.0), (0.5, 71.0, 1.0), M['trimhi'])
        head.cube((-4.9, 55.6, 2.0), (4.9, 63.0, 4.9), M['armor2'])                             # Nackenschutz
        head.cube((-1.2, 52.5, -5.0), (1.2, 55.0, -3.7), M['trimhi'])                           # Kinnstachel
        for sx in (-1, 1):
            head.cube((sx * 4.4 - 0.5, 55.8, -3.0), (sx * 4.4 + 0.5, 62.0, 2.2), M['trim'])  # Wangenplatten
            # Hoerner: Kette aus 3 Segmenten
            base = (sx * 3.4, 62.4, 0.0)
            h1 = s.part(head, 'horn1_%s' % ('l' if sx < 0 else 'r'), base, (0, 0, sx * 0.85))
            h1.cube((base[0] - 1.6, base[1] - 0.5, -1.6), (base[0] + 1.6, base[1] + 6.5, 1.6), M['horn'])
            p2 = (base[0], base[1] + 6.3, 0.0)
            h2 = s.part(h1, 'horn2_%s' % ('l' if sx < 0 else 'r'), p2, (0, 0, sx * 0.55))
            h2.cube((p2[0] - 1.25, p2[1], -1.25), (p2[0] + 1.25, p2[1] + 6.0, 1.25), M['horn'])
            p3 = (p2[0], p2[1] + 5.8, 0.0)
            h3 = s.part(h2, 'horn3_%s' % ('l' if sx < 0 else 'r'), p3, (0, 0, -sx * 1.05))
            h3.cube((p3[0] - 0.8, p3[1], -0.8), (p3[0] + 0.8, p3[1] + 5.4, 0.8), M['hornt'])
        # kleine Kronzacken hinten
        for k in range(5):
            phi = -0.9 + 1.8 * k / 4
            q = s.part(head, 'sp%d' % k, (0, 63.5, 3.0), (0, 0, phi))
            q.cube((-0.7, 64.0, 2.4), (0.7, 64.0 + 4.0 - abs(phi) * 1.2, 3.6), M['trim'])
        # ---- Arme
        for side, sx in (('l', -1), ('r', 1)):
            ax = sx * 10.4
            arm = s.part(body, 'arm_' + side, (ax, 50.5, 0))
            arm.cube((ax - 2.6, 38, -2.6), (ax + 2.6, 51, 2.6), M['armor2'])
            arm.cube((ax - 5.6, 50.0, -4.4), (ax + 5.6, 54.0, 4.4), M['armor'])                    # Schulterplatte 1
            arm.cube((ax - 5.0 + sx * 0.8, 54.0, -3.8), (ax + 5.0 + sx * 0.8, 56.4, 3.8), M['trim'])  # 2
            arm.cube((ax - 3.8 + sx * 1.6, 56.4, -3.0), (ax + 3.8 + sx * 1.6, 58.2, 3.0), M['armor'])  # 3
            for o in (-2.6, 0.0, 2.6):
                arm.cube((ax + sx * 3.2 - 0.9, 58.2, o - 0.9), (ax + sx * 3.2 + 0.9, 62.6 - abs(o) * 0.7, o + 0.9), M['trimhi'])   # Stacheln
            arm.cube((ax - 3.0, 36.5, -3.0), (ax + 3.0, 39.0, 3.0), M['trim'])                     # Ellbogen
            arm.cube((ax + sx * 2.2 - 0.7, 36.0, -0.7), (ax + sx * 2.2 + 0.7, 41.0, 0.7), M['trimhi']) if False else None
            fa = s.part(arm, 'forearm_' + side, (ax, 38.0, 0))
            fa.cube((ax - 2.9, 24.5, -2.9), (ax + 2.9, 38.5, 2.9), M['armor'])
            fa.cube((ax - 3.3, 26, -3.3), (ax + 3.3, 31.5, 3.3), M['trim'])                           # Armschiene
            fa.cube((ax + sx * 3.2 - 0.6, 25.5, -0.6), (ax + sx * 3.2 + 0.6, 33.0, 0.6), M['trimhi'])  # Klinge am Unterarm
            fa.cube((ax - 2.4, 20.0, -2.4), (ax + 2.4, 24.8, 2.4), M['armor3'])                      # Faust
            for o in (-1.4, 0.0, 1.4):
                fa.cube((ax + o - 0.45, 15.6, -2.9), (ax + o + 0.45, 20.4, -2.1), M['trimhi'])        # Krallen
            if side == 'r':
                w = s.part(fa, 'weapon_r', (ax, 22.0, 0), (1.4, 0, 0))
                w.cube((ax - 0.9, 14, -0.9), (ax + 0.9, 30, 0.9), M['trimdk'])                        # Griff
                w.cube((ax - 1.4, 22.0, -1.4), (ax + 1.4, 23.6, 1.4), M['trimhi'])
                w.cube((ax - 1.8, 12.5, -1.8), (ax + 1.8, 14.5, 1.8), M['glow'])                      # Knauf
                w.cube((ax - 6.2, 30, -1.1), (ax + 6.2, 32.2, 1.1), M['trim'])                        # Parierstange
                for o in (-1, 1):
                    w.cube((ax + o * 6.2 - (0.9 if o > 0 else -0.9) - 0.9, 28.6, -0.9), (ax + o * 6.2 + 0.9, 32.8 + 2.4, 0.9), M['trimhi'])
                w.cube((ax - 2.2, 32.2, -0.9), (ax + 2.2, 60, 0.9), M['blade'])                        # Klinge
                w.cube((ax - 0.5, 32.2, -1.1), (ax + 0.5, 60, 1.1), M['bladehi'])                      # Hohlkehle
                w.cube((ax - 1.7, 60, -0.8), (ax + 1.7, 66, 0.8), M['blade'])
                w.cube((ax - 0.9, 66, -0.7), (ax + 0.9, 70, 0.7), M['bladehi'])
        # ---- Fluegel (Fledermaus)
        for side, sx in (('l', -1), ('r', 1)):
            th = -sx
            P0 = (sx * 6.0, 50.0, 5.2)
            wing = s.part(body, 'wing_' + side, P0, (0, 0.45 if side == 'l' else -0.45, 0))
            L1, A1 = 17.0, 2.55
            ua = s.part(wing, 'ua_' + side, P0, (0, 0, th * A1))
            ua.cube((P0[0] - 2.0, P0[1] - L1, P0[2] - 1.0), (P0[0] + 2.0, P0[1], P0[2] + 1.0), M['bone'])
            ua.cube((P0[0] - 3.0, P0[1] - 3.0, P0[2] - 1.6), (P0[0] + 3.0, P0[1] + 1.0, P0[2] + 1.6), M['trim'])
            pw = (P0[0], P0[1] - L1, P0[2])
            L2, A2 = 26.0, 1.95
            fo = s.part(ua, 'fo_' + side, pw, (0, 0, th * (A2 - A1)))
            fo.cube((pw[0] - 1.5, pw[1] - L2, pw[2] - 0.9), (pw[0] + 1.5, pw[1], pw[2] + 0.9), M['bone'])
            fo.cube((pw[0] - 2.4, pw[1] - 2.6, pw[2] - 1.5), (pw[0] + 2.4, pw[1] + 1.4, pw[2] + 1.5), M['trim'])
            pr = (pw[0], pw[1] - L2, pw[2])
            fingers = [(0.55, 40), (0.95, 42), (1.35, 36), (1.72, 28)]
            absang = A2
            for i, (a, L) in enumerate(fingers):
                q = s.part(fo, 'fi%d_%s' % (i, side), pr, (0, 0, th * (a - absang)))
                q.cube((pr[0] - 0.9, pr[1] - L, pr[2] - 0.6), (pr[0] + 0.9, pr[1], pr[2] + 0.6), M['bone'])
                q.cube((pr[0] - 0.7, pr[1] - L - 2.4, pr[2] - 0.5), (pr[0] + 0.7, pr[1] - L, pr[2] + 0.5), M['trimhi'])
            # Membranen zwischen den Fingern
            for i in range(len(fingers) - 1):
                (a0, L0), (a1, L1_) = fingers[i], fingers[i + 1]
                am = (a0 + a1) / 2; Lm = min(L0, L1_) * 0.92
                wd = 2 * Lm * math.sin((a1 - a0) / 2) * 1.0 + 1.0
                q = s.part(fo, 'mb%d_%s' % (i, side), pr, (0, 0, th * (am - absang)))
                q.cube((pr[0] - wd / 2, pr[1] - Lm, pr[2] - 0.25), (pr[0] + wd / 2, pr[1], pr[2] + 0.25), M['mem'] if i % 2 == 0 else M['mem2'])
            # Membran Koerper -> erster Finger
            q = s.part(wing, 'mbx_' + side, P0, (0, 0, th * 0.18))
            q.cube((P0[0] - 9.5, P0[1] - 40, P0[2] - 0.3), (P0[0] + 9.5, P0[1], P0[2] + 0.3), M['mem'])
        # ---- Umhang (zerfetzt)
        cape = s.part(body, 'cape', (0, 52, 5.8))
        cape.cube((-8.2, 35, 5.3), (8.2, 52, 6.5), M['cape'])
        cape.cube((-8.6, 50.4, 5.0), (8.6, 52.4, 6.8), M['trim'])
        c2 = s.part(cape, 'cape2', (0, 35, 6.0))
        c2.cube((-8.6, 18, 5.5), (8.6, 35, 6.4), M['cape'])
        c3 = s.part(c2, 'cape3', (0, 18, 6.0))
        for sx, w, L in ((-5.6, 3.0, 17), (-1.9, 3.0, 22), (1.9, 3.0, 20), (5.6, 3.0, 15)):
            c3.cube((sx - w, 18 - L, 5.6), (sx + w, 18, 6.3), M['capetorn'] if abs(sx) < 3 else M['cape2'])
        # ---- Halo: Dornenkrone/Hoellenring
        halo = s.part(all_, 'halo', (0, 62.0, 9.5))
        cx, cy, cz = 0.0, 62.0, 9.5
        for k in range(18):
            ang = 2 * PI * k / 18
            q = s.part(halo, 'hr%d' % k, (cx, cy, cz), (0, 0, ang))
            q.cube((-2.6, cy + 14.5, cz - 0.9), (2.6, cy + 16.4, cz + 0.9), M['trim'] if k % 2 else M['trimhi'])
            Lr = 9.5 if k % 3 == 0 else 5.0
            q.cube((-0.9, cy + 16.4, cz - 0.7), (0.9, cy + 16.4 + Lr, cz + 0.7), M['glow'] if k % 3 == 0 else M['trimdk'])
        for k in range(8):
            ang = 2 * PI * k / 8 + 0.39
            q = s.part(halo, 'hi%d' % k, (cx, cy, cz + 0.8), (0, 0, ang))
            q.cube((-1.4, cy + 8.0, cz + 0.2), (1.4, cy + 11.0, cz + 1.4), M['glow'] if k % 2 else M['trim'])
        return s


def build_demon(variant='normal'):
    return D(variant).build().root
