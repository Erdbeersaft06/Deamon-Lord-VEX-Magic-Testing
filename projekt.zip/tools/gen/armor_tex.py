"""Vanilla-Ruestungstexturen (64x32) fuer die Sets Tank und Glass.
Layer 1 (humanoid): Helm, Brust+Arme, Stiefel. Layer 2 (humanoid_leggings): Gurt + Hose.
Die Texturen liegen auf dem normalen Ruestungsmodell -> sie bewegen sich exakt wie Vanilla und sind
auch in der Inventar-Ansicht sichtbar."""
from PIL import Image


def hx(s):
    s = s.lstrip('#')
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (255,)


def noise(x, y, k):
    h = (x * 73856093 ^ y * 19349663 ^ k * 83492791) & 255
    return 0.94 + 0.12 * (h / 255.0)


def faces(u, v, w, h, d):
    return {'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d), 'right': (u, v + d, d, h),
            'front': (u + d, v + d, w, h), 'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h)}


def paint_box(img, u, v, w, h, d, fn, k=0):
    """fn(face, x, y, fw, fh) -> RGBA oder None (transparent)."""
    for name, (fu, fv, fw, fh) in faces(u, v, w, h, d).items():
        for y in range(fh):
            for x in range(fw):
                c = fn(name, x, y, fw, fh)
                if c is None:
                    continue
                img.putpixel((fu + x, fv + y), shade(c, noise(fu + x, fv + y, k)))


# ------------------------------------------------------------------ Tank
def tank_palette():
    return dict(plate=hx('#E9E1CC'), plate2=hx('#CDC3A9'), gold=hx('#D9A63A'), hi=hx('#FFD97A'), dk=hx('#8F6418'),
                steel=hx('#3B4157'), steel2=hx('#232739'), crim=hx('#8E1F2D'), crim2=hx('#5C1020'), glow=hx('#7FE6FF'))


def tank_helm(P):
    def f(face, x, y, w, h):
        edge = x in (0, w - 1) or y in (0, h - 1)
        if face == 'top':
            return P['hi'] if x in (3, 4) else (P['gold'] if edge else P['plate'])
        if face == 'bottom':
            return None
        if face in ('front',):
            if y == 2: return P['gold']
            if y in (3, 4):
                if y == 4 and x in (1, 2, 5, 6): return P['glow']
                return P['steel2']
            if y >= 6 and x in (3, 4): return None
            if y >= 5: return P['plate2'] if not edge else P['gold']
            return P['gold'] if edge else P['plate']
        if y == 3: return P['gold']
        if y >= 5 and face != 'back': return None if x > 1 else P['plate2']
        return P['gold'] if edge else P['plate']
    return f


def tank_body(P):
    def f(face, x, y, w, h):
        edge = x in (0, w - 1) or y == 0
        if face in ('top', 'bottom'):
            return P['gold']
        if face == 'front':
            if y == 10: return P['gold']
            if x in (3, 4) and y >= 1:
                if x == 3 and y in (4, 5): return P['hi']
                if x == 4 and y in (4, 5): return P['gold']
                return P['crim'] if y < 11 else P['crim2']
            if edge: return P['gold']
            return P['plate'] if (x + y) % 5 else P['plate2']
        if face == 'back':
            if 1 <= x <= w - 2 and y >= 1: return P['crim'] if y % 4 else P['crim2']
            return P['gold']
        if y == 10: return P['gold']
        return P['plate2'] if x in (0, w - 1) else P['plate']
    return f


def tank_arm(P):
    def f(face, x, y, w, h):
        if face == 'top': return P['hi']
        if face == 'bottom': return P['dk']
        if y == 0: return P['hi']
        if y <= 3: return P['gold'] if y != 3 else P['dk']
        if y in (10, 11): return P['gold'] if y == 10 else P['dk']
        return P['plate'] if (x + y) % 4 else P['plate2']
    return f


def tank_boots(P):
    def f(face, x, y, w, h):
        if y < 8 or face == 'top': return None
        if face == 'bottom': return P['steel2']
        if y == 8: return P['gold']
        if y == 11: return P['steel2']
        if face == 'front' and y == 10 and x in (1, 2): return P['glow']
        return P['plate'] if y != 9 else P['plate2']
    return f


def tank_legs(P):
    def f(face, x, y, w, h):
        if face in ('top', 'bottom'): return P['gold'] if face == 'top' else None
        if y >= 8: return None
        if y == 0: return P['gold']
        if y == 7: return P['dk']
        if face == 'front' and x in (1, 2) and y in (3, 4): return P['gold']
        if x in (0, w - 1): return P['plate2']
        return P['plate'] if y % 3 else P['plate2']
    return f


def tank_belt(P):
    def f(face, x, y, w, h):
        if face in ('top', 'bottom') or y < 9: return None
        if y == 9: return P['gold']
        if face == 'front' and x in (3, 4): return P['crim']
        return P['dk'] if y == 11 else P['crim2']
    return f


# ------------------------------------------------------------------ Glass
def glass_palette():
    return dict(pearl=hx('#F4F2FA'), pearl2=hx('#D9D6EC'), pearl3=hx('#B4B0D6'), gold=hx('#E6B84A'), hi=hx('#FFEBA6'),
                dk=hx('#A97D1F'), blue=hx('#4FB3F5'), glow=hx('#B9F3FF'), dark=hx('#585A8E'))


def glass_helm(P):
    def f(face, x, y, w, h):
        if face == 'bottom': return None
        if face == 'top': return P['hi'] if x in (3, 4) and y in (3, 4) else (P['pearl'] if (x + y) % 3 else P['pearl2'])
        if y <= 1: return P['pearl'] if (x + y) % 2 else P['pearl2']
        if y == 2: return P['gold']
        if y == 3:
            if face == 'front' and x in (3, 4): return P['blue']
            return P['dk']
        if face == 'back' and y <= 5: return P['pearl2']
        return None
    return f


def glass_body(P):
    def f(face, x, y, w, h):
        if face in ('top', 'bottom'): return P['pearl2']
        if face == 'front':
            if y == 0: return P['gold']
            if x in (3, 4):
                if y in (2, 3): return P['blue'] if y == 2 else P['glow']
                return P['gold'] if y % 3 == 0 else P['hi']
            if y == 10: return P['gold']
            return P['pearl'] if (x + y) % 4 else P['pearl2']
        if face == 'back':
            if y == 0: return P['gold']
            return P['pearl2'] if (x + y) % 3 else P['pearl3']
        if y == 10: return P['gold']
        return P['pearl2']
    return f


def glass_arm(P):
    def f(face, x, y, w, h):
        if face == 'top': return P['gold']
        if face == 'bottom': return P['pearl3']
        if y <= 2: return P['pearl'] if y != 2 else P['gold']
        if y >= 9: return P['gold'] if y == 9 else (P['pearl3'] if (x + y) % 2 else P['pearl2'])
        return P['pearl'] if (x + y) % 3 else P['pearl2']
    return f


def glass_boots(P):
    def f(face, x, y, w, h):
        if y < 8 or face == 'top': return None
        if face == 'bottom': return P['dark']
        if y == 8: return P['gold']
        if face == 'front' and y == 10 and x in (1, 2): return P['blue']
        return P['pearl'] if y != 9 else P['pearl2']
    return f


def glass_legs(P):
    def f(face, x, y, w, h):
        if face in ('top', 'bottom'): return P['gold'] if face == 'top' else None
        if y >= 8: return None
        if y == 7: return P['gold']
        if y == 0: return P['dk']
        if face == 'front' and x in (1, 2) and y in (2, 3): return P['blue']
        return P['pearl'] if (x + y) % 3 else P['pearl2']
    return f


def glass_belt(P):
    def f(face, x, y, w, h):
        if face in ('top', 'bottom') or y < 9: return None
        if y == 9: return P['gold']
        if face == 'front' and x in (3, 4): return P['blue']
        return P['pearl3'] if y == 11 else P['pearl2']
    return f


def make(setname):
    """-> (layer1, layer2) als PIL-Bilder (64x32)."""
    if setname == 'tank':
        P = tank_palette(); fh, fb, fa, fbo, fl, fbe = tank_helm(P), tank_body(P), tank_arm(P), tank_boots(P), tank_legs(P), tank_belt(P)
    else:
        P = glass_palette(); fh, fb, fa, fbo, fl, fbe = glass_helm(P), glass_body(P), glass_arm(P), glass_boots(P), glass_legs(P), glass_belt(P)
    l1 = Image.new('RGBA', (64, 32), (0, 0, 0, 0))
    paint_box(l1, 0, 0, 8, 8, 8, fh, 1)       # Kopf
    paint_box(l1, 16, 16, 8, 12, 4, fb, 2)    # Koerper
    paint_box(l1, 40, 16, 4, 12, 4, fa, 3)    # Arm (links gespiegelt)
    paint_box(l1, 0, 16, 4, 12, 4, fbo, 4)    # Bein -> Stiefel
    l2 = Image.new('RGBA', (64, 32), (0, 0, 0, 0))
    paint_box(l2, 16, 16, 8, 12, 4, fbe, 5)   # Gurt
    paint_box(l2, 0, 16, 4, 12, 4, fl, 6)     # Hose
    return l1, l2
