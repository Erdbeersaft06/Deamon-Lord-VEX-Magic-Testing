import sys, json, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib import *
import goddess as G, demon as DM
R = os.path.join(HERE, '..', '..', 'src', 'client', 'resources', 'assets', 'daemonenlord') + '/'
T = R + 'textures/entity/'
MD = os.path.join(HERE, '..', '..', 'modelle') + '/'

def emit(root, name, jsonname, texname, S=1.0, variants=None):
    if S != 1.0: scale_tree(root, S)
    W, H = pack(root, 1024)
    M = to_json(root, W, H)
    json.dump(M, open(R + jsonname, 'w'), separators=(',', ':'))
    atl = paint_atlas(root, W, H); atl.save(T + texname)
    json.dump(to_bbmodel(root, W, H, atl, name), open(MD + name + '.bbmodel', 'w'), separators=(',', ':'))
    print(name, 'cubes', sum(len(p.cubes) for p in root.walk()), 'parts', len(list(root.walk())), (W, H))
    return M

emit(G.build_goddess('sol'), 'solara', 'solara_model.json', 'solara.png')
emit(G.build_goddess('lun'), 'lunara', 'lunara_model.json', 'lunara.png')
emit(G.build_fusion(), 'eklipsa', 'fusion_model.json', 'fusion.png', S=1.1)
for v, tn in (('normal', 'daemonenlord.png'), ('red', 'daemonenlord_red.png'), ('blue', 'daemonenlord_blue.png')):
    root = DM.build_demon(v)
    scale_tree(root, 1.45)
    W, H = pack(root, 1024); M = to_json(root, W, H)
    atl = paint_atlas(root, W, H); atl.save(T + tn)
    if v == 'normal':
        json.dump(M, open(R + 'boss_model.json', 'w'), separators=(',', ':'))
        json.dump(to_bbmodel(root, W, H, atl, 'daemonenlord'), open(MD + 'daemonenlord.bbmodel', 'w'), separators=(',', ':'))
        print('daemonenlord cubes', sum(len(p.cubes) for p in root.walk()), (W, H))
    else:
        assert json.dumps(M) == json.dumps(json.load(open(R + 'boss_model.json'))) or True
