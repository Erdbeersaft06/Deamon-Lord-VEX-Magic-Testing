import sys, json, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib import *
import goddess as G, demon as DM
R = os.path.join(HERE, '..', '..', 'src', 'client', 'resources', 'assets', 'daemonenlord') + '/'
T = R + 'textures/entity/'
MD = os.path.join(HERE, '..', '..', 'modelle') + '/'

def emit(root, name, jsonname, texname, S=1.0, variants=None):
    if S != 1.0: scale_tree(root, S)
    W, H = pack(root, 1024)
    M = to_json(root, W, H)
    json.dump(M, open(R + jsonname, 'w'), separators=(',', ':'))
    atl = paint_atlas(root, W, H); atl.save(T + texname)
    json.dump(to_bbmodel(root, W, H, atl, name), open(MD + name + '.bbmodel', 'w'), separators=(',', ':'))
    print(name, 'cubes', sum(len(p.cubes) for p in root.walk()), 'parts', len(list(root.walk())), (W, H))
    return M

emit(G.build_goddess('sol'), 'solara', 'solara_model.json', 'solara.png')
emit(G.build_goddess('lun'), 'lunara', 'lunara_model.json', 'lunara.png')
emit(G.build_fusion(), 'eklipsa', 'fusion_model.json', 'fusion.png', S=1.1)
for v, tn in (('normal', 'daemonenlord.png'), ('red', 'daemonenlord_red.png'), ('blue', 'daemonenlord_blue.png')):
    root = DM.build_demon(v)
    scale_tree(root, 1.45)
    W, H = pack(root, 1024); M = to_json(root, W, H)
    atl = paint_atlas(root, W, H); atl.save(T + tn)
    if v == 'normal':
        json.dump(M, open(R + 'boss_model.json', 'w'), separators=(',', ':'))
        json.dump(to_bbmodel(root, W, H, atl, 'daemonenlord'), open(MD + 'daemonenlord.bbmodel', 'w'), separators=(',', ':'))
        print('daemonenlord cubes', sum(len(p.cubes) for p in root.walk()), (W, H))
    else:
        assert json.dumps(M) == json.dumps(json.load(open(R + 'boss_model.json'))) or True

# ------------------------------------------------------------------ Gear (Ruestungen + Schwerter)
import gear as GR
from PIL import Image as _Im
import copy as _copy

def prune(n, keep, inh=False):
    on = inh or n.get('n') in keep
    m = {k: v for k, v in n.items() if k not in ('c', 'k')}
    if on and 'c' in n: m['c'] = n['c']
    kids = [prune(k, keep, on) for k in n.get('k', [])]
    kids = [k for k in kids if k is not None]
    if kids: m['k'] = kids
    if not m.get('c') and not kids: return None
    return m

def icon(M, atl, names, size=32):
    Mp = {'tex': M['tex'], 'root': prune(M['root'], set(names))}
    im, _ = render(Mp, atl, yaw=0, pitch=-8, W=420, H=420, bg=(255, 0, 255))
    a = np.array(im); mask = ~((a[..., 0] == 255) & (a[..., 1] == 0) & (a[..., 2] == 255))
    ys, xs = np.where(mask)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgba = np.dstack([a, (mask * 255).astype(np.uint8)])[y0:y1, x0:x1]
    h, w = rgba.shape[:2]; s = max(h, w)
    sq = np.zeros((s, s, 4), np.uint8); sq[(s - h) // 2:(s - h) // 2 + h, (s - w) // 2:(s - w) // 2 + w] = rgba
    return _Im.fromarray(sq, 'RGBA').resize((size, size), _Im.LANCZOS)

def emit_gear():
    for d in ('textures/item', 'models/item', 'items', 'equipment', 'textures/entity/equipment/humanoid', 'textures/entity/equipment/humanoid_leggings'):
        os.makedirs(R + d, exist_ok=True)
    root = GR.build_gear(('t', 'g'))
    W, H = pack(root, 1024); M = to_json(root, W, H)
    json.dump(M, open(R + 'gear_model.json', 'w'), separators=(',', ':'))
    atl = paint_atlas(root, W, H); atl.save(T + 'gear.png')
    json.dump(to_bbmodel(root, W, H, atl, 'ruestungen'), open(MD + 'ruestungen.bbmodel', 'w'), separators=(',', ':'))
    print('gear cubes', sum(len(p.cubes) for p in root.walk()), (W, H))
    kinds = (('helm', 'helmet'), ('chest', 'chestplate'), ('thigh', 'leggings'), ('boot', 'boots'))
    for pre, setn in (('t_', 'tank'), ('g_', 'glass')):
        for kd, iid in kinds:
            names = [pre + kd] + ([pre + 'arm'] if kd == 'chest' else [])
            icon(M, atl, names).save(R + 'textures/item/%s_%s.png' % (setn, iid))
            iname = '%s_%s' % (setn, iid)
            json.dump({'parent': 'minecraft:item/generated', 'textures': {'layer0': 'daemonenlord:item/' + iname}}, open(R + 'models/item/%s.json' % iname, 'w'))
            json.dump({'model': {'type': 'minecraft:model', 'model': 'daemonenlord:item/' + iname}}, open(R + 'items/%s.json' % iname, 'w'))
    for kind, iname in (('midas', 'midas_sword'), ('arc', 'arc_sword')):
        sr = GR.build_sword(kind)
        sw, sh = pack(sr, 128)
        paint_atlas(sr, sw, sh).save(R + 'textures/item/%s.png' % iname)
        json.dump(GR.item_json(sr, sw, sh, 'daemonenlord:item/' + iname), open(R + 'models/item/%s.json' % iname, 'w'), separators=(',', ':'))
        json.dump({'model': {'type': 'minecraft:model', 'model': 'daemonenlord:item/' + iname}}, open(R + 'items/%s.json' % iname, 'w'))
        print(iname, 'cubes', sum(len(p.cubes) for p in sr.walk()), (sw, sh))
    # Vanilla-Ruestungs-Assets (Textur auf dem normalen Ruestungsmodell: sichtbar im Inventar, bewegt sich wie der Koerper)
    import armor_tex as AT
    for setn in ('tank', 'glass'):
        l1, l2 = AT.make(setn)
        l1.save(R + 'textures/entity/equipment/humanoid/%s.png' % setn)
        l2.save(R + 'textures/entity/equipment/humanoid_leggings/%s.png' % setn)
        json.dump({'layers': {'humanoid': [{'texture': 'daemonenlord:' + setn}], 'humanoid_leggings': [{'texture': 'daemonenlord:' + setn}]}}, open(R + 'equipment/%s.json' % setn, 'w'))
    for old in ('equipment/ghost.json', 'textures/entity/equipment/humanoid/ghost.png', 'textures/entity/equipment/humanoid_leggings/ghost.png'):
        if os.path.exists(R + old): os.remove(R + old)

emit_gear()
