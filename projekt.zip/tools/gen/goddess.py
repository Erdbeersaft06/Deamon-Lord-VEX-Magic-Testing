"""Solara / Lunara / Eklipsa (Fusion) – detailreiche Modelle im Blockbench-Stil."""
import math
from lib import *

PI = math.pi

PAL = {
    'sol': dict(robe='#F7EBCB', robe2='#E9CB8C', robe3='#FFF6DD', gold='#E9B93D', gold_hi='#FFE680', gold_dk='#A8731B', glow='#FFB02E',
                skin='#F6D5B4', skin2='#E8B994', hair='#FFD56B', hair2='#E8A92E', eye='#FF8A00', eye2='#FFF0B0', lip='#D9736B', accent='#E2562B',
                feather='#FFF7E2', feather2='#F2D58E', tip='#FFC94A'),
    'lun': dict(robe='#2C3070', robe2='#1B1D47', robe3='#4A4FA6', gold='#C9D3EE', gold_hi='#F2F6FF', gold_dk='#7C86B8', glow='#7FE9FF',
                skin='#DDDFF2', skin2='#B9BDDD', hair='#3A3F94', hair2='#B7C3F4', eye='#7FE9FF', eye2='#EAFDFF', lip='#7A5BC4', accent='#8E63E6',
                feather='#33387F', feather2='#5A4FB4', tip='#A98CFF'),
}


def faces(pal, kind, half=False):
    """Gesicht auf Vorderseite des Kopfes (10x10 Pixel)."""
    sk = rgb(pal['skin']); ey = rgb(pal['eye']); e2 = rgb(pal['eye2']); br = rgb(pal['hair2'] if kind == 'sol' else pal['hair']); lp = rgb(pal['lip'])
    sk2 = rgb(pal['skin2'])
    def face(a):
        H, W = a.shape[:2]
        def px(x, y, c, al=255):
            if 0 <= x < W and 0 <= y < H: a[y, x, :3] = c; a[y, x, 3] = al
        for x in (2, 3): px(x, 3, br)
        for x in (6, 7): px(x, 3, br)
        if kind == 'sol':
            for x in (2, 3): px(x, 4, e2); px(x, 5, ey)
            for x in (6, 7): px(x, 4, e2); px(x, 5, ey)
            px(1, 4, br); px(8, 4, br)
        else:   # schmale, leuchtende Augen
            for x in (1, 2, 3): px(x, 4, ey)
            for x in (6, 7, 8): px(x, 4, ey)
            px(2, 5, e2); px(7, 5, e2); px(0, 3, br); px(9, 3, br)
        px(4, 6, sk2); px(5, 6, sk2)
        px(1, 6, mix(sk, pal['accent'], 0.25)); px(8, 6, mix(sk, pal['accent'], 0.25))
        if not half: px(4, 8, lp); px(5, 8, lp)
    return face


class B:
    """Baukasten fuer eine Goettin; kann in einen bestehenden Baum bauen (Fusion)."""

    def __init__(s, root, kind, clip=None, sides=('l', 'r'), wside='r', halo=True, ob=0):
        s.do_halo = halo; s.ob = ob
        s.root = root; s.kind = kind; s.p = PAL[kind]; s.clip = clip; s.sides = sides; s.wside = wside; s.sol = kind == 'sol'
        s.parts = {q.name: q for q in root.walk()}

    def keep(s, xc):
        if s.clip is None: return True
        return xc <= 1e-6 if s.clip == 'neg' else xc > 1e-6

    def part(s, parent, name, piv, rot=(0, 0, 0)):
        if name in s.parts: return s.parts[name]
        q = parent.add(name, piv, rot); s.parts[name] = q; return q

    def cube(s, part, a, b, mat, clip=True, name=None):
        return part.cube(a, b, mat, name=name, clip=s.clip if clip else None)

    # --------------------------------------------------------------- Materialien
    def mats(s):
        p = s.p; sol = s.sol
        m = {}
        m['robe'] = Mat(p['robe'], pat='weave' if sol else 'stripe', grad=(1.10, 0.88))
        m['robe2'] = Mat(p['robe2'], pat='weave', grad=(1.08, 0.85))
        m['robe3'] = Mat(p['robe3'], grad=(1.05, 0.9), pat='weave')
        m['gold'] = Mat(p['gold'], pat='plate', pc=p['gold_hi'], grad=(1.15, 0.80), edge=0.25)
        m['golddk'] = Mat(p['gold_dk'], pat='plate', pc=p['gold'], grad=(1.1, 0.8))
        m['goldhi'] = Mat(p['gold_hi'], grad=(1.05, 0.9), edge=0.15)
        m['glow'] = Mat(p['glow'], glow=p['gold_hi'] if sol else '#FFFFFF', grad=(1.05, 0.95), edge=0.08, noise=4)
        m['skin'] = Mat(p['skin'], grad=(1.04, 0.94), noise=3, edge=0.10)
        m['hair'] = Mat(p['hair'], pat='stripe', pc=p['hair2'], grad=(1.15, 0.80), noise=9, edge=0.12)
        m['hair2'] = Mat(p['hair2'], pat='stripe', grad=(1.12, 0.82), noise=8)
        m['head'] = Mat(p['skin'], grad=(1.04, 0.95), noise=3, edge=0.08, custom={'N': faces(p, s.kind, s.clip is not None)})
        m['feather'] = Mat(p['feather'], pat='feather', pc=p['feather2'], tip='v', grad=(1.10, 0.82), edge=0.10, noise=5)
        m['feather2'] = Mat(p['feather2'], pat='feather', pc=p['feather'], tip='v', grad=(1.08, 0.80), edge=0.10, noise=5)
        m['feather3'] = Mat(p['tip'], pat='feather', pc=p['feather'], tip='v', grad=(1.12, 0.78), edge=0.10, noise=5)
        m['bone'] = Mat(p['gold'] if sol else p['gold_dk'], pat='plate', pc=p['gold_hi'], grad=(1.1, 0.8))
        m['cape'] = Mat(p['robe2'] if not sol else p['robe3'], pat='weave' if sol else 'stars', pc=p['gold_hi'], grad=(1.05, 0.78), edge=0.15)
        m['cape2'] = Mat(p['robe'] if not sol else p['robe'], pat='weave' if sol else 'stars', pc=p['gold_hi'], grad=(1.05, 0.78), edge=0.15, tip='v')
        m['trimcape'] = Mat(p['gold'], pat='plate', pc=p['gold_hi'])
        return m

    # --------------------------------------------------------------- Teile
    def build(s):
        p = s.p; sol = s.sol; M = s.mats(); all_ = s.root
        body = s.part(all_, 'body', (0, 41, 0))
        # --- Torso
        s.cube(body, (-4.5, 41, -3), (4.5, 49.5, 3), M['robe'])
        s.cube(body, (-5.4, 49.5, -3.5), (5.4, 57, 3.5), M['robe3'] if sol else M['robe'])
        s.cube(body, (-4.8, 44.4, -3.5), (4.8, 46.6, 3.5), M['gold'], clip=True)       # Guertel
        s.cube(body, (-1.7, 57, -1.7), (1.7, 60, 1.7), M['skin'])                        # Hals
        s.cube(body, (-6.6, 55, -3.2), (6.6, 58, 3.2), M['gold'])                        # Schulterjoch
        s.cube(body, (-5.0, 50.5, -3.9), (5.0, 54.5, -3.5), M['robe2'] if sol else M['robe3'])  # Brustblende
        s.cube(body, (-1.8, 50.4, -4.4), (1.8, 54.2, -3.9), M['glow'])                    # Brust-Emblem
        s.cube(body, (-0.7, 44, -4.0), (0.7, 47, -3.5), M['goldhi'])                      # Guertelschnalle
        # Rueckenplatte
        s.cube(body, (-4.5, 47, 3.0), (4.5, 56, 3.9), M['gold'])
        # --- Rock (Stufen)
        sk = s.part(all_, 'skirt', (0, 41, 0))
        tiers = [(41, 36, 6.2), (36, 31, 7.6), (31, 26, 9.2), (26, 20.5, 10.8), (20.5, 15, 12.4), (15, 9.5, 14.0), (9.5, 4, 15.6)]
        for i, (y1, y0, hw) in enumerate(tiers):
            hd = hw * 0.78
            mm = M['robe'] if i % 2 == 0 else M['robe3']
            s.cube(sk, (-hw, y0, -hd), (hw, y1, hd), mm)
            s.cube(sk, (-hw - 0.4, y0 - 0.2, -hd - 0.4), (hw + 0.4, y0 + 1.0, hd + 0.4), M['gold'])      # Saum
            s.cube(sk, (-2.6, y0 + 0.4, -hd - 0.9), (2.6, y1 - 0.6, -hd - 0.1), M['robe2'] if sol else M['robe3'])  # Frontbahn
            for sx in (-1, 1):                                                                   # Eckzacken
                s.cube(sk, (sx * (hw + 0.6) - 1.2, y0 - 1.4, -hd - 1.0), (sx * (hw + 0.6) + 1.2, y0 + 0.4, -hd + 1.4), M['goldhi'])
                s.cube(sk, (sx * (hw + 0.6) - 1.2, y0 - 1.4, hd - 1.4), (sx * (hw + 0.6) + 1.2, y0 + 0.4, hd + 1.0), M['goldhi'])
        # Rocksaum-Zierleiste Front
        s.cube(sk, (-0.8, 4.6, -hd - 1.3), (0.8, 40, -hd - 0.9), M['goldhi'], clip=True) if False else None
        # --- Kopf
        head = s.part(body, 'head', (0, 58, 0))
        s.cube(head, (-4.75, 58.5, -4.5), (4.75, 68, 4.5), M['head'])
        # Haarkappe (Front frei)
        s.cube(head, (-5.2, 67.0, -5.0), (5.2, 69.6, 5.2), M['hair'])
        s.cube(head, (-5.2, 59.0, 3.0), (5.2, 69.6, 5.2), M['hair'])
        s.cube(head, (-5.4, 60.5, -4.9), (-4.6, 69.4, 4.6), M['hair'])
        s.cube(head, (4.6, 60.5, -4.9), (5.4, 69.4, 4.6), M['hair'])
        for (x0, x1, ln) in ((-4.8, -3.0, 3.2), (-3.0, -1.0, 4.6), (-1.0, 1.0, 3.4), (1.0, 3.0, 4.6), (3.0, 4.8, 3.2)):   # Pony
            s.cube(head, (x0, 68.2 - ln, -5.2), (x1, 69.6, -4.5), M['hair'])
        for sx in (-1, 1):   # Seitenstraehnen
            s.cube(head, (sx * 5.6 - 0.9, 50.5, -3.4), (sx * 5.6 + 0.9, 64, -0.8), M['hair2'])
            s.cube(head, (sx * 5.6 - 0.9, 46.5, -3.0), (sx * 5.6 + 0.9, 50.5, -1.2), M['hair'])
        # Ohr-Schmuck
        for sx in (-1, 1): s.cube(head, (sx * 4.8 - 0.4, 61.0, -0.8), (sx * 4.8 + 0.4, 64.4, 0.8), M['glow'])
        # langes Haar hinten
        hair = s.part(head, 'hair', (0, 66, 5.0))
        s.cube(hair, (-5.0, 48, 4.4), (5.0, 66, 7.4), M['hair'])
        hair2 = s.part(hair, 'hair2', (0, 48, 5.8))
        s.cube(hair2, (-4.6, 36, 4.6), (4.6, 48, 7.0), M['hair2'])
        hair3 = s.part(hair2, 'hair3', (0, 36, 5.8))
        L = 12 if sol else 22
        s.cube(hair3, (-3.2, 36 - L, 4.9), (3.2, 36, 6.8), M['hair'])
        # --- Krone / Tiara
        crown = s.part(head, 'crown', (0, 68.5, 0))
        if sol:
            n = 9
            for i in range(n):
                phi = -1.25 + 2.5 * i / (n - 1)
                mxc = math.sin(phi) * 5
                if not s.keep(mxc): continue
                q = s.part(crown, 'cr%d_%s' % (i, s.kind), (0, 68.6, -1.2), (0, 0, phi))
                Lh = 7.5 - abs(phi) * 2.4
                s.cube(q, (-0.9, 69.0, -2.0), (0.9, 69.0 + Lh * 0.55, -0.4), M['gold'], clip=False)
                s.cube(q, (-0.55, 69.0 + Lh * 0.55, -1.8), (0.55, 69.0 + Lh, -0.6), M['goldhi'], clip=False)
            s.cube(crown, (-5.3, 68.6, -5.2), (5.3, 70.0, -4.4), M['gold'])    # Stirnreif
            s.cube(crown, (-1.0, 66.8, -5.5), (1.0, 69.2, -4.9), M['glow'])
        else:
            s.cube(crown, (-5.3, 68.6, -5.2), (5.3, 69.9, -4.4), M['gold'])
            n = 7
            for i in range(n):
                phi = -1.1 + 2.2 * i / (n - 1)
                mxc = math.sin(phi) * 5
                if not s.keep(mxc): continue
                q = s.part(crown, 'cr%d_%s' % (i, s.kind), (0, 68.6, -1.2), (0, 0, phi))
                Lh = 4.5 + 3.5 * math.cos(phi * 1.2) - (2.5 if i % 2 else 0)
                s.cube(q, (-0.7, 69.0, -2.0), (0.7, 69.0 + Lh, -0.8), M['gold'], clip=False)
            s.cube(crown, (-1.3, 67.2, -5.6), (1.3, 70.4, -4.9), M['glow'])
        # --- Arme
        for side in s.sides:
            sx = -1 if side == 'l' else 1
            ph = 1 if side == 'l' else -1   # Vorzeichen fuer zRot (nach aussen)
            ax = sx * 7.4
            arm = s.part(body, 'arm_' + side, (ax, 55.5, 0))
            s.cube(arm, (ax - 1.8, 45, -1.8), (ax + 1.8, 56, 1.8), M['robe3'] if sol else M['robe2'], clip=False)
            # Schulterpanzer
            s.cube(arm, (ax - 4.2, 55.5, -3.6), (ax + 4.2, 58.4, 3.6), M['gold'], clip=False)
            s.cube(arm, (ax - 3.6 + sx * 0.8, 58.4, -3.0), (ax + 3.6 + sx * 0.8, 60.2, 3.0), M['golddk'], clip=False)
            if sol:
                for j, o in enumerate((-2.0, 0.0, 2.0)):
                    s.cube(arm, (ax + sx * 2.8 - 0.8, 60.2, o - 0.8), (ax + sx * 2.8 + 0.8, 63.8 - abs(o) * 0.5, o + 0.8), M['goldhi'], clip=False)
            else:
                s.cube(arm, (ax + sx * 2.2 - 0.9, 60.2, -1.5), (ax + sx * 2.2 + 0.9, 63.0, 1.5), M['gold'], clip=False)
                s.cube(arm, (ax + sx * 3.6 - 0.8, 62.4, -1.2), (ax + sx * 3.6 + 0.8, 66.0, 1.2), M['goldhi'], clip=False)
            fa = s.part(arm, 'forearm_' + side, (ax, 45.5, 0))
            s.cube(fa, (ax - 2.9, 38, -2.9), (ax + 2.9, 46.2, 2.9), M['robe'], clip=False)         # Glockenaermel
            s.cube(fa, (ax - 2.1, 33.8, -2.1), (ax + 2.1, 38.4, 2.1), M['gold'], clip=False)       # Armschiene
            s.cube(fa, (ax - 1.5, 30.6, -1.5), (ax + 1.5, 33.8, 1.5), M['skin'], clip=False)        # Hand
            s.cube(fa, (ax - 3.3, 37.4, -3.3), (ax + 3.3, 38.8, 3.3), M['goldhi'], clip=False)      # Saum
            if side == s.wside:
                s.weapon(fa, ax, 31.6)
        # --- Fluegel
        for side in s.sides:
            sx = -1 if side == 'l' else 1
            th = 1 if side == 'l' else -1
            wx = sx * 3.2
            wing = s.part(body, 'wing_' + side, (wx, 53, 5.2), (0, th * 0.5, 0))
            s.wing(wing, side, sx, th, wx, 53, 5.2, M)
        # --- Umhang
        cape = s.part(body, 'cape', (0, 57, 4.4))
        cw = 7.2 if not sol else 6.0
        s.cube(cape, (-cw, 40, 3.9), (cw, 57, 5.1), M['cape'])
        s.cube(cape, (-cw - 0.4, 40, 3.7), (-cw + 0.8, 57, 5.3), M['trimcape']) if False else None
        s.cube(cape, (-cw, 55.6, 3.7), (cw, 57.4, 5.3), M['trimcape'])
        c2 = s.part(cape, 'cape2', (0, 40, 4.6))
        s.cube(c2, (-cw - 0.6, 24, 4.1), (cw + 0.6, 40, 5.1), M['cape'])
        c3 = s.part(c2, 'cape3', (0, 24, 4.6))
        s.cube(c3, (-cw - 1.2, 6 if not sol else 10, 4.2), (cw + 1.2, 24, 5.0), M['cape2'])
        if sol:   # Sonnen-Emblem auf dem Mantel
            s.cube(cape, (-2, 46, 5.0), (2, 50, 5.5), M['glow'])
        # --- Heiligenschein
        halo = s.part(all_, 'halo', (0, 70.5, 8.5))
        if s.do_halo: s.halo(halo, M)
        # leere Zweit-Aura (fuer Fusion gefuellt)
        s.part(all_, 'halo2', (0, 70.5, 6.8))
        # --- Orbs
        for i in range(3):
            o = s.part(all_, 'orb%d' % (i + s.ob), (0, 56, 0), (0.6, 0.6, 0.3))
            s.cube(o, (-1.8, 54.2, -1.8), (1.8, 57.8, 1.8), M['glow'], clip=False)
            s.cube(o, (-0.7, 52.6, -0.7), (0.7, 59.4, 0.7), M['goldhi'], clip=False)
        return s

    # --------------------------------------------------------------- Waffe
    def weapon(s, fa, ax, hy):
        sol = s.sol; M = s.mats()
        w = s.part(fa, 'weapon_' + s.wside, (ax, hy, 0), (1.3, 0, 0))
        s.cube(w, (ax - 0.8, hy - 22, -0.8), (ax + 0.8, hy + 44, 0.8), M['bone'], clip=False)           # Schaft
        s.cube(w, (ax - 1.3, hy - 1.8, -1.3), (ax + 1.3, hy + 1.8, 1.3), M['goldhi'], clip=False)       # Griffwulst
        top = hy + 44
        if sol:
            s.cube(w, (ax - 2.2, top, -2.2), (ax + 2.2, top + 4.4, 2.2), M['glow'], clip=False)
            for k in range(8):
                ang = k * PI / 4
                q = s.part(w, 'ray%d_%s' % (k, s.wside), (ax, top + 2.2, 0), (0, 0, ang))
                Lr = 8.5 if k % 2 == 0 else 5.2
                s.cube(q, (ax - 0.9, top + 4.0, -0.9), (ax + 0.9, top + 4.0 + Lr, 0.9), M['gold'] if k % 2 else M['goldhi'], clip=False)
            s.cube(w, (ax - 3.2, top - 3.4, -1.0), (ax + 3.2, top - 1.6, 1.0), M['gold'], clip=False)
        else:
            cy = top + 5.0; R = 6.5
            n = 11
            for k in range(n):
                ang = 0.8 + (2 * PI - 1.6) * k / (n - 1)
                tcur = 0.9 + 2.2 * math.sin(PI * k / (n - 1))
                q = s.part(w, 'moon%d_%s' % (k, s.wside), (ax, cy, 0), (0, 0, ang))
                s.cube(q, (ax - 1.7, cy + R, -1.0), (ax + 1.7, cy + R + tcur, 1.0), M['goldhi'] if k % 3 == 1 else M['gold'], clip=False)
            s.cube(w, (ax - 1.8, cy - 1.8, -1.8), (ax + 1.8, cy + 1.8, 1.8), M['glow'], clip=False)
            s.cube(w, (ax - 1.2, top - 3, -1.2), (ax + 1.2, top + 1.0, 1.2), M['gold'], clip=False)

    # --------------------------------------------------------------- Fluegel
    def wing(s, wing, side, sx, th, wx, wy, wz, M):
        sol = s.sol
        s.cube(wing, (wx + sx * 0.0 - 1.2, wy - 2, wz - 0.8), (wx + sx * 14 + 1.2 * 0, wy + 3, wz + 0.8), M['bone'], clip=False)
        rows = []
        if sol:
            rows = [('a', [0.55, 0.80, 1.05, 1.30, 1.55, 1.80], [26, 31, 36, 39, 38, 33], 6.4, 'feather', 0.0),
                    ('b', [0.68, 0.95, 1.22, 1.49, 1.76], [19, 23, 26, 26, 22], 5.6, 'feather2', -0.9),
                    ('c', [0.80, 1.20, 1.60], [12, 15, 13], 5.0, 'feather3', -1.8)]
        else:
            rows = [('a', [0.75, 1.10, 1.45, 1.80, 2.15], [30, 39, 45, 41, 32], 5.0, 'feather', 0.0),
                    ('b', [0.90, 1.27, 1.64, 2.00], [22, 28, 30, 24], 5.2, 'feather2', -0.9),
                    ('c', [1.05, 1.55, 2.00], [14, 17, 14], 5.0, 'feather3', -1.8)]
        for (nm, angs, lens, wd, mk, zo) in rows:
            row = s.part(wing, 'w%s_%s' % (nm, side), (wx, wy, wz))
            for i, (a, L) in enumerate(zip(angs, lens)):
                q = s.part(row, 'f%s%d_%s' % (nm, i, side), (wx, wy, wz + zo), (0, 0, th * a))
                s.cube(q, (wx - wd / 2, wy - L, wz + zo - 0.6), (wx + wd / 2, wy, wz + zo + 0.6), M[mk], clip=False)

    # --------------------------------------------------------------- Heiligenschein
    def halo(s, halo, M):
        sol = s.sol
        cx, cy, cz = 0, 70.5, 8.5
        if sol:
            n = 20; R = 12.5
            for k in range(n):
                ang = 2 * PI * k / n
                if not s.keep(0.0 if s.clip is None else 0.0): pass
                q = s.part(halo, 'hr%d' % k, (cx, cy, cz), (0, 0, ang))
                s.cube(q, (-2.5, cy + R, cz - 0.7), (2.5, cy + R + 1.8, cz + 0.7), M['gold'] if k % 2 else M['goldhi'], clip=False)
                Lr = 7.0 if k % 2 == 0 else 3.6
                s.cube(q, (-0.9, cy + R + 1.8, cz - 0.6), (0.9, cy + R + 1.8 + Lr, cz + 0.6), M['goldhi'] if k % 2 == 0 else M['glow'], clip=False)
        else:
            n = 12; R = 11.0
            for k in range(n):
                ang = 0.9 + (2 * PI - 1.8) * k / (n - 1)
                tcur = 0.9 + 3.4 * math.sin(PI * k / (n - 1))
                q = s.part(halo, 'hm%d' % k, (cx, cy, cz), (0, 0, ang))
                s.cube(q, (-2.1, cy + R, cz - 0.7), (2.1, cy + R + tcur, cz + 0.7), M['gold'] if k % 2 else M['goldhi'], clip=False)
            for k, (ox, oy) in enumerate(((13, 9), (-14, 4), (9, -12), (-9, 14))):
                q = s.part(halo, 'hs%d' % k, (cx + ox, cy + oy, cz), (0, 0, 0.78))
                s.cube(q, (cx + ox - 1.1, cy + oy - 1.1, cz - 0.6), (cx + ox + 1.1, cy + oy + 1.1, cz + 0.6), M['glow'], clip=False)


def build_goddess(kind):
    root = Part('all', (0, 0, 0))
    B(root, kind).build()
    return root


def build_fusion():
    root = Part('all', (0, 0, 0))
    B(root, 'sol', clip='neg', sides=('l',), wside='l').build()
    lb = B(root, 'lun', clip='pos', sides=('r',), wside='r', halo=False, ob=3).build()
    # zweite Aura: Mond-Sichel innerhalb des Sonnenrings
    M = lb.mats(); h2 = lb.parts['halo2']
    cx, cy, cz = 0, 70.5, 6.8
    n = 12; R = 7.2
    for k in range(n):
        ang = 0.9 + (2 * PI - 1.8) * k / (n - 1)
        tcur = 0.9 + 3.0 * math.sin(PI * k / (n - 1))
        q = h2.add('hm%d' % k, (cx, cy, cz), (0, 0, ang))
        q.cube((-1.9, cy + R, cz - 0.7), (1.9, cy + R + tcur, cz + 0.7), M['gold'] if k % 2 else M['goldhi'])
    return root
