# Modell-Generator

`python3 tools/gen/build.py` erzeugt alle Boss-Modelle (JSON), Texturen (PNG) und .bbmodel-Dateien neu.
Benoetigt Python 3 mit `numpy` und `Pillow`. Das Ergebnis landet in `src/client/resources/assets/daemonenlord/` und `modelle/`.

- `goddess.py`: Solara, Lunara und Eklipsa (Fusion = linke Haelfte Solara, rechte Haelfte Lunara)
- `demon.py`: Daemonenlord (3 Farbvarianten: normal, rot, blau)
- `lib.py`: Part-Baum, Materialien/Texturmalerei, Export (JSON, .bbmodel), Vorschau-Renderer
