import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from lib import *
import gear as G
from PIL import Image
out = sys.argv[1] if len(sys.argv) > 1 else '/tmp/work/gear_prev.png'
ims = []
for sets in (('t',), ('g',)):
    root = G.build_gear(sets, mannequin=True)
    W, H = pack(root, 1024); M = to_json(root, W, H); atl = paint_atlas(root, W, H)
    for yaw in (150, 0, 70):
        im, (lo, hi) = render(M, atl, yaw=yaw, pitch=-5, W=460, H=640)
        ims.append(im)
sheet = Image.new('RGB', (460 * 3, 640 * 2))
for i, im in enumerate(ims): sheet.paste(im, ((i % 3) * 460, (i // 3) * 640))
os.makedirs(os.path.dirname(out), exist_ok=True); sheet.save(out); print(out)
