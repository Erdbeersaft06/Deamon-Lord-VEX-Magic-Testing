"""Custom-Ruestungen (3D) und Schwerter im Blockbench-Stil.
Set 't' = Ehrwuerdiger Kriegspanzer (Tank), Set 'g' = Himmlischer Mantel (Glascannon).
Skelett: all -> head, body, arm_r (-x), arm_l (+x), leg_r (-x), leg_l (+x); Teile je Set: t_/g_ + helm|chest|arm|thigh|boot (+cape, wing)."""
import math
from lib import *

PI = math.pi

TP = dict(plate='#E9E1CC', plate2='#CDC3A9', gold='#D9A63A', gold_hi='#FFD97A', gold_dk='#8F6418',
          steel='#3B4157', steel2='#232739', crimson='#8E1F2D', crimson2='#5C1020', glow='#7FE6FF')
GP = dict(pearl='#F4F2FA', pearl2='#D9D6EC', pearl3='#B4B0D6', gold='#E6B84A', gold_hi='#FFEBA6', gold_dk='#A97D1F',
          blue='#4FB3F5', glow='#B9F3FF', dark='#585A8E', feather='#F8F7FF', feather2='#C9C6EA')


def leaf(power=3.0):
    """Feder-Form: Superellipse (Alpha) auf den grossen Flaechen."""
    def f(a):
        H, W = a.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W]
        cx, cy = (W - 1) / 2.0, (H - 1) / 2.0
        r = (np.abs(xx - cx) / (W / 2.0)) ** power + (np.abs(yy - cy) / (H / 2.0)) ** 2
        a[..., 3] = np.where(r > 1.02, 0, a[..., 3])
    return f


def emblem(col, col2):
    """kleines Kreuz-/Rautenzeichen in der Mitte einer Flaeche"""
    c1, c2 = rgb(col), rgb(col2)
    def f(a):
        H, W = a.shape[:2]
        cx, cy = W // 2, H // 2
        for dy in range(-3, 4):
            for dx in range(-3, 4):
                d = abs(dx) + abs(dy)
                x, y = cx + dx, cy + dy
                if 0 <= x < W and 0 <= y < H:
                    if d == 0: a[y, x, :3] = c2
                    elif d <= 2 and (dx == 0 or dy == 0): a[y, x, :3] = c1
    return f


def visor(cglow, cdark):
    cg, cd = rgb(cglow), rgb(cdark)
    def f(a):
        H, W = a.shape[:2]
        a[:, :, :3] = cd
        for x in range(1, W - 1):
            if 1 <= H // 2 < H: a[H // 2, x, :3] = tuple(int(c * 0.6) for c in cg)
        for xs in (range(1, max(2, W // 2 - 1)), range(W - max(2, W // 2 - 1) , W - 1)):
            for x in xs:
                for y in range(max(0, H // 2 - 1), min(H, H // 2 + 1)):
                    a[y, x, :3] = cg
    return f


def mats_t():
    p = TP
    m = {}
    m['plate'] = Mat(p['plate'], pat='plate', pc=p['gold'], grad=(1.10, 0.84), edge=0.22)
    m['plate2'] = Mat(p['plate2'], pat='plate', pc=p['gold_dk'], grad=(1.08, 0.82), edge=0.22)
    m['gold'] = Mat(p['gold'], pat='plate', pc=p['gold_hi'], grad=(1.15, 0.80), edge=0.25)
    m['goldhi'] = Mat(p['gold_hi'], grad=(1.05, 0.9), edge=0.15)
    m['golddk'] = Mat(p['gold_dk'], pat='plate', pc=p['gold'], grad=(1.1, 0.8))
    m['steel'] = Mat(p['steel'], pat='weave', pc=p['steel2'], grad=(1.15, 0.8), edge=0.2)
    m['steel2'] = Mat(p['steel2'], grad=(1.1, 0.85), edge=0.15)
    m['crim'] = Mat(p['crimson'], pat='weave', grad=(1.10, 0.78), edge=0.15, trim=p['gold'])
    m['crim2'] = Mat(p['crimson2'], pat='stripe', grad=(1.08, 0.80), edge=0.15)
    m['glow'] = Mat(p['glow'], glow='#FFFFFF', grad=(1.05, 0.95), edge=0.08, noise=4)
    m['chest'] = Mat(p['plate'], pat='plate', pc=p['gold'], grad=(1.10, 0.84), edge=0.22,
                     custom={'N': emblem(p['gold'], p['glow'])})
    m['visor'] = Mat(p['steel2'], custom={'N': visor(p['glow'], p['steel2'])})
    return m


def mats_g():
    p = GP
    m = {}
    m['pearl'] = Mat(p['pearl'], pat='weave', pc=p['pearl2'], grad=(1.06, 0.88), edge=0.14, noise=5)
    m['pearl2'] = Mat(p['pearl2'], pat='weave', pc=p['pearl3'], grad=(1.06, 0.86), edge=0.14, noise=5)
    m['pearl3'] = Mat(p['pearl3'], pat='stripe', grad=(1.06, 0.84), edge=0.14)
    m['gold'] = Mat(p['gold'], pat='plate', pc=p['gold_hi'], grad=(1.15, 0.80), edge=0.25)
    m['goldhi'] = Mat(p['gold_hi'], grad=(1.05, 0.9), edge=0.15)
    m['golddk'] = Mat(p['gold_dk'], pat='plate', pc=p['gold'], grad=(1.1, 0.8))
    m['blue'] = Mat(p['blue'], glow=p['glow'], grad=(1.05, 0.95), edge=0.10, noise=4)
    m['glow'] = Mat(p['glow'], glow='#FFFFFF', grad=(1.05, 0.95), edge=0.08, noise=4)
    m['dark'] = Mat(p['dark'], pat='weave', grad=(1.1, 0.8), edge=0.15)
    m['feather'] = Mat(p['feather'], pat='feather', pc=p['feather2'], grad=(1.08, 0.86), edge=0.10, noise=5, custom={'N': leaf(3.0), 'S': leaf(3.0)})
    m['feather2'] = Mat(p['feather2'], pat='feather', pc=p['feather'], grad=(1.08, 0.84), edge=0.10, noise=5, custom={'N': leaf(3.0), 'S': leaf(3.0)})
    m['featherg'] = Mat(p['gold_hi'], pat='feather', pc=p['gold'], grad=(1.10, 0.84), edge=0.10, noise=5, custom={'N': leaf(3.0), 'S': leaf(3.0)})
    m['chest'] = Mat(p['pearl'], pat='weave', pc=p['pearl2'], grad=(1.06, 0.88), edge=0.14,
                     custom={'N': emblem(p['gold'], p['blue'])})
    return m


# ------------------------------------------------------------------ Ruestung "Ehrwuerdiger Kriegspanzer"
def build_tank(R, sk):
    M = mats_t()
    head, body, arm = sk['head'], sk['body'], {-1: sk['arm_r'], 1: sk['arm_l']}
    leg = {-1: sk['leg_r'], 1: sk['leg_l']}
    # ---- Helm
    h = head.add('t_helm', (0, 24, 0))
    h.cube((-4.7, 23.6, -4.7), (4.7, 32.6, 4.7), M['plate'])
    h.cube((-4.9, 23.2, -4.9), (4.9, 24.6, 4.9), M['gold'])             # Rand unten
    h.cube((-4.2, 26.4, -4.95), (4.2, 29.2, -4.55), M['visor'])          # Sichtschlitz
    h.cube((-4.9, 29.2, -5.0), (4.9, 30.4, -4.3), M['gold'])             # Stirnband
    h.cube((-0.7, 24.0, -5.1), (0.7, 29.4, -4.6), M['golddk'])           # Nasensteg
    h.cube((-0.7, 32.6, -4.8), (0.7, 35.0, 4.6), M['gold'])              # Kamm
    h.cube((-0.5, 35.0, -2.8), (0.5, 36.6, 2.6), M['goldhi'])
    for sx in (-1, 1):
        h.cube((sx * 4.7, 24.0, -4.4), (sx * 5.4, 28.6, -1.6), M['plate2'])   # Wangenschutz
        h.cube((sx * 4.7, 24.0, 1.4), (sx * 5.4, 27.0, 4.6), M['plate2'])
        # Fluegelhoerner
        for i, (L, ang, y) in enumerate(((5.2, 0.55, 30.0), (4.2, 0.95, 31.0), (3.2, 1.35, 32.0))):
            w = h.add('t_hw%d_%s' % (i, 'l' if sx > 0 else 'r'), (sx * 4.9, y, 0.0), (0.0, sx * -0.35, -sx * ang))
            w.cube((sx * 4.9, y - 0.7, -2.2), (sx * (4.9 + L), y + 0.7, 2.2), M['gold'] if i != 1 else M['plate'])
    # ---- Brust
    c = body.add('t_chest', (0, 24, 0))
    c.cube((-4.7, 12.2, -2.7), (4.7, 24.4, 2.7), M['chest'])
    c.cube((-4.9, 11.6, -2.9), (4.9, 13.2, 2.9), M['gold'])              # Guertel
    c.cube((-1.2, 11.8, -3.1), (1.2, 13.0, -2.8), M['glow'])             # Gurtelschnalle
    c.cube((-3.6, 24.2, -3.3), (3.6, 25.6, 3.3), M['gold'])              # Halsberge
    c.cube((-5.0, 22.2, -3.0), (5.0, 24.4, 3.0), M['plate2'])            # Schulterjoch
    c.cube((-0.5, 12.2, -3.0), (0.5, 24.2, -2.75), M['golddk'])          # Mittelnaht
    c.cube((-5.4, 3.0, 2.7), (5.4, 24.6, 4.0), M['plate2'])              # Rueckenplatte
    c.cube((-3.4, 8.0, 3.9), (3.4, 22.0, 4.6), M['gold'])                # Ruecken-Zierplatte
    c.cube((-1.2, 15.0, 4.5), (1.2, 19.5, 4.9), M['glow'])
    # Tabard vorne
    c.cube((-2.6, 4.0, -3.1), (2.6, 12.0, -2.7), M['crim'])
    c.cube((-0.4, 4.0, -3.2), (0.4, 12.0, -3.05), M['gold'])
    # Umhang (schwingt)
    cp = c.add('t_cape', (0, 24.0, 4.0), (0.12, 0, 0))
    cp.cube((-5.2, 6.0, 3.9), (5.2, 24.0, 4.9), M['crim'])
    cp.cube((-5.2, 5.0, 3.9), (5.2, 6.0, 4.9), M['gold'])
    cp2 = cp.add('t_cape2', (0, 6.0, 4.4), (0.12, 0, 0))
    cp2.cube((-4.6, -1.0, 4.0), (4.6, 6.0, 4.8), M['crim2'])
    cp2.cube((-4.6, -1.4, 4.0), (4.6, -0.2, 4.8), M['gold'])
    # ---- Arme (Schulter + Schienen)
    for sx in (-1, 1):
        a = arm[sx].add('t_arm', (sx * 5, 22, 0))
        s = sx
        # Schulterkoller: drei geneigte Platten
        for i, (w_, y0, tilt, mat) in enumerate(((6.4, 24.2, 0.18, M['plate']), (6.9, 22.8, 0.28, M['plate2']), (7.4, 21.2, 0.38, M['plate']))):
            sp = a.add('t_sh%d' % i, (s * 5.0, 24.6, 0.0), (0, 0, s * -tilt))
            sp.cube((s * 2.2, y0 - 0.2, -3.6), (s * (2.2 + w_), y0 + 2.2, 3.6), mat)
        a.cube((s * 7.6, 20.4, -3.6), (s * 8.5, 25.0, 3.6), M['gold'])      # Schulterkante
        a.cube((s * 5.6, 25.0, -0.9), (s * 6.4, 27.4, 0.9), M['goldhi'])     # Schulterdorn
        a.cube((s * 3.4, 14.8, -2.9), (s * 8.5, 21.0, 2.9), M['plate'])      # Oberarm
        a.cube((s * 3.2, 14.2, -3.1), (s * 8.7, 15.6, 3.1), M['gold'])       # Ellbogen
        a.cube((s * 3.3, 11.6, -2.8), (s * 8.6, 14.4, 2.8), M['steel'])      # Unterarm
        a.cube((s * 3.2, 11.8, -3.0), (s * 8.8, 12.8, 3.0), M['gold'])       # Manschette
        a.cube((s * 7.6, 12.0, -1.5), (s * 9.0, 18.0, 1.5), M['plate2'])     # Aussenplatte
    # ---- Beine
    for sx in (-1, 1):
        xc = sx * 1.9
        t = leg[sx].add('t_thigh', (xc, 12, 0))
        t.cube((xc - 2.5, 5.6, -2.7), (xc + 2.5, 12.4, 2.7), M['plate'])
        t.cube((xc - 2.7, 5.0, -3.0), (xc + 2.7, 6.6, 3.0), M['gold'])      # Knie
        t.cube((xc - 2.4, 5.0, -3.4), (xc + 2.4, 7.2, -2.8), M['goldhi'])    # Kniekappe
        t.cube((xc + sx * 2.4, 7.2, -3.0), (xc + sx * 3.3, 12.6, 3.0), M['plate2'])
        # Beintasche / Tasset (haengt von der Huefte)
        tp = t.add('t_tas', (xc, 12.4, -3.0), (0.0, 0, sx * -0.05))
        tp.cube((xc - 2.4, 7.0, -3.5), (xc + 2.4, 12.4, -3.0), M['crim'])
        tp.cube((xc - 2.4, 6.6, -3.6), (xc + 2.4, 7.4, -3.0), M['gold'])
        b = leg[sx].add('t_boot', (xc, 12, 0))
        b.cube((xc - 2.6, -0.1, -2.8), (xc + 2.6, 5.4, 2.8), M['steel'])
        b.cube((xc - 2.8, 4.2, -3.0), (xc + 2.8, 5.6, 3.0), M['gold'])
        b.cube((xc - 2.5, -0.1, -4.0), (xc + 2.5, 2.2, -2.7), M['plate'])    # Kappe vorn
        b.cube((xc - 0.6, -0.1, -4.4), (xc + 0.6, 1.4, -3.9), M['goldhi'])
        b.cube((xc - 2.6, -0.2, -2.8), (xc + 2.6, 0.8, 2.8), M['golddk'])    # Sohle


# ------------------------------------------------------------------ Ruestung "Himmlischer Mantel"
def build_glass(R, sk):
    M = mats_g()
    head, body, arm = sk['head'], sk['body'], {-1: sk['arm_r'], 1: sk['arm_l']}
    leg = {-1: sk['leg_r'], 1: sk['leg_l']}
    # ---- Kopf: Reif, Schleier, Heiligenschein
    h = head.add('g_helm', (0, 24, 0))
    h.cube((-4.7, 29.2, -4.7), (4.7, 30.8, 4.7), M['gold'])             # Reif
    h.cube((-1.2, 29.0, -5.0), (1.2, 32.2, -4.6), M['gold'])            # Stirnzier
    h.cube((-0.6, 29.8, -5.2), (0.6, 31.4, -4.9), M['blue'])
    h.cube((-4.6, 23.8, 4.0), (4.6, 32.6, 5.0), M['pearl'])             # Schleier hinten
    h.cube((-5.0, 24.0, -4.5), (-4.4, 32.4, 4.6), M['pearl2'])         # Haube Seiten
    h.cube((4.4, 24.0, -4.5), (5.0, 32.4, 4.6), M['pearl2'])
    h.cube((-4.6, 32.4, -4.6), (4.6, 33.2, 4.6), M['pearl'])            # Haubendach
    for sx in (-1, 1):
        for i, (L, ang, y) in enumerate(((5.0, 0.50, 31.5), (4.0, 0.90, 32.6), (3.0, 1.30, 33.6))):
            w = h.add('g_hw%d_%s' % (i, 'l' if sx > 0 else 'r'), (sx * 4.9, y, 0.6), (0.0, sx * -0.55, -sx * ang))
            w.cube((sx * 4.9, y - 0.6, 0.0), (sx * (4.9 + L), y + 0.6, 2.4), M['featherg'] if i == 1 else M['feather'])
    # Heiligenschein: Ring aus 8 Boxen (schwebt)
    hl = h.add('g_halo', (0, 37.5, 0))
    for i in range(8):
        ang = i * PI / 4
        x, z = math.sin(ang) * 3.6, math.cos(ang) * 3.6
        q = hl.add('g_h%d' % i, (x, 37.5, z), (0, ang, 0))
        q.cube((x - 1.5, 37.2, z - 0.4), (x + 1.5, 38.0, z + 0.4), M['goldhi'] if i % 2 == 0 else M['gold'])
    # ---- Brust
    c = body.add('g_chest', (0, 24, 0))
    c.cube((-4.6, 12.4, -2.65), (4.6, 24.2, 2.65), M['chest'])
    c.cube((-4.8, 11.8, -2.85), (4.8, 13.0, 2.85), M['gold'])
    c.cube((-1.0, 15.0, -3.0), (1.0, 19.2, -2.7), M['blue'])
    c.cube((-0.4, 13.4, -2.95), (0.4, 24.2, -2.7), M['gold'])
    # Schulter-Mantel (Pelerine) mit Goldsaum
    c.cube((-6.6, 21.4, -3.6), (6.6, 24.8, 3.6), M['pearl2'])
    c.cube((-6.8, 20.6, -3.8), (6.8, 21.8, 3.8), M['gold'])
    c.cube((-3.8, 24.6, -3.4), (3.8, 26.0, 3.4), M['pearl'])            # Kragen
    c.cube((-3.8, 25.8, -3.5), (3.8, 26.4, 3.5), M['gold'])
    # Langer Mantel hinten (zwei Teile, schwingt)
    cp = c.add('g_cape', (0, 22.0, 3.0), (0.10, 0, 0))
    cp.cube((-5.2, 5.0, 2.6), (5.2, 22.0, 3.6), M['pearl'])
    cp.cube((-5.2, 4.2, 2.6), (5.2, 5.2, 3.6), M['gold'])
    cp.cube((-0.5, 6.0, 3.5), (0.5, 21.5, 3.8), M['gold'])
    cp2 = cp.add('g_cape2', (0, 5.0, 3.1), (0.10, 0, 0))
    cp2.cube((-4.6, -1.0, 2.7), (4.6, 5.0, 3.5), M['pearl2'])
    cp2.cube((-4.6, -1.4, 2.7), (4.6, -0.4, 3.5), M['gold'])
    # Fluegel
    for sx in (-1, 1):
        base = (sx * 2.6, 21.5, 3.9)
        wg = c.add('g_wing_' + ('l' if sx > 0 else 'r'), base)
        rows = ((11.0, 1.00, 0.70, 22.2, 'feather'), (13.0, 0.85, 0.66, 20.3, 'featherg'), (12.0, 0.68, 0.60, 18.4, 'feather'),
                (10.0, 0.50, 0.55, 16.6, 'feather2'), (8.0, 0.32, 0.50, 14.8, 'feather2'), (6.0, 0.16, 0.45, 13.0, 'feather2'))
        for i, (L, a, sw, y, mk) in enumerate(rows):
            f = wg.add('g_wf%d_%s' % (i, 'l' if sx > 0 else 'r'), (sx * 2.6, y, 3.9), (0.0, sx * -sw, -sx * a))
            f.cube((sx * 2.6, y - 1.25, 3.4), (sx * (2.6 + L), y + 1.25, 4.4), M[mk])
        # Federn zweite Lage (kleiner, ueber den ersten)
        for i, (L, a, sw, y, mk) in enumerate(((8.0, 1.0, 0.62, 23.0, 'feather2'), (9.0, 0.82, 0.58, 21.2, 'feather2'), (8.0, 0.60, 0.52, 19.4, 'feather'))):
            f = wg.add('g_wg%d_%s' % (i, 'l' if sx > 0 else 'r'), (sx * 2.6, y, 4.5), (0.0, sx * -sw, -sx * a))
            f.cube((sx * 2.6, y - 1.0, 4.4), (sx * (2.6 + L), y + 1.0, 5.2), M[mk])
        wg.cube((sx * 2.4, 19.5, 3.6), (sx * 3.6, 24.0, 4.8), M['gold'])      # Fluegelansatz
    # ---- Arme: weite Aermel
    for sx in (-1, 1):
        a = arm[sx].add('g_arm', (sx * 5, 22, 0))
        s = sx
        a.cube((s * 3.4, 15.2, -2.7), (s * 8.4, 21.6, 2.7), M['pearl'])
        a.cube((s * 3.2, 14.4, -3.0), (s * 8.7, 15.6, 3.0), M['gold'])
        a.cube((s * 3.4, 11.8, -2.9), (s * 8.6, 14.6, 2.9), M['pearl2'])    # Schulterung unten
        a.cube((s * 3.0, 10.8, -3.4), (s * 9.2, 12.4, 3.4), M['pearl'])      # weiter Aermelsaum
        a.cube((s * 3.0, 10.4, -3.5), (s * 9.3, 11.2, 3.5), M['gold'])
        a.cube((s * 5.2, 22.6, -1.0), (s * 6.6, 25.4, 1.0), M['blue'])        # Schulterkristall
        a.cube((s * 5.0, 22.2, -1.4), (s * 7.0, 23.0, 1.4), M['gold'])
        fe = a.add('g_ar_f', (s * 8.0, 20.0, 0.0), (0, 0, s * 0.35))
        fe.cube((s * 8.0, 15.0, -0.5), (s * 9.0, 21.0, 2.5), M['feather'])
    # ---- Beine: fliessender Rock + Stiefel
    for sx in (-1, 1):
        xc = sx * 1.9
        t = leg[sx].add('g_thigh', (xc, 12, 0))
        t.cube((xc - 2.5, 6.6, -2.7), (xc + 2.5, 12.4, 2.7), M['pearl'])
        t.cube((xc - 2.8, 5.8, -3.3), (xc + 2.8, 8.2, 3.3), M['pearl2'])
        t.cube((xc - 3.0, 5.2, -3.5), (xc + 3.0, 6.4, 3.5), M['gold'])
        tp = t.add('g_skirt', (xc, 12.4, -3.2), (0.0, 0, 0.0))
        tp.cube((xc - 2.4, 5.0, -3.7), (xc + 2.4, 12.4, -3.2), M['pearl3'])
        tp.cube((xc - 0.4, 5.4, -3.8), (xc + 0.4, 12.0, -3.65), M['gold'])
        b = leg[sx].add('g_boot', (xc, 12, 0))
        b.cube((xc - 2.6, -0.1, -2.8), (xc + 2.6, 5.6, 2.8), M['pearl'])
        b.cube((xc - 2.8, 4.4, -3.0), (xc + 2.8, 5.8, 3.0), M['gold'])
        b.cube((xc - 2.5, -0.1, -4.2), (xc + 2.5, 2.0, -2.7), M['pearl2'])
        b.cube((xc - 2.6, -0.2, -2.8), (xc + 2.6, 0.8, 2.8), M['gold'])
        fe = b.add('g_bf', (xc + sx * 2.6, 3.5, 0.0), (0, 0, sx * 0.5))
        fe.cube((xc + sx * 2.6, 2.0, -0.5), (xc + sx * 3.6, 8.0, 2.5), M['feather'])


def skeleton():
    root = Part('all', (0, 0, 0))
    sk = {'root': root}
    sk['head'] = root.add('head', (0, 24, 0))
    sk['body'] = root.add('body', (0, 24, 0))
    sk['arm_r'] = root.add('arm_r', (-5, 22, 0))
    sk['arm_l'] = root.add('arm_l', (5, 22, 0))
    sk['leg_r'] = root.add('leg_r', (-1.9, 12, 0))
    sk['leg_l'] = root.add('leg_l', (1.9, 12, 0))
    return sk


def build_gear(sets=('t', 'g'), mannequin=False):
    sk = skeleton()
    if 't' in sets: build_tank(sk['root'], sk)
    if 'g' in sets: build_glass(sk['root'], sk)
    if mannequin:   # nur fuer die Vorschau
        sm = Mat('#C99572', grad=(1.0, 0.9), noise=3, edge=0.1)
        sc = Mat('#3C5A7A', grad=(1.0, 0.9), noise=3, edge=0.1)
        sk['head'].cube((-4, 24, -4), (4, 32, 4), sm); sk['body'].cube((-4, 12, -2), (4, 24, 2), sc)
        sk['arm_r'].cube((-8, 12, -2), (-4, 24, 2), sc); sk['arm_l'].cube((4, 12, -2), (8, 24, 2), sc)
        sk['leg_r'].cube((-3.9, 0, -2), (0.1, 12, 2), Mat('#2F3A66')); sk['leg_l'].cube((-0.1, 0, -2), (3.9, 12, 2), Mat('#2F3A66'))
    return sk['root']


# ------------------------------------------------------------------ Schwerter (Item-Modelle, Item-Raum: x/z 0..16, y nach oben)
def mats_sword(kind):
    if kind == 'midas':
        g, gh, gd = '#E2AE35', '#FFE58C', '#8D5F14'
        return dict(
            blade=Mat('#F1D27A', pat='brush', pc='#FFF2B8', grad=(1.12, 0.84), edge=0.20),
            fuller=Mat('#B8851F', pat='stripe', grad=(1.1, 0.8), edge=0.15),
            edge=Mat('#FFF4C8', grad=(1.0, 0.92), edge=0.1, noise=3),
            gold=Mat(g, pat='plate', pc=gh, grad=(1.15, 0.8), edge=0.25),
            goldhi=Mat(gh, grad=(1.05, 0.9), edge=0.15),
            golddk=Mat(gd, pat='plate', pc=g, grad=(1.1, 0.8)),
            leather=Mat('#6E1D2A', pat='stripe', pc='#4A1019', grad=(1.1, 0.8), edge=0.2),
            gem=Mat('#FF5A3C', glow='#FFE3A0', grad=(1.05, 0.95), edge=0.1, noise=4))
    return dict(
        blade=Mat('#E8F4FF', pat='brush', pc='#FFFFFF', grad=(1.10, 0.86), edge=0.18),
        glow=Mat('#52DFFF', glow='#EFFFFF', grad=(1.05, 0.95), edge=0.05, noise=4),
        glow2=Mat('#2E9BE0', glow='#9AF0FF', grad=(1.05, 0.9), edge=0.1, noise=4),
        steel=Mat('#3A4259', pat='weave', pc='#272D40', grad=(1.15, 0.8), edge=0.2),
        steel2=Mat('#1D2232', grad=(1.1, 0.85), edge=0.15),
        silver=Mat('#B7C3D6', pat='plate', pc='#E8F0FA', grad=(1.12, 0.8), edge=0.2),
        violet=Mat('#8E5CFF', glow='#E3D2FF', grad=(1.05, 0.95), edge=0.1, noise=4))


def build_sword(kind):
    M = mats_sword(kind)
    root = Part('sword', (0, 0, 0)); p = root
    X0, Z0 = 8.0, 8.0
    def box(x0, y0, z0, x1, y1, z1, m): p.cube((x0, y0, z0), (x1, y1, z1), m)
    if kind == 'midas':
        # Knauf + Griff
        box(7.0, 0.0, 7.0, 9.0, 1.6, 9.0, M['gold']); box(7.4, 1.6, 7.4, 8.6, 2.4, 8.6, M['goldhi'])
        box(7.4, 2.4, 7.4, 8.6, 8.4, 8.6, M['leather'])
        for y in (3.6, 5.2, 6.8): box(7.3, y, 7.3, 8.7, y + 0.5, 8.7, M['gold'])
        # Parierstange (lang in z), Fluegel nach oben
        box(7.0, 8.4, 3.6, 9.0, 9.8, 12.4, M['gold'])
        box(7.2, 9.8, 3.0, 8.8, 11.2, 4.4, M['goldhi']); box(7.2, 9.8, 11.6, 8.8, 11.2, 13.0, M['goldhi'])
        box(7.3, 11.2, 2.6, 8.7, 12.4, 3.6, M['gold']); box(7.3, 11.2, 12.4, 8.7, 12.4, 13.4, M['gold'])
        box(7.2, 8.0, 3.0, 8.8, 8.6, 4.2, M['golddk']); box(7.2, 8.0, 11.8, 8.8, 8.6, 13.0, M['golddk'])
        box(6.8, 8.6, 7.0, 9.2, 11.0, 9.0, M['gold']); box(6.7, 9.0, 7.3, 9.3, 10.6, 8.7, M['gem'])
        # Klinge (breit in z, duenn in x)
        box(7.5, 9.8, 6.3, 8.5, 26.4, 9.7, M['blade'])
        box(7.4, 11.0, 7.3, 8.6, 24.6, 8.7, M['fuller'])
        box(7.45, 9.8, 6.0, 8.55, 26.4, 6.4, M['edge']); box(7.45, 9.8, 9.6, 8.55, 26.4, 10.0, M['edge'])
        # Spitze (gestuft)
        box(7.6, 26.4, 6.5, 8.4, 27.8, 9.5, M['blade']); box(7.65, 27.8, 6.9, 8.35, 29.0, 9.1, M['blade'])
        box(7.7, 29.0, 7.3, 8.3, 30.0, 8.7, M['edge']); box(7.8, 30.0, 7.6, 8.2, 30.8, 8.4, M['goldhi'])
        # Sonnenzier am Blattansatz
        box(7.3, 12.0, 5.6, 8.7, 13.6, 6.4, M['gold']); box(7.3, 12.0, 9.6, 8.7, 13.6, 10.4, M['gold'])
    else:
        # Griff (Tech)
        box(7.2, 0.0, 7.2, 8.8, 1.4, 8.8, M['steel2']); box(7.0, 1.4, 7.0, 9.0, 2.2, 9.0, M['silver'])
        box(7.3, 2.2, 7.3, 8.7, 8.4, 8.7, M['steel'])
        for y in (3.2, 5.0, 6.8): box(7.2, y, 7.2, 8.8, y + 0.5, 8.8, M['glow2'])
        # Parierstange: schmale Sichel-Flügel
        box(7.0, 8.4, 5.4, 9.0, 9.4, 10.6, M['silver'])
        box(7.2, 9.4, 4.4, 8.8, 10.4, 5.6, M['steel']); box(7.2, 9.4, 10.4, 8.8, 10.4, 11.6, M['steel'])
        box(7.4, 10.4, 3.8, 8.6, 11.2, 4.8, M['glow']); box(7.4, 10.4, 11.2, 8.6, 11.2, 12.2, M['glow'])
        box(6.8, 8.9, 7.2, 9.2, 10.2, 8.8, M['violet'])
        # Klinge: gebogene Sichel (gestuft in z)
        pts = []
        N = 11
        for i in range(N):
            y0 = 9.4 + i * 1.5
            off = 0.016 * i * i * 2.0       # Kruemmung nach +z
            pts.append((y0, off))
        for i, (y0, off) in enumerate(pts):
            wd = 1.4 - (0.07 * max(0, i - 6))
            zc = 7.0 + off
            h = 1.5                                   # exakt = Schrittweite -> keine ueberlappenden (z-fightenden) Flaechen
            box(7.55, y0, zc - wd / 2, 8.45, y0 + h, zc + wd / 2 + 1.0, M['blade'])
            box(7.4, y0 + 0.01, zc + wd / 2 + 1.0, 8.6, y0 + h - 0.01, zc + wd / 2 + 1.8, M['glow'])   # leuchtende Schneide
            if i % 2 == 0: box(7.45, y0 + 0.2, zc - 0.3, 8.55, y0 + 1.0, zc + 0.3, M['glow2'])
        top = pts[-1]
        box(7.6, top[0] + 1.5, 7.0 + top[1] + 1.2, 8.4, top[0] + 2.7, 7.0 + top[1] + 2.6, M['glow'])
        # Schwebender Energiebogen ueber der Spitze
        for k, (dy, dz) in enumerate(((0.0, 0.0), (0.9, 0.9), (1.5, 2.0), (1.7, 3.2))):
            box(7.7, 28.0 + dy, 12.0 + dz, 8.3, 29.2 + dy, 13.0 + dz, M['violet'] if k % 2 else M['glow'])
    return root


def item_json(root, W, H, tex):
    """Block-Item-Modell (nur Quader ohne Rotation)."""
    names = {'N': 'north', 'S': 'south', 'E': 'east', 'W': 'west', 'U': 'up', 'D': 'down'}
    els = []
    for part in root.walk():
        for c in part.cubes:
            rects = face_rects(c)
            faces = {}
            for f, (u0, v0, pw, ph) in rects.items():
                faces[names[f]] = {'uv': [round(u0 * 16.0 / W, 4), round(v0 * 16.0 / H, 4), round((u0 + pw) * 16.0 / W, 4), round((v0 + ph) * 16.0 / H, 4)], 'texture': '#0'}
            els.append({'from': [r3(c.a[0]), r3(c.a[1]), r3(c.a[2])], 'to': [r3(c.b[0]), r3(c.b[1]), r3(c.b[2])], 'faces': faces})
    return {'textures': {'0': tex, 'particle': tex}, 'elements': els, 'display': SWORD_DISPLAY}


SWORD_DISPLAY = {
    'thirdperson_righthand': {'rotation': [0, 0, 0], 'translation': [0, 2.3, 0.4], 'scale': [0.85, 0.85, 0.85]},
    'thirdperson_lefthand': {'rotation': [0, 0, 0], 'translation': [0, 2.3, 0.4], 'scale': [0.85, 0.85, 0.85]},
    'firstperson_righthand': {'rotation': [-35, 0, 22], 'translation': [0.6, 1.9, -0.4], 'scale': [0.62, 0.62, 0.62]},
    'firstperson_lefthand': {'rotation': [-35, 0, -22], 'translation': [0.6, 1.9, -0.4], 'scale': [0.62, 0.62, 0.62]},
    'ground': {'rotation': [90, 0, 0], 'translation': [0, 2, -3.38], 'scale': [0.45, 0.45, 0.45]},
    'gui': {'rotation': [-128.1, 24.6, 131.53], 'translation': [2.33, -2.94, 1.64], 'scale': [0.62, 0.62, 0.62]},
    'fixed': {'rotation': [-55, -43.4, -63.33], 'translation': [-2.27, -2.48, 0.75], 'scale': [0.6, 0.6, 0.6]}}


def piece_names(root, prefix, kind):
    """Teile eines Rüstungsteils fuer Icons: kind helm|chest|thigh|boot"""
    out = []
    for p in root.walk():
        if p.name.startswith(prefix):
            if kind == 'helm' and p.name == prefix + 'helm': out.append(p)
            if kind == 'chest' and p.name in (prefix + 'chest', prefix + 'arm'): out.append(p)
            if kind == 'thigh' and p.name == prefix + 'thigh': out.append(p)
            if kind == 'boot' and p.name == prefix + 'boot': out.append(p)
    return out


# ------------------------------------------------------------------ GeckoLib (Bedrock geo.json)
GEO_SKEL = {'head': 'armorHead', 'body': 'armorBody', 'arm_r': 'armorRightArm', 'arm_l': 'armorLeftArm',
            'leg_r': 'armorRightLeg', 'leg_l': 'armorLeftLeg'}


def _geo_uv(c):
    """Pro-Flaeche-UV (exakt unser Atlas-Layout). GeckoLib: EAST = Region (u, v+d), WEST = (u+d+w, v+d)."""
    u, v = c.uv; w, h, d = c.dim
    iw, ih, idd = int(math.ceil(w)), int(math.ceil(h)), int(math.ceil(d))
    return {'east': {'uv': [u, v + idd], 'uv_size': [idd, ih]},
            'west': {'uv': [u + idd + iw, v + idd], 'uv_size': [idd, ih]},
            'north': {'uv': [u + idd, v + idd], 'uv_size': [iw, ih]},
            'south': {'uv': [u + 2 * idd + iw, v + idd], 'uv_size': [iw, ih]},
            'up': {'uv': [u + idd, v], 'uv_size': [iw, idd]},
            'down': {'uv': [u + idd + iw, v + idd], 'uv_size': [iw, -idd]}}


def to_geo(root, W, H, ident):
    """Wandelt den Part-Baum (nach pack()) in ein GeckoLib-Armor-Modell (Bedrock geo 1.12.0).
    Positionen = DSL-Koordinaten (y oben); Rotation (Grad) = Vanilla-Rotation der Parts (GeckoLib negiert x/y selbst)."""
    bones = []

    def piv(p): return [r3(p.piv[0]), r3(p.piv[1]), r3(p.piv[2])]

    def bone(p, parent, side=''):
        b = {'name': p.name + side, 'pivot': piv(p)}
        if parent: b['parent'] = parent
        if any(abs(a) > 1e-9 for a in p.rot):
            b['rotation'] = [r3(math.degrees(a)) for a in p.rot]
        if p.cubes:
            b['cubes'] = [{'origin': [r3(c.a[0]), r3(c.a[1]), r3(c.a[2])],
                           'size': [r3(c.b[0] - c.a[0]), r3(c.b[1] - c.a[1]), r3(c.b[2] - c.a[2])],
                           'uv': _geo_uv(c)} for c in p.cubes]
        bones.append(b)
        for k in p.kids: bone(k, p.name + side, side)

    for sk in root.kids:
        name = GEO_SKEL[sk.name]
        bones.append({'name': name, 'pivot': piv(sk)})
        side = '_' + sk.name[-1] if sk.name[-2:] in ('_r', '_l') else ''   # Arme/Beine existieren je Seite -> eindeutige Bone-Namen
        if sk.name.startswith('leg'):
            boot = name.replace('Leg', 'Boot')
            bones.append({'name': boot, 'pivot': piv(sk)})
            for k in sk.kids: bone(k, boot if k.name.endswith('boot') else name, side)
        else:
            for k in sk.kids: bone(k, name, side)
    return {'format_version': '1.12.0', 'minecraft:geometry': [{
        'description': {'identifier': 'geometry.' + ident, 'texture_width': W, 'texture_height': H,
                        'visible_bounds_width': 4, 'visible_bounds_height': 4, 'visible_bounds_offset': [0, 1.5, 0]},
        'bones': bones}]}
