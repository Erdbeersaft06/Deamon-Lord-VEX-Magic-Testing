# Gear & Stats Implementation Plan

> Ausführung: nativ in dieser Session (Nutzer wollte direkt die fertige Datei).

**Goal:** Zwei Rüstungssets + zwei Schwerter mit Stats-System, Set-Boni, Fähigkeiten, 3D-Rüstungsrendering.
**Architecture:** Vanilla-Items via /give-Komponenten (item_model-ID = Schlüssel), Stats-Tabelle in Java, Damage-Hook über Fabric ALLOW_DAMAGE, 3D-Rüstung als folgende Client-Entity (GearEntity) mit JsonModel.
**Spec:** docs/superpowers/specs/2026-11-27-gear-stats-design.md

## Global Constraints
Minecraft 26.2, Java 25, Mojang-Mappings, Fabric; Build ungetestet (nur Syntaxcheck); Sprache Deutsch.

## Review Focus
- Mehrere Spieler / Respawn / Dimensionswechsel: Gear-Entity wird neu erzeugt.
- Schaden ohne Angreifer (Void, /kill): Defense wird übersprungen.
- Rekursion im Damage-Hook (Guard-Flag).
- Spieler unsichtbar / Ego-Perspektive: Rüstung wird nicht gezeichnet.

### Task 1: Generator (tools/gen/gear.py): Rüstungs-Atlas+JSON, Schwert-Item-Modelle, Icons, bbmodel
### Task 2: Stats/Events/Fähigkeiten/Entity/Command (Java, main)
### Task 3: Client-Renderer (GearModel/State/Renderer + Registrierung)
### Task 4: Ressourcen (items/*.json, equipment ghost), Lang, ZAUBER.md, Zip, Syntaxcheck
