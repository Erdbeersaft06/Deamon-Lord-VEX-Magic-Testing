# Gear & Stats – Kurzdesign (freigegeben 2026-11-27)

## Ziel
Zwei Rüstungssets + zwei Schwerter, unbreakable, eigene Namen, Stats-System, Set-Boni, Schwert-Fähigkeiten. Admin-Ausgabe per `/gear give`.

## Stats
Stärke (1=+1% Schaden), Crit Chance (Cap 100), Crit Schaden (1=+1% Crit-Schaden), Leben (Cap 20 Herzen = 40 HP), Defense (1=-1% erlittener Schaden).

## Sets
- Tank "Ehrwürdiger Kriegspanzer" + Schwert "Midas' Richtspruch": Leben +10 Herzen, Defense ~70, Setbonus Eidschwur.
- Glascannon "Himmlischer Mantel" + Schwert "Bogenklinge": Leben 0, Defense ~8, hohe Stärke/Crit, Setbonus Sternensturm.

## Ansätze
Vanilla-Netherite-Items mit Data Components (custom_data-Stats) statt neuer Item-Klassen (Build-Sicherheit); Stats serverseitig im Damage-Hook; 3D-Rüstung via Client-Layer mit JsonModel-Würfeln; Schwerter als Item-Modelle. Gewählt vom Nutzer: direkt 3D, eigene Texturen.

## Nicht-Ziele
Crafting, Boss-Drops, Original-Texturen übernehmen.

## Risiko
26.2-Renderer-API ungeprüft; ggf. Build-Korrekturrunden.
