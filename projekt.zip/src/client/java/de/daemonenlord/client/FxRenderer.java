package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.FxEntity;

public class FxRenderer extends MobRenderer<FxEntity, FxRenderState, FxModel> {
	private static final Identifier TEXTURE = DaemonenlordMod.id("textures/entity/daemonenlord_fx.png");

	public FxRenderer(EntityRendererProvider.Context context) {
		super(context, new FxModel(context.bakeLayer(FxModel.LAYER)), 0.0f);
	}

	@Override
	public FxRenderState createRenderState() {
		return new FxRenderState();
	}

	@Override
	public void extractRenderState(FxEntity entity, FxRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.kind = entity.getKind();
		state.life = entity.getLife();
		state.sxz = entity.getSxz();
		state.sy = entity.getSy();
		state.ax = entity.getAx();
		state.ay = entity.getAy();
		state.lightCoords = 15728880;
	}

	@Override
	public Identifier getTextureLocation(FxRenderState state) {
		return TEXTURE;
	}
}
