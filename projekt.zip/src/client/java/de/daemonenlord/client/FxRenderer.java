package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.AABB;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.FxEntity;

public class FxRenderer extends MobRenderer<FxEntity, FxRenderState, FxModel> {
	private static final Identifier TEXTURE = DaemonenlordMod.id("textures/entity/daemonenlord_fx.png");

	private static final Identifier TEXTURE_RED = DaemonenlordMod.id("textures/entity/daemonenlord_fx_red.png");

	private static final Identifier TEXTURE_BLUE = DaemonenlordMod.id("textures/entity/daemonenlord_fx_blue.png");

	private static final Identifier[] TINTS = {
			DaemonenlordMod.id("textures/entity/daemonenlord_fx_t3.png"), DaemonenlordMod.id("textures/entity/daemonenlord_fx_t4.png"),
			DaemonenlordMod.id("textures/entity/daemonenlord_fx_t5.png"), DaemonenlordMod.id("textures/entity/daemonenlord_fx_t6.png"),
			DaemonenlordMod.id("textures/entity/daemonenlord_fx_t7.png")};

	public FxRenderer(EntityRendererProvider.Context context) {
		super(context, new FxModel(context.bakeLayer(FxModel.LAYER)), 0.0f);
	}

	/** Grosse Effekte (Domaene, Strahlen) duerfen nie weggeculled werden, nur weil ihr Mittelpunkt ausser Sicht ist. */
	public AABB getBoundingBoxForCulling(FxEntity entity) {
		double r = Math.max(entity.getSxz() * 16.0, entity.getSy()) + 6.0;
		return entity.getBoundingBox().inflate(r, 6.0, r);
	}

	public boolean affectedByCulling(FxEntity entity) {
		return false;
	}

	@Override
	public FxRenderState createRenderState() {
		return new FxRenderState();
	}

	@Override
	public void extractRenderState(FxEntity entity, FxRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.kind = entity.getKind();
		state.life = entity.getLife();
		state.red = entity.isRed();
		state.blue = entity.isBlue();
		state.tint = entity.getTint();
		state.sxz = entity.getSxz();
		state.sy = entity.getSy();
		state.ax = entity.getAx();
		state.ay = entity.getAy();
		state.lightCoords = 15728880;
	}

	@Override
	public Identifier getTextureLocation(FxRenderState state) {
		if (state.tint >= 3 && state.tint <= 7) return TINTS[state.tint - 3];
		return state.blue ? TEXTURE_BLUE : state.red ? TEXTURE_RED : TEXTURE;
	}
}
