package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRenderers;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

import de.daemonenlord.entity.ModEntities;

public class DaemonenlordClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ModelLayerRegistry.registerModelLayer(DaemonenlordModel.LAYER, DaemonenlordModel::createLayer);
		EntityRenderers.register(ModEntities.DAEMONENLORD, DaemonenlordRenderer::new);
	}
}
