package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRenderers;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

import de.daemonenlord.entity.ModEntities;

public class DaemonenlordClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ModelLayerRegistry.registerModelLayer(DaemonenlordModel.LAYER, DaemonenlordModel::createLayer);
		EntityRenderers.register(ModEntities.DAEMONENLORD, DaemonenlordRenderer::new);
		ModelLayerRegistry.registerModelLayer(GoddessModel.SOLARA, GoddessModel::createSolara);
		ModelLayerRegistry.registerModelLayer(GoddessModel.LUNARA, GoddessModel::createLunara);
		ModelLayerRegistry.registerModelLayer(GoddessModel.FUSION, GoddessModel::createFusion);
		EntityRenderers.register(ModEntities.SOLARA, ctx -> new GoddessRenderer(ctx, 0));
		EntityRenderers.register(ModEntities.LUNARA, ctx -> new GoddessRenderer(ctx, 1));
		EntityRenderers.register(ModEntities.FUSION, ctx -> new GoddessRenderer(ctx, 2));
		ModelLayerRegistry.registerModelLayer(FxModel.LAYER, FxModel::createLayer);
		EntityRenderers.register(ModEntities.FX, FxRenderer::new);
		ModelLayerRegistry.registerModelLayer(GearModel.LAYER, GearModel::createLayer);
		EntityRenderers.register(ModEntities.GEAR, GearRenderer::new);
	}
}
