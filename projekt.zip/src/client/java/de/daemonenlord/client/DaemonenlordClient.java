package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRenderers;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;

import de.daemonenlord.entity.ModEntities;

public class DaemonenlordClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ModelLayerRegistry.registerModelLayer(DaemonenlordModel.LAYER, DaemonenlordModel::createLayer);
		EntityRenderers.register(ModEntities.DAEMONENLORD, DaemonenlordRenderer::new);
		ModelLayerRegistry.registerModelLayer(GoddessModel.SOLARA, GoddessModel::createSolara);
		ModelLayerRegistry.registerModelLayer(GoddessModel.LUNARA, GoddessModel::createLunara);
		EntityRenderers.register(ModEntities.SOLARA, ctx -> new GoddessRenderer(ctx, true));
		EntityRenderers.register(ModEntities.LUNARA, ctx -> new GoddessRenderer(ctx, false));
		ModelLayerRegistry.registerModelLayer(FxModel.LAYER, FxModel::createLayer);
		EntityRenderers.register(ModEntities.FX, FxRenderer::new);
	}
}
