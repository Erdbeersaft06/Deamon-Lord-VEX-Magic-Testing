package de.daemonenlord.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;

/**
 * 3D-Ruestungen (assets/daemonenlord/gear_model.json, erzeugt von tools/gen/gear.py).
 * Skelett wie ein Spielermodell: all -> head, body, arm_r, arm_l, leg_r, leg_l; je Set (t_ / g_):
 * helm (Kopf), chest (Koerper, Umhang, Fluegel), arm (Arme), thigh + boot (Beine).
 */
public class GearModel extends EntityModel<GearRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("gear"), "main");
	private static final String[] PRE = {"t_", "g_"};

	private final ModelPart head, body, armR, armL, legR, legL;
	private final ModelPart[] helm = new ModelPart[2], chest = new ModelPart[2], cape = new ModelPart[2], cape2 = new ModelPart[2];
	private final ModelPart[] aR = new ModelPart[2], aL = new ModelPart[2], thR = new ModelPart[2], thL = new ModelPart[2], boR = new ModelPart[2], boL = new ModelPart[2];
	private final ModelPart wingL, wingR, halo;

	private static ModelPart opt(ModelPart p, String n) {
		try { return p.getChild(n); } catch (RuntimeException e) { return null; }
	}

	public GearModel(ModelPart root) {
		super(root);
		ModelPart all = root.getChild("all");
		head = all.getChild("head");
		body = all.getChild("body");
		armR = all.getChild("arm_r");
		armL = all.getChild("arm_l");
		legR = all.getChild("leg_r");
		legL = all.getChild("leg_l");
		for (int s = 0; s < 2; s++) {
			String p = PRE[s];
			helm[s] = head.getChild(p + "helm");
			chest[s] = body.getChild(p + "chest");
			cape[s] = chest[s].getChild(p + "cape");
			cape2[s] = cape[s].getChild(p + "cape2");
			aR[s] = armR.getChild(p + "arm");
			aL[s] = armL.getChild(p + "arm");
			thR[s] = legR.getChild(p + "thigh");
			thL[s] = legL.getChild(p + "thigh");
			boR[s] = legR.getChild(p + "boot");
			boL[s] = legL.getChild(p + "boot");
		}
		wingL = opt(chest[1], "g_wing_l");
		wingR = opt(chest[1], "g_wing_r");
		halo = opt(helm[1], "g_halo");
	}

	public static LayerDefinition createLayer() { return JsonModel.load("/assets/daemonenlord/gear_model.json"); }

	@Override
	public void setupAnim(GearRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		// Sichtbarkeit je getragenem Teil
		for (int s = 0; s < 2; s++) {
			int m = (state.mask >> (s * 4)) & 15;
			// Die eigentliche Ruestung zeichnet Vanilla (Ruestungstextur); hier nur Zubehoer: Umhang, Fluegel, Heiligenschein.
			helm[s].visible = (m & 1) != 0;
			helm[s].skipDraw = true;
			chest[s].visible = (m & 2) != 0;
			chest[s].skipDraw = true;
			aR[s].visible = false;
			aL[s].visible = false;
			thR[s].visible = false;
			thL[s].visible = false;
			boR[s].visible = false;
			boL[s].visible = false;
		}
		float sp = Math.min(1.0f, state.wspd);
		float p = state.wpos;
		head.yRot = state.headYaw * Mth.DEG_TO_RAD;
		head.xRot = state.headPitch * Mth.DEG_TO_RAD;
		armR.xRot = Mth.cos(p * 0.6662f + Mth.PI) * 2.0f * sp * 0.5f;
		armL.xRot = Mth.cos(p * 0.6662f) * 2.0f * sp * 0.5f;
		legR.xRot = Mth.cos(p * 0.6662f) * 1.4f * sp;
		legL.xRot = Mth.cos(p * 0.6662f + Mth.PI) * 1.4f * sp;
		// leichtes Atmen der Arme
		armR.zRot += Mth.cos(t * 0.09f) * 0.05f + 0.05f;
		armL.zRot -= Mth.cos(t * 0.09f) * 0.05f + 0.05f;
		armR.xRot += Mth.sin(t * 0.067f) * 0.05f;
		armL.xRot -= Mth.sin(t * 0.067f) * 0.05f;
		// Angriffsschwung (rechter Arm)
		if (state.swing > 0.0f) {
			float f = 1.0f - state.swing;
			f = 1.0f - f * f * f * f;
			armR.xRot -= Mth.sin(f * Mth.PI) * 1.3f + Mth.sin(state.swing * Mth.PI) * 0.4f;
			armR.zRot += Mth.sin(state.swing * Mth.PI) * -0.3f;
		}
		float sneakCape = 0.0f;
		if (state.sneak) {
			body.xRot += 0.5f;
			armR.xRot += 0.4f;
			armL.xRot += 0.4f;
			legR.z += 4.0f;
			legL.z += 4.0f;
			legR.y += 0.2f;
			legL.y += 0.2f;
			head.y += 4.2f;
			body.y += 3.2f;
			armR.y += 3.2f;
			armL.y += 3.2f;
			sneakCape = 0.45f;
		}
		// Umhaenge: wehen beim Laufen
		for (int s = 0; s < 2; s++) {
			cape[s].xRot += sp * 0.65f + Mth.sin(t * 0.08f) * 0.03f + sneakCape;
			cape2[s].xRot += sp * 0.45f + Mth.sin(t * 0.08f + 0.8f) * 0.04f;
		}
		// Fluegel schlagen sanft, Heiligenschein dreht sich
		if (wingL != null) {
			float fl = Mth.sin(t * 0.12f) * 0.10f;
			wingL.zRot += fl;
			wingL.yRot += fl * 0.5f;
			wingR.zRot -= fl;
			wingR.yRot -= fl * 0.5f;
		}
		if (halo != null) {
			halo.yRot += t * 0.04f;
			halo.y += Mth.sin(t * 0.07f) * 0.6f;
		}
	}
}
