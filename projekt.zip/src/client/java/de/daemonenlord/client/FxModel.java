package de.daemonenlord.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;

/** Effekt-Teile aus der Blockbench-Szene: Welle, Siegel, Klinge, Lichtsaeule, Kern, Klingenring. */
public class FxModel extends EntityModel<FxRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("fx"), "main");

	private final ModelPart[] parts;
	private final ModelPart arm, panL, panR;
	private static final String[] GROUPS = {"g_out", "g_script", "g_arc1", "g_tri", "g_sq", "g_orbit", "g_arc2", "g_inner", "g_core"};
	private static final float[] SPEEDS = {0.010f, -0.016f, 0.022f, 0.028f, -0.024f, 0.035f, -0.040f, -0.048f, 0.070f};
	private final ModelPart[][] circ = new ModelPart[10][];   // [Part-Index][Gruppe]
	private final ModelPart[][] orbs = new ModelPart[10][];

	/** Drehung aller Schichten eines Magiekreises: jede Schicht mit eigener Geschwindigkeit, abwechselnd links/rechts. */
	private void spinCircle(int idx, float age, float dir) {
		ModelPart[] g = circ[idx];
		for (int i = 0; i < g.length; i++) g[i].yRot = age * SPEEDS[i] * dir;
		ModelPart[] o = orbs[idx];
		for (int k = 0; k < o.length; k++) o[k].yRot = age * 0.12f * (k % 2 == 0 ? 1 : -1);
	}

	public FxModel(ModelPart root) {
		super(root);
		ModelPart fx = root.getChild("fx");
		this.parts = new ModelPart[] {
				fx.getChild("ring"), fx.getChild("seal"), fx.getChild("blade"),
				fx.getChild("pillar"), fx.getChild("core"), fx.getChild("bladering"),
				fx.getChild("beam"), fx.getChild("rune"), fx.getChild("scale"), fx.getChild("mandala")
		};
		for (int idx : new int[] {1, 7, 9}) {
			ModelPart[] g = new ModelPart[GROUPS.length];
			for (int i = 0; i < GROUPS.length; i++) g[i] = parts[idx].getChild(GROUPS[i]);
			circ[idx] = g;
			ModelPart orbit = parts[idx].getChild("g_orbit");
			ModelPart[] o = new ModelPart[6];
			for (int k = 0; k < 6; k++) o[k] = orbit.getChild("orb" + k);
			orbs[idx] = o;
		}
		this.arm = parts[8].getChild("arm");
		this.panL = arm.getChild("panl");
		this.panR = arm.getChild("panr");
	}

	public static LayerDefinition createLayer() {
		return JsonModel.load("/assets/daemonenlord/fx_model.json");
	}

	@Override
	public void setupAnim(FxRenderState state) {
		super.setupAnim(state);
		for (ModelPart p : parts) p.visible = false;
		// Kinds: 0 Ring, 1 Siegel, 2 Klinge, 3 Saeule, 4 Kern, 5 Klingenring, 6 Strahl (duenn, Laenge = sy Bloecke), 7 Runen-Stern
		int idx = (state.kind == 8 || state.kind == 10) ? 7 : state.kind == 9 ? 8 : (state.kind == 11 || state.kind == 12) ? 9 : Mth.clamp(state.kind, 0, parts.length - 1);
		ModelPart p = parts[idx];
		p.visible = true;

		float age = state.ageInTicks;
		float fade = Mth.clamp((state.life - age) / 8.0f, 0.0f, 1.0f) * Mth.clamp(age / 4.0f + 0.2f, 0.0f, 1.0f);
		p.xScale = state.sxz * fade;
		p.yScale = state.kind == 6 ? state.sy : state.sy * fade;
		p.zScale = state.sxz * fade;

		p.xRot = 0.0f;
		p.zRot = 0.0f;
		p.yRot = 0.0f;
		switch (state.kind) {
			case 1 -> spinCircle(1, age, 1.0f);
			case 3 -> p.yRot = age * 0.05f;
			case 4 -> p.yRot = age * 0.12f;
			case 5 -> p.yRot = age * 0.07f;
			case 6 -> {
				p.xRot = state.ax;
				p.yRot = state.ay;
			}
			case 7 -> spinCircle(7, age, state.ax != 0.0f ? state.ax : 1.0f);
			case 10 -> p.yRot = age * state.ax;
			case 11, 12 -> {
				if (state.kind == 12) {
					p.xRot = state.ax;
					p.yRot = state.ay;
				}
				spinCircle(9, age, (state.kind == 11 && state.ax != 0.0f) ? state.ax : 1.0f);
			}
			case 9 -> {
				p.yRot = age * 0.012f;
				float grow = Mth.clamp(age / 60.0f, 0.0f, 1.0f);
				float tilt = (Mth.sin(age * 0.06f) * 0.30f + Mth.sin(age * 0.19f) * 0.07f) * grow;
				arm.zRot = tilt;
				panL.zRot = -tilt;
				panR.zRot = -tilt;
			}
			case 8 -> {
				p.xRot = state.ax;
				p.yRot = state.ay;
				spinCircle(7, age, 1.0f);
			}
			default -> { }
		}
	}
}
