package de.daemonenlord.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;

/** Effekt-Teile aus der Blockbench-Szene: Welle, Siegel, Klinge, Lichtsaeule, Kern, Klingenring. */
public class FxModel extends EntityModel<FxRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("fx"), "main");

	private final ModelPart[] parts;
	private final ModelPart arm, panL, panR;
	private final ModelPart mOut, mRune, mTri, mSq, mOrbit, mInner, mCore;

	public FxModel(ModelPart root) {
		super(root);
		ModelPart fx = root.getChild("fx");
		this.parts = new ModelPart[] {
				fx.getChild("ring"), fx.getChild("seal"), fx.getChild("blade"),
				fx.getChild("pillar"), fx.getChild("core"), fx.getChild("bladering"),
				fx.getChild("beam"), fx.getChild("rune"), fx.getChild("scale"), fx.getChild("mandala")
		};
		this.mOut = parts[9].getChild("g_out");
		this.mRune = parts[9].getChild("g_rune");
		this.mTri = parts[9].getChild("g_tri");
		this.mSq = parts[9].getChild("g_sq");
		this.mOrbit = parts[9].getChild("g_orbit");
		this.mInner = parts[9].getChild("g_inner");
		this.mCore = parts[9].getChild("g_core");
		this.arm = parts[8].getChild("arm");
		this.panL = arm.getChild("panl");
		this.panR = arm.getChild("panr");
	}

	public static LayerDefinition createLayer() {
		return JsonModel.load("/assets/daemonenlord/fx_model.json");
	}

	@Override
	public void setupAnim(FxRenderState state) {
		super.setupAnim(state);
		for (ModelPart p : parts) p.visible = false;
		// Kinds: 0 Ring, 1 Siegel, 2 Klinge, 3 Saeule, 4 Kern, 5 Klingenring, 6 Strahl (duenn, Laenge = sy Bloecke), 7 Runen-Stern
		int idx = (state.kind == 8 || state.kind == 10) ? 7 : state.kind == 9 ? 8 : (state.kind == 11 || state.kind == 12) ? 9 : Mth.clamp(state.kind, 0, parts.length - 1);
		ModelPart p = parts[idx];
		p.visible = true;

		float age = state.ageInTicks;
		float fade = Mth.clamp((state.life - age) / 8.0f, 0.0f, 1.0f) * Mth.clamp(age / 4.0f + 0.2f, 0.0f, 1.0f);
		p.xScale = state.sxz * fade;
		p.yScale = state.kind == 6 ? state.sy : state.sy * fade;
		p.zScale = state.sxz * fade;

		p.xRot = 0.0f;
		p.zRot = 0.0f;
		p.yRot = 0.0f;
		switch (state.kind) {
			case 1 -> p.yRot = age * 0.02f;
			case 3 -> p.yRot = age * 0.05f;
			case 4 -> p.yRot = age * 0.12f;
			case 5 -> p.yRot = age * 0.07f;
			case 6 -> {
				p.xRot = state.ax;
				p.yRot = state.ay;
			}
			case 7 -> p.yRot = -age * 0.06f;
			case 10 -> p.yRot = age * state.ax;
			case 11, 12 -> {
				if (state.kind == 12) {
					p.xRot = state.ax;
					p.yRot = state.ay;
				}
				float dir = (state.kind == 11 && state.ax != 0.0f) ? state.ax : 1.0f;
				mOut.yRot = age * 0.010f * dir;
				mRune.yRot = -age * 0.018f * dir;
				mTri.yRot = age * 0.028f * dir;
				mSq.yRot = -age * 0.022f * dir;
				mOrbit.yRot = age * 0.035f * dir;
				mInner.yRot = -age * 0.045f * dir;
				mCore.yRot = age * 0.070f * dir;
				for (int k = 0; k < 6; k++) {
					ModelPart orb = mOrbit.getChild("orb" + k);
					orb.yRot = age * 0.12f * (k % 2 == 0 ? 1 : -1);
				}
			}
			case 9 -> {
				p.yRot = age * 0.012f;
				float grow = Mth.clamp(age / 60.0f, 0.0f, 1.0f);
				float tilt = (Mth.sin(age * 0.06f) * 0.30f + Mth.sin(age * 0.19f) * 0.07f) * grow;
				arm.zRot = tilt;
				panL.zRot = -tilt;
				panR.zRot = -tilt;
			}
			case 8 -> {
				p.xRot = state.ax;
				p.yRot = state.ay;
			}
			default -> { }
		}
	}
}
