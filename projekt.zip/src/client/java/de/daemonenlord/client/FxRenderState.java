package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class FxRenderState extends LivingEntityRenderState {
	public int kind;
	public int life;
	public boolean red;
	public boolean blue;
	public float sxz = 1f, sy = 1f, ax, ay;
}
