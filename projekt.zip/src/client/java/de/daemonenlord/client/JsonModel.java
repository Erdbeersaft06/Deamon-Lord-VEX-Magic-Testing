package de.daemonenlord.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Laedt ein aus Blockbench konvertiertes Modell (JSON) als LayerDefinition. */
final class JsonModel {
	private JsonModel() {}

	static LayerDefinition load(String resource) {
		JsonObject json;
		try (InputStream in = JsonModel.class.getResourceAsStream(resource)) {
			if (in == null) throw new IllegalStateException(resource + " fehlt");
			json = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
		MeshDefinition mesh = new MeshDefinition();
		build(mesh.getRoot(), json.getAsJsonObject("root"), new int[] {0});
		JsonArray tex = json.getAsJsonArray("tex");
		return LayerDefinition.create(mesh, tex.get(0).getAsInt(), tex.get(1).getAsInt());
	}

	private static void build(PartDefinition parent, JsonObject n, int[] counter) {
		String name = n.has("n") ? n.get("n").getAsString() : "c" + (counter[0]++);
		CubeListBuilder cb = CubeListBuilder.create();
		if (n.has("c")) {
			for (JsonElement ce : n.getAsJsonArray("c")) {
				JsonArray a = ce.getAsJsonArray();
				cb.texOffs(a.get(0).getAsInt(), a.get(1).getAsInt())
						.addBox(a.get(2).getAsFloat(), a.get(3).getAsFloat(), a.get(4).getAsFloat(),
								a.get(5).getAsFloat(), a.get(6).getAsFloat(), a.get(7).getAsFloat());
			}
		}
		JsonArray p = n.getAsJsonArray("p");
		float px = p.get(0).getAsFloat(), py = p.get(1).getAsFloat(), pz = p.get(2).getAsFloat();
		PartPose pose;
		if (n.has("r")) {
			JsonArray r = n.getAsJsonArray("r");
			pose = PartPose.offsetAndRotation(px, py, pz, r.get(0).getAsFloat(), r.get(1).getAsFloat(), r.get(2).getAsFloat());
		} else {
			pose = PartPose.offset(px, py, pz);
		}
		PartDefinition pd = parent.addOrReplaceChild(name, cb, pose);
		if (n.has("k")) {
			for (JsonElement k : n.getAsJsonArray("k")) build(pd, k.getAsJsonObject(), counter);
		}
	}
}
