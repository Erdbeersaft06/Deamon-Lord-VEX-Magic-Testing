package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.DaemonenlordEntity;

public class DaemonenlordRenderer extends MobRenderer<DaemonenlordEntity, DaemonenlordRenderState, DaemonenlordModel> {
	private static final Identifier TEXTURE = DaemonenlordMod.id("textures/entity/daemonenlord.png");
	private static final Identifier TEXTURE_BLUE = DaemonenlordMod.id("textures/entity/daemonenlord_blue.png");
	private static final Identifier TEXTURE_RED = DaemonenlordMod.id("textures/entity/daemonenlord_red.png");
	private static final int FULL_BRIGHT = 15728880;

	public DaemonenlordRenderer(EntityRendererProvider.Context context) {
		super(context, new DaemonenlordModel(context.bakeLayer(DaemonenlordModel.LAYER)), 1.8f);
	}

	@Override
	public DaemonenlordRenderState createRenderState() {
		return new DaemonenlordRenderState();
	}

	@Override
	public void extractRenderState(DaemonenlordEntity entity, DaemonenlordRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.castState = entity.getCastState();
		state.revived = entity.isRevived();
		state.blue = entity.getRevivals() >= 2;
		state.lightCoords = FULL_BRIGHT; // Gold leuchtet immer
	}

	@Override
	public Identifier getTextureLocation(DaemonenlordRenderState state) {
		return state.blue ? TEXTURE_BLUE : state.revived ? TEXTURE_RED : TEXTURE;
	}
}
