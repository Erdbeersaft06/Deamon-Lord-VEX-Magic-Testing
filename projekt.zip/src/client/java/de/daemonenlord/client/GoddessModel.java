package de.daemonenlord.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.duo.GoddessEntity;

/** Modell von Solara und Lunara (assets/daemonenlord/solara_model.json bzw. lunara_model.json). */
public class GoddessModel extends EntityModel<GoddessRenderState> {
	public static final ModelLayerLocation SOLARA = new ModelLayerLocation(DaemonenlordMod.id("solara"), "main");
	public static final ModelLayerLocation LUNARA = new ModelLayerLocation(DaemonenlordMod.id("lunara"), "main");

	private final boolean sol;
	private final ModelPart all, body, wingL, wingR, halo, armL, armR, skirt, head;
	private final ModelPart cape;   // nur Lunara
	private final float[] pose = {0.10f, 0.10f, 0f, 0f};   // armL aussen, armR aussen, armL vor, armR vor

	public GoddessModel(ModelPart root, boolean sol) {
		super(root);
		this.sol = sol;
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.halo = all.getChild("halo");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		this.armL = body.getChild("arm_l");
		this.armR = body.getChild("arm_r");
		this.skirt = body.getChild("skirt");
		this.head = body.getChild("head");
		this.cape = sol ? null : body.getChild("cape");
	}

	public static LayerDefinition createSolara() { return JsonModel.load("/assets/daemonenlord/solara_model.json"); }
	public static LayerDefinition createLunara() { return JsonModel.load("/assets/daemonenlord/lunara_model.json"); }

	@Override
	public void setupAnim(GoddessRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		float flap = Mth.sin(t * (cast ? 0.2f : 0.07f)) * (cast ? 0.14f : 0.08f);
		float open = cast ? 0.20f : 0.0f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.all.y = 24.0f + Mth.sin(t * 0.07f + (sol ? 0f : 1.5f)) * 1.5f;

		if (sol) {
			this.halo.zRot = t * (cast ? 0.06f : 0.018f);
		} else {
			this.halo.zRot = Mth.sin(t * 0.03f) * 0.08f;
		}

		// Arm-Pose je Zauber (Reihenfolge: zRot L, zRot R, xRot L, xRot R; + = aussen bzw. nach vorn). Lanze: Arme nach vorn.
		float[] tgt = {0.10f, 0.10f, 0f, 0f};
		if (cast) {
			int id = state.castState - 1;
			boolean lance = id == GoddessEntity.Atk.LANZE.ordinal();
			if (lance) tgt = new float[] {0.25f, 0.25f, 1.45f, 1.45f};
			else tgt = new float[] {1.7f + Mth.sin(t * 0.25f) * 0.05f, 1.7f + Mth.sin(t * 0.25f) * 0.05f, -0.25f, -0.25f};
		}
		for (int i = 0; i < 4; i++) pose[i] += (tgt[i] - pose[i]) * 0.12f;
		float breathe = Mth.sin(t * 0.09f) * 0.03f;
		float pos = state.walkAnimationPos;
		float spd = Mth.clamp(state.walkAnimationSpeed * 1.6f, 0.0f, 1.0f);
		this.armL.zRot = pose[0] + breathe;
		this.armR.zRot = -(pose[1] + breathe);
		this.armL.xRot = pose[2];
		this.armR.xRot = pose[3];
		this.skirt.xRot = 0.04f + spd * 0.22f + Mth.sin(t * 0.1f) * 0.03f;
		this.skirt.zRot = Mth.sin(t * 0.08f) * 0.02f;
		if (cape != null) this.cape.xRot = 0.06f + spd * 0.25f + Mth.sin(t * 0.12f) * 0.04f;
		this.head.yRot = Mth.clamp(state.yRot * 0.0174533f, -0.9f, 0.9f);
		this.head.xRot = Mth.clamp(state.xRot * 0.0174533f, -0.5f, 0.5f);
		this.body.xRot = cast ? -0.05f : 0f;
	}
}
