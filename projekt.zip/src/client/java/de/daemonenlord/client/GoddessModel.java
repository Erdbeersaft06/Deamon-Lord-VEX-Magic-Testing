package de.daemonenlord.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.duo.GoddessEntity;

/**
 * Modell von Solara, Lunara und Eklipsa (assets/daemonenlord/solara_model.json, lunara_model.json, fusion_model.json).
 * Die Modelle werden von tools/gen (Python) erzeugt; Knochenhierarchie:
 * all -> body (head -> hair..., arm -> forearm -> weapon, wing -> Federreihen, cape -> cape2 -> cape3), skirt, halo, halo2, orb*.
 */
public class GoddessModel extends EntityModel<GoddessRenderState> {
	public static final ModelLayerLocation SOLARA = new ModelLayerLocation(DaemonenlordMod.id("solara"), "main");
	public static final ModelLayerLocation LUNARA = new ModelLayerLocation(DaemonenlordMod.id("lunara"), "main");
	public static final ModelLayerLocation FUSION = new ModelLayerLocation(DaemonenlordMod.id("fusion"), "main");

	// Zielposen je Modus (0 Heben, 1 Vorstossen, 2 Weit, 3 Ruhe): {Arm-xRot, Arm-nach-aussen, Unterarm-xRot}
	private static final float[][] WEAPON = {
			{-1.00f, 0.15f, -0.35f}, {-1.45f, 0.10f, -0.10f}, {-0.60f, 0.90f, -0.30f}, {-0.30f, 0.08f, -0.95f}};
	private static final float[][] FREE = {
			{-0.40f, 1.25f, -0.40f}, {-1.35f, 0.15f, -0.10f}, {-0.60f, 0.90f, -0.30f}, {0.05f, 0.10f, -0.35f}};

	private final int kind;   // 0 Solara, 1 Lunara, 2 Eklipsa
	private final ModelPart all, body, skirt, head, hair, hair2, hair3, halo, halo2, cape, cape2, cape3;
	private final ModelPart armL, armR, foreL, foreR, wingL, wingR;
	private final ModelPart[] rowsL = new ModelPart[3];
	private final ModelPart[] rowsR = new ModelPart[3];
	private final ModelPart[] orbs;
	private final float[] orbY;
	private final boolean weaponL, weaponR;
	private final float wingLy, wingRy;
	private final float[] pose = {0.05f, 0.10f, -0.35f, -0.30f, 0.08f, -0.95f};

	private static ModelPart opt(ModelPart p, String n) {
		try { return p.getChild(n); } catch (RuntimeException e) { return null; }
	}

	public GoddessModel(ModelPart root, int kind) {
		super(root);
		this.kind = kind;
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.skirt = all.getChild("skirt");
		this.halo = all.getChild("halo");
		this.halo2 = all.getChild("halo2");
		this.head = body.getChild("head");
		this.hair = head.getChild("hair");
		this.hair2 = hair.getChild("hair2");
		this.hair3 = hair2.getChild("hair3");
		this.cape = body.getChild("cape");
		this.cape2 = cape.getChild("cape2");
		this.cape3 = cape2.getChild("cape3");
		this.armL = body.getChild("arm_l");
		this.armR = body.getChild("arm_r");
		this.foreL = armL.getChild("forearm_l");
		this.foreR = armR.getChild("forearm_r");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		String[] rn = {"wa_", "wb_", "wc_"};
		for (int i = 0; i < 3; i++) {
			rowsL[i] = opt(wingL, rn[i] + "l");
			rowsR[i] = opt(wingR, rn[i] + "r");
		}
		this.weaponL = opt(foreL, "weapon_l") != null;
		this.weaponR = opt(foreR, "weapon_r") != null;
		this.wingLy = wingL.yRot;
		this.wingRy = wingR.yRot;
		ModelPart[] tmp = new ModelPart[6];
		int n = 0;
		for (int i = 0; i < 6; i++) {
			ModelPart o = opt(all, "orb" + i);
			if (o != null) tmp[n++] = o;
		}
		this.orbs = new ModelPart[n];
		this.orbY = new float[n];
		for (int i = 0; i < n; i++) { orbs[i] = tmp[i]; orbY[i] = tmp[i].y; }
	}

	public static LayerDefinition createSolara() { return JsonModel.load("/assets/daemonenlord/solara_model.json"); }
	public static LayerDefinition createLunara() { return JsonModel.load("/assets/daemonenlord/lunara_model.json"); }
	public static LayerDefinition createFusion() { return JsonModel.load("/assets/daemonenlord/fusion_model.json"); }

	private static int modeOf(int castState) {
		int id = castState - 1;
		GoddessEntity.Atk[] v = GoddessEntity.Atk.values();
		if (id < 0 || id >= v.length) return 0;
		switch (v[id]) {
			case LANZE: case ZWIELICHTLANZE: return 1;
			case SONNENKRONE: case MONDFINSTERNIS: case ZWILLINGSGESTIRN: case HIMMELSBUND: return 2;
			default: return 0;
		}
	}

	@Override
	public void setupAnim(GoddessRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		int mode = cast ? modeOf(state.castState) : 3;
		float ph = kind == 1 ? 1.5f : 0f;
		float spd = Mth.clamp(state.walkAnimationSpeed * 1.6f, 0.0f, 1.0f);
		float pos = state.walkAnimationPos;

		// ---- Schweben
		this.all.y = 24.0f + Mth.sin(t * 0.07f + ph) * 1.4f;

		// ---- Koerper / Kopf
		float lean = !cast ? 0f : mode == 1 ? 0.14f : mode == 2 ? -0.09f : 0.03f;
		this.body.xRot = lean + spd * 0.10f;
		this.body.yRot = Mth.sin(t * 0.03f + ph) * 0.04f;
		this.body.zRot = Mth.sin(t * 0.045f + ph) * 0.02f;
		this.head.yRot = Mth.clamp(state.yRot * 0.0174533f, -0.9f, 0.9f) - this.body.yRot;
		this.head.xRot = Mth.clamp(state.xRot * 0.0174533f, -0.5f, 0.5f) - lean * 0.6f + (mode == 2 && cast ? -0.12f : 0f);
		this.head.zRot = Mth.sin(t * 0.05f + ph) * 0.025f;

		// ---- Haare, Umhang, Rock (weich nachlaufend)
		float w1 = Mth.sin(t * 0.10f), w2 = Mth.sin(t * 0.10f - 0.7f), w3 = Mth.sin(t * 0.10f - 1.4f);
		this.hair.xRot = 0.04f + spd * 0.35f + w1 * 0.05f + (cast ? 0.10f : 0f);
		this.hair2.xRot = 0.03f + spd * 0.20f + w2 * 0.08f;
		this.hair3.xRot = 0.02f + spd * 0.15f + w3 * 0.10f;
		this.hair.zRot = Mth.sin(t * 0.06f) * 0.03f;
		this.cape.xRot = 0.06f + spd * 0.30f + Mth.sin(t * 0.12f) * 0.04f + (cast ? 0.08f : 0f);
		this.cape2.xRot = 0.05f + spd * 0.20f + Mth.sin(t * 0.12f - 0.8f) * 0.07f;
		this.cape3.xRot = 0.04f + spd * 0.15f + Mth.sin(t * 0.12f - 1.6f) * 0.09f;
		this.skirt.xRot = spd * 0.08f + Mth.sin(t * 0.10f) * 0.012f;
		this.skirt.zRot = Mth.sin(t * 0.08f) * 0.015f;

		// ---- Fluegel
		float flap = Mth.sin(t * (cast ? 0.22f : 0.08f)) * (cast ? 0.16f : 0.10f);
		float open = !cast ? 0.0f : mode == 2 ? 0.45f : 0.20f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.wingL.yRot = wingLy - open * 0.5f + Mth.sin(t * 0.06f) * 0.04f;
		this.wingR.yRot = wingRy + open * 0.5f - Mth.sin(t * 0.06f) * 0.04f;
		for (int i = 0; i < 3; i++) {
			float rip = Mth.sin(t * (cast ? 0.22f : 0.08f) - (i + 1) * 0.7f) * 0.06f;
			if (rowsL[i] != null) rowsL[i].zRot = rip;
			if (rowsR[i] != null) rowsR[i].zRot = -rip;
		}

		// ---- Arme (weich ueberblendet)
		float[] wt = WEAPON[mode], ft = FREE[mode];
		float[] tl = weaponL ? wt : ft, tr = weaponR ? wt : ft;
		float pulse = cast ? Mth.sin(t * 0.25f) * 0.05f : 0f;
		pose[0] += (tl[0] - pose[0]) * 0.12f; pose[1] += (tl[1] - pose[1]) * 0.12f; pose[2] += (tl[2] - pose[2]) * 0.12f;
		pose[3] += (tr[0] - pose[3]) * 0.12f; pose[4] += (tr[1] - pose[4]) * 0.12f; pose[5] += (tr[2] - pose[5]) * 0.12f;
		float breathe = Mth.sin(t * 0.09f) * 0.03f;
		float swing = Mth.cos(pos * 0.45f) * 0.15f * spd;
		this.armL.xRot = pose[0] + (weaponL ? 0f : swing);
		this.armL.zRot = pose[1] + breathe + pulse;
		this.foreL.xRot = pose[2];
		this.armR.xRot = pose[3] + (weaponR ? 0f : -swing);
		this.armR.zRot = -(pose[4] + breathe + pulse);
		this.foreR.xRot = pose[5];

		// ---- Heiligenschein / Aura
		if (kind == 1) {
			this.halo.zRot = Mth.sin(t * 0.03f) * 0.08f;
		} else {
			this.halo.zRot = t * (cast ? 0.06f : 0.018f);
		}
		this.halo2.zRot = Mth.sin(t * 0.03f + 1.0f) * 0.10f - t * (cast ? 0.012f : 0.004f);

		// ---- Orbs umkreisen die Goettin
		int n = orbs.length;
		for (int i = 0; i < n; i++) {
			float a = t * (cast ? 0.05f : 0.028f) + i * (6.2831855f / Math.max(1, n));
			float r = (n > 3 ? 24.0f : 20.0f) + Mth.sin(t * 0.05f + i) * 2.0f;
			orbs[i].x = Mth.cos(a) * r;
			orbs[i].z = Mth.sin(a) * r;
			orbs[i].y = orbY[i] + Mth.sin(t * 0.07f + i * 1.3f) * 4.0f - 6.0f + (i % 3) * 5.0f;
			orbs[i].yRot = t * 0.1f;
		}
	}
}
