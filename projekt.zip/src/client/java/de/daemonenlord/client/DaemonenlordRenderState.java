package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class DaemonenlordRenderState extends LivingEntityRenderState {
	public int castState;
	public boolean revived;
}
