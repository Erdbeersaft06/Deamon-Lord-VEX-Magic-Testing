package de.daemonenlord.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.gear.Gear;
import de.daemonenlord.gear.GearEntity;

/**
 * Zeichnet die 3D-Ruestung an Position und Koerperdrehung des Besitzers (die Entity selbst ist nur ein Traeger).
 * Position/Drehung/Laufanimation werden beim Rendern vom Besitzer uebernommen -> keine Verzoegerung.
 */
public class GearRenderer extends MobRenderer<GearEntity, GearRenderState, GearModel> {
	private static final Identifier TEXTURE = DaemonenlordMod.id("textures/entity/gear.png");

	public GearRenderer(EntityRendererProvider.Context context) {
		super(context, new GearModel(context.bakeLayer(GearModel.LAYER)), 0.0f);
	}

	public boolean affectedByCulling(GearEntity entity) {
		return false;
	}

	@Override
	public GearRenderState createRenderState() {
		return new GearRenderState();
	}

	@Override
	public void extractRenderState(GearEntity entity, GearRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.mask = 0;
		Entity o = entity.level().getEntity(entity.getOwnerId());
		if (!(o instanceof LivingEntity p) || p.isInvisible() || p.isSpectator()) return;
		Minecraft mc = Minecraft.getInstance();
		if (p == mc.player && mc.options.getCameraType().isFirstPerson()) return;
		state.mask = Gear.mask(p);
		state.x = Mth.lerp((double) partialTick, p.xOld, p.getX());
		state.y = Mth.lerp((double) partialTick, p.yOld, p.getY());
		state.z = Mth.lerp((double) partialTick, p.zOld, p.getZ());
		float body = Mth.rotLerp(partialTick, p.yBodyRotO, p.yBodyRot);
		float head = Mth.rotLerp(partialTick, p.yHeadRotO, p.yHeadRot);
		state.bodyRot = body;
		state.headYaw = Mth.wrapDegrees(head - body);
		state.headPitch = Mth.lerp(partialTick, p.xRotO, p.getXRot());
		state.wpos = p.walkAnimation.position(partialTick);
		state.wspd = p.walkAnimation.speed(partialTick);
		state.swing = p.getAttackAnim(partialTick);
		state.sneak = p.isCrouching();
	}

	@Override
	public Identifier getTextureLocation(GearRenderState state) {
		return TEXTURE;
	}
}
