package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class GearRenderState extends LivingEntityRenderState {
	/** Bit (Set*4 + Teil): 0 Helm, 1 Brust, 2 Hose, 3 Stiefel. */
	public int mask;
	public float wpos, wspd, swing, headYaw, headPitch;
	public boolean sneak;
}
