package de.daemonenlord.client;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;

/** Modell aus der Blockbench-Datei (konvertiert nach assets/daemonenlord/boss_model.json). */
public class DaemonenlordModel extends EntityModel<DaemonenlordRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("daemonenlord"), "main");

	private final ModelPart all;
	private final ModelPart body;
	private final ModelPart wingL;
	private final ModelPart wingR;
	private final ModelPart halo;

	public DaemonenlordModel(ModelPart root) {
		super(root);
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		this.halo = all.getChild("halo");
	}

	public static LayerDefinition createLayer() {
		JsonObject json;
		try (InputStream in = DaemonenlordModel.class.getResourceAsStream("/assets/daemonenlord/boss_model.json")) {
			if (in == null) throw new IllegalStateException("boss_model.json fehlt");
			json = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
		} catch (java.io.IOException e) {
			throw new IllegalStateException(e);
		}
		MeshDefinition mesh = new MeshDefinition();
		int[] counter = {0};
		build(mesh.getRoot(), json.getAsJsonObject("root"), counter);
		JsonArray tex = json.getAsJsonArray("tex");
		return LayerDefinition.create(mesh, tex.get(0).getAsInt(), tex.get(1).getAsInt());
	}

	private static void build(PartDefinition parent, JsonObject n, int[] counter) {
		String name = n.has("n") ? n.get("n").getAsString() : "c" + (counter[0]++);
		CubeListBuilder cb = CubeListBuilder.create();
		if (n.has("c")) {
			for (JsonElement ce : n.getAsJsonArray("c")) {
				JsonArray a = ce.getAsJsonArray();
				cb.texOffs(a.get(0).getAsInt(), a.get(1).getAsInt())
						.addBox(a.get(2).getAsFloat(), a.get(3).getAsFloat(), a.get(4).getAsFloat(),
								a.get(5).getAsFloat(), a.get(6).getAsFloat(), a.get(7).getAsFloat());
			}
		}
		JsonArray p = n.getAsJsonArray("p");
		float px = p.get(0).getAsFloat(), py = p.get(1).getAsFloat(), pz = p.get(2).getAsFloat();
		PartPose pose;
		if (n.has("r")) {
			JsonArray r = n.getAsJsonArray("r");
			pose = PartPose.offsetAndRotation(px, py, pz, r.get(0).getAsFloat(), r.get(1).getAsFloat(), r.get(2).getAsFloat());
		} else {
			pose = PartPose.offset(px, py, pz);
		}
		PartDefinition pd = parent.addOrReplaceChild(name, cb, pose);
		if (n.has("k")) {
			for (JsonElement k : n.getAsJsonArray("k")) build(pd, k.getAsJsonObject(), counter);
		}
	}

	@Override
	public void setupAnim(DaemonenlordRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		boolean ult = state.castState == 2;
		float flap = Mth.sin(t * (cast ? 0.22f : 0.08f)) * (cast ? 0.16f : 0.10f);
		float open = ult ? 0.55f : cast ? 0.22f : 0.0f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.body.xRot = ult ? -0.18f : 0.0f;
		this.halo.zRot = t * (ult ? 0.08f : cast ? 0.035f : 0.012f);
		this.all.y = 24.0f + Mth.sin(t * 0.07f) * 1.5f;
	}
}
