package de.daemonenlord.client;



import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;

/** Modell aus der Blockbench-Datei (konvertiert nach assets/daemonenlord/boss_model.json). */
public class DaemonenlordModel extends EntityModel<DaemonenlordRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("daemonenlord"), "main");

	private final ModelPart all;
	private final ModelPart body;
	private final ModelPart wingL;
	private final ModelPart wingR;
	private final ModelPart halo;

	public DaemonenlordModel(ModelPart root) {
		super(root);
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		this.halo = all.getChild("halo");
	}

	public static LayerDefinition createLayer() {
		return JsonModel.load("/assets/daemonenlord/boss_model.json");
	}

	@Override
	public void setupAnim(DaemonenlordRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		boolean ult = state.castState == 2;
		float flap = Mth.sin(t * (cast ? 0.22f : 0.08f)) * (cast ? 0.16f : 0.10f);
		float open = ult ? 0.55f : cast ? 0.22f : 0.0f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.body.xRot = ult ? -0.18f : 0.0f;
		this.halo.zRot = t * (ult ? 0.08f : cast ? 0.035f : 0.012f);
		this.all.y = 24.0f + Mth.sin(t * 0.07f) * 1.5f;
	}
}
