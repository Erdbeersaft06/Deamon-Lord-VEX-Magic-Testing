package de.daemonenlord.client;



import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.Attack;

/** Modell aus der Blockbench-Datei (konvertiert nach assets/daemonenlord/boss_model.json). */
public class DaemonenlordModel extends EntityModel<DaemonenlordRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("daemonenlord"), "main");

	private final ModelPart all;
	private final ModelPart body;
	private final ModelPart wingL;
	private final ModelPart wingR;
	private final ModelPart halo;
	private final float[] pose = {0f, 0f, 0.10f, 0.10f, 0f};
	private final ModelPart legL, legR, armL, armR, cape, head;

	public DaemonenlordModel(ModelPart root) {
		super(root);
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		this.halo = all.getChild("halo");
		this.legL = body.getChild("leg_l");
		this.legR = body.getChild("leg_r");
		this.armL = body.getChild("arm_l");
		this.armR = body.getChild("arm_r");
		this.cape = body.getChild("cape");
		this.head = body.getChild("head");
	}

	public static LayerDefinition createLayer() {
		return JsonModel.load("/assets/daemonenlord/boss_model.json");
	}

	@Override
	public void setupAnim(DaemonenlordRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		boolean ult = state.castState == 2;
		float flap = Mth.sin(t * (cast ? 0.22f : 0.08f)) * (cast ? 0.16f : 0.10f);
		float open = ult ? 0.55f : cast ? 0.22f : 0.0f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.halo.zRot = t * (ult ? 0.08f : cast ? 0.035f : 0.012f);
		this.all.y = 24.0f + Mth.sin(t * 0.07f) * 1.5f;

		// ---- Pose je Zauber (weich ueberblendet) ----
		// tgt: 0 armL vor, 1 armR vor, 2 armL aussen, 3 armR aussen, 4 Oberkoerper-Neigung
		float[] tgt = {0f, 0f, 0.10f, 0.10f, 0f};
		if (ult) {
			tgt = new float[] {-0.1f, -0.1f, 0.55f, 0.55f, -0.18f};
		} else if (state.castState >= 10) {
			Attack[] all = Attack.values();
			int id = state.castState - 10;
			Attack a = id < all.length ? all[id] : Attack.HELLFIRE;
			float s1 = Mth.sin(t * 0.25f);
			switch (a) {
				case HELLFIRE -> tgt = new float[] {0.2f, 1.35f, 0.25f, 0.0f, 0.05f};
				case BLADES -> tgt = new float[] {1.1f, 1.1f, 0.4f + s1 * 0.25f, 0.4f + s1 * 0.25f, 0.04f};
				case SHOCKWAVE -> tgt = new float[] {0.9f + 0.8f * s1, 0.9f + 0.8f * s1, 0.2f, 0.2f, 0.06f * s1};
				case STARFALL -> tgt = new float[] {-0.2f, -0.2f, 0.9f, 0.9f, -0.08f};
				case VOID -> tgt = new float[] {1.2f, 1.2f, -0.25f, -0.25f, 0.06f};
				case SUMMON -> tgt = new float[] {2.3f, 2.3f, 0.3f, 0.3f, 0.1f};
				case BEAM -> tgt = new float[] {1.0f, 1.5f, -0.2f, 0.0f, 0.04f};
				case SLAM -> tgt = new float[] {-0.3f, -0.3f, 0.5f, 0.5f, -0.12f};
				case SWORDS -> tgt = new float[] {0.1f, 0.1f, 1.0f, 1.0f, -0.05f};
				case DRAIN -> tgt = new float[] {1.3f, 1.3f, 0.6f, 0.6f, 0.04f};
				case HALO -> tgt = new float[] {0.0f, 0.0f, 1.45f, 1.45f, -0.04f};
				case LINK -> tgt = new float[] {1.0f, 1.0f, -0.3f, -0.3f, 0.03f};
				case AUSLOESCHUNG -> tgt = new float[] {-0.15f, -0.15f, 0.6f, 0.6f, -0.2f};
				case HINRICHTUNG -> tgt = new float[] {0.4f, 1.45f, 0.2f, 0.0f, 0.04f};
				default -> { }
			}
		}
		for (int i = 0; i < 5; i++) pose[i] += (tgt[i] - pose[i]) * 0.12f;

		// ---- Gehen (dezent) ----
		float pos = state.walkAnimationPos;
		float spd = Mth.clamp(state.walkAnimationSpeed * 1.6f, 0.0f, 1.0f);
		float swing = Mth.cos(pos * 0.45f);
		float step = Mth.sin(pos * 0.45f);
		this.legL.xRot = swing * 0.45f * spd;
		this.legR.xRot = -swing * 0.45f * spd;
		this.legL.zRot = 0.0f;
		this.legR.zRot = 0.0f;
		float breathe = Mth.sin(t * 0.09f) * 0.03f;
		this.armL.xRot = pose[0] - swing * 0.12f * spd;
		this.armR.xRot = pose[1] + swing * 0.12f * spd;
		this.armL.zRot = pose[2] + breathe;   // Teil-Raum: +x = aussen (linker Arm)
		this.armR.zRot = -(pose[3] + breathe);
		this.cape.xRot = 0.06f + spd * 0.25f + Mth.sin(t * 0.12f) * 0.03f;
		this.body.xRot = pose[4];
		this.body.yRot = swing * 0.04f * spd;
		this.body.zRot = 0.0f;
		this.head.yRot = Mth.clamp(state.yRot * 0.0174533f, -0.9f, 0.9f) - this.body.yRot;
		this.head.xRot = Mth.clamp(state.xRot * 0.0174533f, -0.5f, 0.5f) - pose[4] * 0.6f;
		this.all.y += Math.abs(step) * 0.4f * spd;
	}
}
