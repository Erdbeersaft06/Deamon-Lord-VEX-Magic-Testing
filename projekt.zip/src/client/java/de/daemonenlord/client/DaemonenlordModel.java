package de.daemonenlord.client;



import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;

/** Modell aus der Blockbench-Datei (konvertiert nach assets/daemonenlord/boss_model.json). */
public class DaemonenlordModel extends EntityModel<DaemonenlordRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("daemonenlord"), "main");

	private final ModelPart all;
	private final ModelPart body;
	private final ModelPart wingL;
	private final ModelPart wingR;
	private final ModelPart halo;
	private final ModelPart legL, legR, armL, armR, cape, head;

	public DaemonenlordModel(ModelPart root) {
		super(root);
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		this.halo = all.getChild("halo");
		this.legL = body.getChild("leg_l");
		this.legR = body.getChild("leg_r");
		this.armL = body.getChild("arm_l");
		this.armR = body.getChild("arm_r");
		this.cape = body.getChild("cape");
		this.head = body.getChild("head");
	}

	public static LayerDefinition createLayer() {
		return JsonModel.load("/assets/daemonenlord/boss_model.json");
	}

	@Override
	public void setupAnim(DaemonenlordRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		boolean ult = state.castState == 2;
		float flap = Mth.sin(t * (cast ? 0.22f : 0.08f)) * (cast ? 0.16f : 0.10f);
		float open = ult ? 0.55f : cast ? 0.22f : 0.0f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.body.xRot = ult ? -0.18f : 0.0f;
		this.halo.zRot = t * (ult ? 0.08f : cast ? 0.035f : 0.012f);
		this.all.y = 24.0f + Mth.sin(t * 0.07f) * 1.5f;

		// ---- Bewegungsanimation ----
		float pos = state.walkAnimationPos;
		float spd = Mth.clamp(state.walkAnimationSpeed * 1.6f, 0.0f, 1.0f);
		float swing = Mth.cos(pos * 0.45f);
		float step = Mth.sin(pos * 0.45f);
		this.legL.xRot = swing * 0.75f * spd;
		this.legR.xRot = -swing * 0.75f * spd;
		this.legL.zRot = 0.0f;
		this.legR.zRot = 0.0f;
		float breathe = Mth.sin(t * 0.09f) * 0.04f;
		float armOpen = ult ? 0.9f : cast ? 0.35f : 0.0f;
		float armLift = cast ? Mth.sin(t * 0.3f) * 0.12f : 0.0f;
		this.armL.xRot = -swing * 0.5f * spd + armLift;
		this.armR.xRot = swing * 0.5f * spd + armLift;
		this.armL.zRot = -(0.06f + breathe + armOpen);
		this.armR.zRot = 0.06f + breathe + armOpen;
		this.cape.xRot = 0.08f + spd * 0.35f + Mth.sin(t * 0.12f) * 0.04f + Math.abs(step) * 0.08f * spd;
		this.body.yRot = swing * 0.10f * spd;
		this.body.zRot = step * 0.03f * spd;
		this.head.yRot = Mth.clamp(state.yRot * 0.0174533f, -0.9f, 0.9f) - this.body.yRot;
		this.head.xRot = Mth.clamp(state.xRot * 0.0174533f, -0.5f, 0.5f) + Math.abs(step) * 0.03f * spd;
		this.all.y += Math.abs(step) * 0.8f * spd;
	}
}
