package de.daemonenlord.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.Attack;

/**
 * Modell des Daemonenlords (assets/daemonenlord/boss_model.json, erzeugt von tools/gen).
 * Hierarchie: all -> leg_l/leg_r (-> shin), body (head+Hoerner, arm -> forearm -> weapon_r, wing -> ua -> fo -> Finger, cape -> cape2 -> cape3), halo.
 */
public class DaemonenlordModel extends EntityModel<DaemonenlordRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(DaemonenlordMod.id("daemonenlord"), "main");

	// Posen: {L-xRot, L-aussen, L-Unterarm, R-xRot, R-aussen, R-Unterarm, Oberkoerper-Neigung}
	private static final float[] IDLE = {0.05f, 0.12f, -0.45f, -0.35f, 0.10f, -0.95f, 0.00f};
	private static final float[] CAST = {-1.20f, 0.25f, -0.50f, -1.10f, 0.15f, -0.40f, 0.05f};
	private static final float[] WIDE = {-0.70f, 1.00f, -0.40f, -0.70f, 1.00f, -0.40f, -0.12f};
	private static final float[] THRUST = {-1.30f, 0.10f, -0.20f, -0.25f, 0.05f, -0.30f, 0.12f};

	private final ModelPart all, body, head, armL, armR, foreL, foreR, legL, legR, shinL, shinR;
	private final ModelPart wingL, wingR, foL, foR, cape, cape2, cape3, halo;
	private final float wingLy, wingRy, foLz, foRz;
	private final float[] pose = IDLE.clone();

	public DaemonenlordModel(ModelPart root) {
		super(root);
		this.all = root.getChild("all");
		this.body = all.getChild("body");
		this.halo = all.getChild("halo");
		this.legL = all.getChild("leg_l");
		this.legR = all.getChild("leg_r");
		this.shinL = legL.getChild("shin_l");
		this.shinR = legR.getChild("shin_r");
		this.head = body.getChild("head");
		this.armL = body.getChild("arm_l");
		this.armR = body.getChild("arm_r");
		this.foreL = armL.getChild("forearm_l");
		this.foreR = armR.getChild("forearm_r");
		this.wingL = body.getChild("wing_l");
		this.wingR = body.getChild("wing_r");
		this.foL = wingL.getChild("ua_l").getChild("fo_l");
		this.foR = wingR.getChild("ua_r").getChild("fo_r");
		this.cape = body.getChild("cape");
		this.cape2 = cape.getChild("cape2");
		this.cape3 = cape2.getChild("cape3");
		this.wingLy = wingL.yRot;
		this.wingRy = wingR.yRot;
		this.foLz = foL.zRot;
		this.foRz = foR.zRot;
	}

	public static LayerDefinition createLayer() {
		return JsonModel.load("/assets/daemonenlord/boss_model.json");
	}

	@Override
	public void setupAnim(DaemonenlordRenderState state) {
		super.setupAnim(state);
		float t = state.ageInTicks;
		boolean cast = state.castState != 0;
		boolean ult = state.castState == 2;
		float s1 = Mth.sin(t * 0.25f);

		// ---- Zielpose je Zauber
		float[] tgt = IDLE;
		if (ult) {
			tgt = WIDE;
		} else if (state.castState >= 10) {
			Attack[] all = Attack.values();
			int id = state.castState - 10;
			Attack a = id < all.length ? all[id] : Attack.HELLFIRE;
			switch (a) {
				case SLAM: case SHOCKWAVE: case HINRICHTUNG:
					tgt = new float[] {-1.2f, 0.20f, -0.30f, -2.1f + s1 * 0.5f, 0.10f, -0.30f, 0.10f + s1 * 0.08f};
					break;
				case BEAM: case BLADES: case SWORDS:
					tgt = THRUST;
					break;
				case STARFALL: case SUMMON: case HALO: case AUSLOESCHUNG: case SONNENZORN: case ULTIMATE:
					tgt = WIDE;
					break;
				default:
					tgt = CAST;
					break;
			}
		}
		for (int i = 0; i < 7; i++) pose[i] += (tgt[i] - pose[i]) * 0.12f;

		// ---- Gehen
		float pos = state.walkAnimationPos;
		float spd = Mth.clamp(state.walkAnimationSpeed * 1.6f, 0.0f, 1.0f);
		float swing = Mth.cos(pos * 0.45f);
		float step = Mth.sin(pos * 0.45f);
		this.legL.xRot = swing * 0.50f * spd;
		this.legR.xRot = -swing * 0.50f * spd;
		this.shinL.xRot = Math.max(0f, -swing) * 0.55f * spd;
		this.shinR.xRot = Math.max(0f, swing) * 0.55f * spd;
		this.all.y = 24.0f + Math.abs(step) * 0.8f * spd + Mth.sin(t * 0.06f) * 0.4f;

		// ---- Koerper / Kopf
		this.body.xRot = pose[6] + spd * 0.05f;
		this.body.yRot = swing * 0.05f * spd;
		this.body.zRot = Mth.sin(t * 0.05f) * 0.015f;
		this.head.yRot = Mth.clamp(state.yRot * 0.0174533f, -0.9f, 0.9f) - this.body.yRot;
		this.head.xRot = Mth.clamp(state.xRot * 0.0174533f, -0.5f, 0.5f) - pose[6] * 0.6f;

		// ---- Arme
		float breathe = Mth.sin(t * 0.09f) * 0.03f;
		float arms = cast ? 0f : 1f;
		this.armL.xRot = pose[0] - swing * 0.15f * spd * arms;
		this.armL.zRot = pose[1] + breathe;
		this.foreL.xRot = pose[2];
		this.armR.xRot = pose[3];
		this.armR.zRot = -(pose[4] + breathe);
		this.foreR.xRot = pose[5];

		// ---- Fluegel
		float flap = Mth.sin(t * (cast ? 0.20f : 0.07f)) * (cast ? 0.20f : 0.12f);
		float open = ult ? 0.50f : cast ? 0.25f : 0.0f;
		this.wingL.zRot = flap + open;
		this.wingR.zRot = -(flap + open);
		this.wingL.yRot = wingLy - open * 0.5f;
		this.wingR.yRot = wingRy + open * 0.5f;
		this.foL.zRot = foLz + flap * 0.6f;
		this.foR.zRot = foRz - flap * 0.6f;

		// ---- Umhang
		this.cape.xRot = 0.06f + spd * 0.25f + Mth.sin(t * 0.12f) * 0.03f;
		this.cape2.xRot = 0.05f + spd * 0.20f + Mth.sin(t * 0.12f - 0.8f) * 0.06f;
		this.cape3.xRot = 0.04f + spd * 0.15f + Mth.sin(t * 0.12f - 1.6f) * 0.08f;

		// ---- Dornenkrone
		this.halo.zRot = t * (ult ? 0.08f : cast ? 0.035f : 0.012f);
	}
}
