package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class GoddessRenderState extends LivingEntityRenderState {
	public int castState;
}
