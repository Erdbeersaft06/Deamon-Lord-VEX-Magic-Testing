package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.duo.GoddessEntity;

public class GoddessRenderer extends MobRenderer<GoddessEntity, GoddessRenderState, GoddessModel> {
	private static final Identifier TEX_SOL = DaemonenlordMod.id("textures/entity/solara.png");
	private static final Identifier TEX_LUN = DaemonenlordMod.id("textures/entity/lunara.png");
	private static final int FULL_BRIGHT = 15728880;
	private final boolean sol;

	public GoddessRenderer(EntityRendererProvider.Context context, boolean sol) {
		super(context, new GoddessModel(context.bakeLayer(sol ? GoddessModel.SOLARA : GoddessModel.LUNARA), sol), 1.3f);
		this.sol = sol;
	}

	@Override
	public GoddessRenderState createRenderState() {
		return new GoddessRenderState();
	}

	@Override
	public void extractRenderState(GoddessEntity entity, GoddessRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.castState = entity.getCastState();
		state.lightCoords = FULL_BRIGHT;
	}

	@Override
	public Identifier getTextureLocation(GoddessRenderState state) {
		return sol ? TEX_SOL : TEX_LUN;
	}
}
