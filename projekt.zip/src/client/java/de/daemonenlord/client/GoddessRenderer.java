package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.duo.GoddessEntity;

public class GoddessRenderer extends MobRenderer<GoddessEntity, GoddessRenderState, GoddessModel> {
	private static final Identifier TEX_SOL = DaemonenlordMod.id("textures/entity/solara.png");
	private static final Identifier TEX_LUN = DaemonenlordMod.id("textures/entity/lunara.png");
	private static final Identifier TEX_FUS = DaemonenlordMod.id("textures/entity/fusion.png");
	private static final int FULL_BRIGHT = 15728880;
	private final int kind;   // 0 Solara, 1 Lunara, 2 Fusion

	public GoddessRenderer(EntityRendererProvider.Context context, int kind) {
		super(context, new GoddessModel(context.bakeLayer(kind == 0 ? GoddessModel.SOLARA : kind == 1 ? GoddessModel.LUNARA : GoddessModel.FUSION), kind == 0), 1.3f);
		this.kind = kind;
	}

	@Override
	public GoddessRenderState createRenderState() {
		return new GoddessRenderState();
	}

	@Override
	public void extractRenderState(GoddessEntity entity, GoddessRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.castState = entity.getCastState();
		state.lightCoords = FULL_BRIGHT;
	}

	@Override
	public Identifier getTextureLocation(GoddessRenderState state) {
		return kind == 0 ? TEX_SOL : kind == 1 ? TEX_LUN : TEX_FUS;
	}
}
