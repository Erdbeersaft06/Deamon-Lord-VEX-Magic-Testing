package de.daemonenlord;

import net.minecraft.resources.Identifier;

import net.fabricmc.api.ModInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.daemonenlord.command.BossCommands;
import de.daemonenlord.entity.ModEntities;

public class DaemonenlordMod implements ModInitializer {
	public static final String MOD_ID = "daemonenlord";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModEntities.initialize();
		BossCommands.register();
		LOGGER.info("Der Daemonenlord erwacht. /daemonenlord spawn");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
