package de.daemonenlord.party;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.gear.Gear;

/**
 * Parties (nur im Arbeitsspeicher): Einladen, Verlassen, Boss-Kampf starten.
 * Traegt ein Mitglied das volle Tank-Set (4/4), ist es der Tank der Gruppe und faengt
 * {@link #TANK_SHARE} des Schadens aller anderen Mitglieder ab (Treffer: siehe GearEvents).
 */
public final class PartyManager {
	private PartyManager() {}

	/** Anteil des Schadens, den der Tank den anderen Mitgliedern abnimmt. */
	public static final float TANK_SHARE = 0.30f;
	/** Maximale Entfernung zum Tank, damit er abfangen kann. */
	public static final double TANK_RANGE = 50.0;
	private static final long INVITE_MS = 60_000L;

	public static final class Party {
		public UUID leader;
		public final List<UUID> members = new ArrayList<>();
		UUID lastTank;
	}

	private record Invite(UUID leader, long until) {}

	private static final Map<UUID, Party> BY_PLAYER = new HashMap<>();
	private static final Map<UUID, Invite> INVITES = new HashMap<>();

	public static void register() {
		ServerTickEvents.END_SERVER_TICK.register(PartyManager::tick);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> { BY_PLAYER.clear(); INVITES.clear(); });
	}

	// ------------------------------------------------------------------ Abfragen
	public static Party of(UUID id) { return BY_PLAYER.get(id); }

	public static boolean sameParty(ServerPlayer a, ServerPlayer b) {
		Party p = BY_PLAYER.get(a.getUUID());
		return p != null && p == BY_PLAYER.get(b.getUUID());
	}

	/** Der Tank der Gruppe: erstes lebendes Mitglied mit 4/4 Tank-Ruestung (oder null). */
	public static ServerPlayer tank(MinecraftServer server, Party party) {
		for (UUID id : party.members) {
			ServerPlayer sp = server.getPlayerList().getPlayer(id);
			if (sp != null && sp.isAlive() && Gear.count(sp, Gear.Set.TANK) >= 4) return sp;
		}
		return null;
	}

	// ------------------------------------------------------------------ Nachrichten
	private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

	public static void tell(ServerPlayer p, String msg) {
		Fx.cmd((ServerLevel) p.level(), p.position(), "tellraw " + p.getStringUUID() + " {text:\"" + esc(msg) + "\"}");
	}

	public static void tellAll(MinecraftServer server, Party party, String msg) {
		for (UUID id : party.members) {
			ServerPlayer sp = server.getPlayerList().getPlayer(id);
			if (sp != null) tell(sp, msg);
		}
	}

	// ------------------------------------------------------------------ Aktionen (liefern eine Fehlermeldung oder null)
	public static String create(ServerPlayer p) {
		if (BY_PLAYER.containsKey(p.getUUID())) return "Du bist schon in einer Party. (/party leave)";
		Party party = new Party();
		party.leader = p.getUUID();
		party.members.add(p.getUUID());
		BY_PLAYER.put(p.getUUID(), party);
		return null;
	}

	public static String invite(ServerPlayer leader, ServerPlayer target) {
		Party party = BY_PLAYER.get(leader.getUUID());
		if (party == null) return "Du bist in keiner Party. (/party create)";
		if (!party.leader.equals(leader.getUUID())) return "Nur der Anführer kann einladen.";
		if (target == leader) return "Du kannst dich nicht selbst einladen.";
		if (BY_PLAYER.containsKey(target.getUUID())) return target.getScoreboardName() + " ist schon in einer Party.";
		INVITES.put(target.getUUID(), new Invite(leader.getUUID(), System.currentTimeMillis() + INVITE_MS));
		tell(target, "§6" + leader.getScoreboardName() + " §7lädt dich in seine Party ein: §a/party accept §7oder §c/party decline §7(60 s)");
		return null;
	}

	public static String accept(ServerPlayer p) {
		Invite inv = INVITES.remove(p.getUUID());
		if (inv == null || inv.until() < System.currentTimeMillis()) return "Du hast keine offene Einladung.";
		Party party = BY_PLAYER.get(inv.leader());
		if (party == null) return "Die Party existiert nicht mehr.";
		if (BY_PLAYER.containsKey(p.getUUID())) return "Du bist schon in einer Party.";
		party.members.add(p.getUUID());
		BY_PLAYER.put(p.getUUID(), party);
		tellAll(p.level().getServer(), party, "§a" + p.getScoreboardName() + " ist der Party beigetreten.");
		return null;
	}

	public static String decline(ServerPlayer p) {
		return INVITES.remove(p.getUUID()) == null ? "Du hast keine offene Einladung." : null;
	}

	public static String leave(ServerPlayer p) {
		Party party = BY_PLAYER.get(p.getUUID());
		if (party == null) return "Du bist in keiner Party.";
		MinecraftServer server = p.level().getServer();
		remove(server, party, p.getUUID(), p.getScoreboardName() + " hat die Party verlassen.");
		tell(p, "§7Du hast die Party verlassen.");
		return null;
	}

	public static String kick(ServerPlayer leader, ServerPlayer target) {
		Party party = BY_PLAYER.get(leader.getUUID());
		if (party == null) return "Du bist in keiner Party.";
		if (!party.leader.equals(leader.getUUID())) return "Nur der Anführer kann Mitglieder entfernen.";
		if (target == leader || BY_PLAYER.get(target.getUUID()) != party) return target.getScoreboardName() + " ist nicht in deiner Party.";
		remove(leader.level().getServer(), party, target.getUUID(), target.getScoreboardName() + " wurde aus der Party entfernt.");
		tell(target, "§cDu wurdest aus der Party entfernt.");
		return null;
	}

	/** Entfernt ein Mitglied; der naechste wird Anfuehrer, eine leere Party loest sich auf. */
	private static void remove(MinecraftServer server, Party party, UUID id, String msg) {
		party.members.remove(id);
		BY_PLAYER.remove(id);
		if (party.members.isEmpty()) return;
		if (party.leader.equals(id)) {
			party.leader = party.members.get(0);
			ServerPlayer nl = server.getPlayerList().getPlayer(party.leader);
			if (nl != null) msg += " " + nl.getScoreboardName() + " ist jetzt Anführer.";
		}
		tellAll(server, party, "§7" + msg);
	}

	/** Anfuehrer teleportiert alle Mitglieder zu sich. */
	public static String warp(ServerPlayer leader) {
		Party party = BY_PLAYER.get(leader.getUUID());
		if (party == null) return "Du bist in keiner Party.";
		if (!party.leader.equals(leader.getUUID())) return "Nur der Anführer kann die Gruppe holen.";
		MinecraftServer server = leader.level().getServer();
		for (UUID id : party.members) {
			if (id.equals(leader.getUUID())) continue;
			ServerPlayer sp = server.getPlayerList().getPlayer(id);
			if (sp != null) Fx.cmd((ServerLevel) leader.level(), leader.position(), "tp " + sp.getStringUUID() + " " + leader.getStringUUID());
		}
		tellAll(server, party, "§6Der Anführer hat die Gruppe zusammengeholt.");
		return null;
	}

	/** Startet einen Boss-Kampf ~12 Bloecke vor dem Anfuehrer. kind: daemonenlord | solunar */
	public static String boss(ServerPlayer leader, String kind) {
		Party party = BY_PLAYER.get(leader.getUUID());
		if (party == null) return "Du bist in keiner Party. (/party create)";
		if (!party.leader.equals(leader.getUUID())) return "Nur der Anführer kann den Boss-Kampf starten.";
		String cmd = kind.equals("daemonenlord") ? "daemonenlord" : kind.equals("solunar") ? "solunar" : null;
		if (cmd == null) return "Unbekannter Boss. /party boss daemonenlord | solunar";
		Vec3 look = leader.getLookAngle();
		Vec3 dir = new Vec3(look.x, 0.0, look.z);
		dir = dir.lengthSqr() < 1.0e-4 ? new Vec3(0, 0, 1) : dir.normalize();
		Vec3 at = leader.position().add(dir.scale(12.0));
		ServerLevel level = (ServerLevel) leader.level();
		Fx.cmd(level, leader.position(), String.format(Locale.ROOT, "%s spawn %.2f %.2f %.2f", cmd, at.x, at.y, at.z));
		tellAll(leader.level().getServer(), party, "§6Boss-Kampf gestartet! §7(" + party.members.size() + " Spieler)");
		return null;
	}

	public static List<String> describe(MinecraftServer server, Party party) {
		List<String> out = new ArrayList<>();
		ServerPlayer tank = tank(server, party);
		out.add("§6Party §7(" + party.members.size() + " Mitglieder)");
		for (UUID id : party.members) {
			ServerPlayer sp = server.getPlayerList().getPlayer(id);
			if (sp == null) continue;
			String tag = (id.equals(party.leader) ? " §e[Anführer]" : "") + (sp == tank ? " §b[Tank]" : "");
			out.add("§f" + sp.getScoreboardName() + tag + " §c" + Math.round(sp.getHealth()) + "§7/§c" + Math.round(sp.getMaxHealth()) + " HP");
		}
		if (tank != null) out.add("§7Der Tank fängt " + Math.round(TANK_SHARE * 100) + "% des Schadens der anderen ab.");
		return out;
	}

	// ------------------------------------------------------------------ Tick: Offline-Spieler, Einladungen, Tank-Wechsel
	private static void tick(MinecraftServer server) {
		if (server.getTickCount() % 20 != 0) return;
		long now = System.currentTimeMillis();
		INVITES.entrySet().removeIf(e -> e.getValue().until() < now);
		for (Party party : new ArrayList<>(BY_PLAYER.values().stream().distinct().toList())) {
			for (UUID id : new ArrayList<>(party.members)) {
				if (server.getPlayerList().getPlayer(id) == null) remove(server, party, id, "Ein Spieler hat die Party verlassen (offline).");
			}
			if (party.members.isEmpty()) continue;
			ServerPlayer t = tank(server, party);
			UUID tid = t == null ? null : t.getUUID();
			if (!java.util.Objects.equals(tid, party.lastTank)) {
				party.lastTank = tid;
				if (t != null) tellAll(server, party, "§b" + t.getScoreboardName() + " §7ist jetzt der §bTank §7der Gruppe und fängt " + Math.round(TANK_SHARE * 100) + "% des Schadens ab.");
				else tellAll(server, party, "§7Die Gruppe hat keinen Tank mehr.");
			}
		}
	}
}
