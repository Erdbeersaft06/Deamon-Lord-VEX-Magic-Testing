package de.daemonenlord.entity;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.DaemonenlordEntity;
import de.daemonenlord.boss.FxEntity;
import de.daemonenlord.duo.GoddessEntity;
import de.daemonenlord.gear.GearEntity;

public class ModEntities {
	public static final ResourceKey<EntityType<?>> DAEMONENLORD_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("daemonenlord"));

	public static final EntityType<DaemonenlordEntity> DAEMONENLORD = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, DAEMONENLORD_KEY,
			EntityType.Builder.<DaemonenlordEntity>of(DaemonenlordEntity::new, MobCategory.MONSTER)
					.sized(2.6f, 6.4f)
					.fireImmune()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(DAEMONENLORD_KEY));

	public static final ResourceKey<EntityType<?>> FX_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("fx"));

	public static final EntityType<FxEntity> FX = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, FX_KEY,
			EntityType.Builder.<FxEntity>of(FxEntity::new, MobCategory.MISC)
					.sized(6.0f, 6.0f)
					.fireImmune()
					.noSave()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(FX_KEY));

	public static final ResourceKey<EntityType<?>> SOLARA_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("solara"));

	public static final EntityType<GoddessEntity> SOLARA = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, SOLARA_KEY,
			EntityType.Builder.<GoddessEntity>of((type, level) -> new GoddessEntity(type, level, true), MobCategory.MONSTER)
					.sized(1.6f, 4.4f)
					.fireImmune()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(SOLARA_KEY));

	public static final ResourceKey<EntityType<?>> LUNARA_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("lunara"));

	public static final EntityType<GoddessEntity> LUNARA = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, LUNARA_KEY,
			EntityType.Builder.<GoddessEntity>of((type, level) -> new GoddessEntity(type, level, false), MobCategory.MONSTER)
					.sized(1.6f, 4.4f)
					.fireImmune()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(LUNARA_KEY));

	public static final ResourceKey<EntityType<?>> FUSION_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("fusion"));

	public static final EntityType<GoddessEntity> FUSION = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, FUSION_KEY,
			EntityType.Builder.<GoddessEntity>of((type, level) -> { GoddessEntity g = new GoddessEntity(type, level, true); g.makeFusion(); return g; }, MobCategory.MONSTER)
					.sized(1.8f, 4.6f)
					.fireImmune()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(FUSION_KEY));

	public static final ResourceKey<EntityType<?>> GEAR_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("gear"));

	public static final EntityType<GearEntity> GEAR = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, GEAR_KEY,
			EntityType.Builder.<GearEntity>of(GearEntity::new, MobCategory.MISC)
					.sized(0.6f, 1.8f)
					.fireImmune()
					.noSave()
					.clientTrackingRange(10)
					.updateInterval(1)
					.build(GEAR_KEY));

	public static void initialize() {
		FabricDefaultAttributeRegistry.register(GEAR, GearEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(FX, FxEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(DAEMONENLORD, DaemonenlordEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(SOLARA, GoddessEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(LUNARA, GoddessEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(FUSION, GoddessEntity.createAttributes());
	}
}
