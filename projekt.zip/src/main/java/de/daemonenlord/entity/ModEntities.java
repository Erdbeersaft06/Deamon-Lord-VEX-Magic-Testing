package de.daemonenlord.entity;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.boss.DaemonenlordEntity;
import de.daemonenlord.boss.FxEntity;

public class ModEntities {
	public static final ResourceKey<EntityType<?>> DAEMONENLORD_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("daemonenlord"));

	public static final EntityType<DaemonenlordEntity> DAEMONENLORD = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, DAEMONENLORD_KEY,
			EntityType.Builder.<DaemonenlordEntity>of(DaemonenlordEntity::new, MobCategory.MONSTER)
					.sized(2.6f, 6.4f)
					.fireImmune()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(DAEMONENLORD_KEY));

	public static final ResourceKey<EntityType<?>> FX_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, DaemonenlordMod.id("fx"));

	public static final EntityType<FxEntity> FX = Registry.register(
			BuiltInRegistries.ENTITY_TYPE, FX_KEY,
			EntityType.Builder.<FxEntity>of(FxEntity::new, MobCategory.MISC)
					.sized(6.0f, 6.0f)
					.fireImmune()
					.noSave()
					.clientTrackingRange(16)
					.updateInterval(1)
					.build(FX_KEY));

	public static void initialize() {
		FabricDefaultAttributeRegistry.register(FX, FxEntity.createAttributes());
		FabricDefaultAttributeRegistry.register(DAEMONENLORD, DaemonenlordEntity.createAttributes());
	}
}
