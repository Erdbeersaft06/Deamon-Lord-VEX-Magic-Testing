package de.daemonenlord.duo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.boss.FxEntity;
import de.daemonenlord.entity.ModEntities;

/**
 * Solara (Sonne) und Lunara (Mond): zwei Goettinnen, die immer zusammen kaempfen.
 * Eine Klasse, zwei Entity-Typen (sol = true -> Solara). Schaden: 10 Roh-Schaden = 1 Herz bei voller Netherite + Protection V
 * (Magie-Schaden ignoriert Ruestung, Protection V zieht 80 % ab) -> "normale Attacke" = 40 = 4 Herzen.
 */
public class GoddessEntity extends Monster {
	private static final EntityDataAccessor<Integer> STATE =
			SynchedEntityData.defineId(GoddessEntity.class, EntityDataSerializers.INT);

	/** Roh-Schaden je Stufe (nach Protection V: Hauptangriff 4 Herzen). */
	static final float DMG_ZONE = 29f, DMG_MAIN = 46f, DMG_HEAVY = 81f;
	/** Ultimate: Anteil der max. HP des Spielers. */
	static final float ULT_PCT = 1.5f;
	/** Zauber laufen 60 % schneller ab (Logik-Ticks pro echtem Tick). */
	static final float ATK_SPEED = 1.6f;

	/** Lebensdauer eines Effekts: in Logik-Ticks angegeben, in echte Ticks umgerechnet. */
	/** Cast-Zeit-Faktor: Zauber-Zeitleiste laeuft 1,5x so lange (Projektile bleiben gleich schnell). */
	static final float CAST_MULT = 1.5f;
	float castAcc = 0f;
	boolean castStep() { castAcc += 1f / CAST_MULT; if (castAcc >= 1f) { castAcc -= 1f; return true; } return false; }
	static int lifeC(int logicTicks) { return (int) Math.ceil(logicTicks * CAST_MULT / ATK_SPEED) + 2; }
	static FxEntity cfx(ServerLevel l, int kind, Vec3 pos, int life, float sxz, float sy) { return Fx.fx(l, kind, pos, lifeC(life), sxz, sy); }
	static FxEntity cbeam(ServerLevel l, FxEntity cur, Vec3 a, Vec3 b, int life, float w) { return Fx.beam(l, cur, a, b, lifeC(life), w); }
	static int life(int logicTicks) { return (int) Math.ceil(logicTicks / ATK_SPEED) + 2; }
	static FxEntity fx(ServerLevel l, int kind, Vec3 pos, int life, float sxz, float sy) { return Fx.fx(l, kind, pos, life(life), sxz, sy); }
	static FxEntity beam(ServerLevel l, FxEntity cur, Vec3 a, Vec3 b, int life, float w) { return Fx.beam(l, cur, a, b, life(life), w); }
	/** Anteil des Schadens, der auf die Partnerin uebergeht (Bund). */
	static final float BOND = 0.15f;
	public static float BASE_HEALTH = 900f;

	public enum Atk {
		// Solara
		SPEERREGEN("speerregen", "Goldener Speerregen", 0, 70, 0),
		LANZE("lanze", "Gleißende Lanze", 0, 70, 0),
		MORGENROETE("morgenroete", "Morgenröte", 0, 80, 0),
		SONNENSCHEIBE("sonnenscheibe", "Sonnenscheibe", 0, 100, 0),
		FLAMMENFLUEGEL("flammenfluegel", "Flammenflügel", 0, 80, 0),
		STRAHLENKRANZ("strahlenkranz", "Strahlenkranz", 0, 110, 0),
		LAEUTERNDES_FEUER("laeuterndes_feuer", "Läuterndes Feuer", 0, 110, 0),
		ZENIT("zenit", "Zenit", 0, 110, 0),
		GLUTSCHWUR("glutschwur", "Glutschwur", 0, 110, 0),
		SONNENKRONE("sonnenkrone", "Sonnenkrone", 0, 210, 1),
		// Lunara
		MONDSTURZ("mondsturz", "Mondsturz", 1, 80, 0),
		GEZEITENZUG("gezeitenzug", "Gezeitenzug", 1, 80, 0),
		FROSTMOND("frostmond", "Frostmond", 1, 80, 0),
		SILBERSICHELN("silbersicheln", "Silbersicheln", 1, 90, 0),
		SCHATTENSCHLEIER("schattenschleier", "Schattenschleier", 1, 110, 0),
		LUNASPIEGEL("lunaspiegel", "Lunaspiegel", 1, 120, 0),
		TRAUMFESSEL("traumfessel", "Traumfessel", 1, 120, 0),
		NACHTFLUT("nachtflut", "Nachtflut", 1, 130, 0),
		STERNENREIGEN("sternenreigen", "Sternenreigen", 1, 110, 0),
		MONDFINSTERNIS("mondfinsternis", "Mondfinsternis", 1, 220, 1),
		// Duo (Leiterin: Solara)
		SONNENFINSTERNIS("sonnenfinsternis", "Sonnenfinsternis", 2, 130, 0),
		ZWIELICHTLANZE("zwielichtlanze", "Zwielichtlanze", 2, 110, 0),
		TAG_NACHT_RAD("tag_nacht_rad", "Tag-Nacht-Rad", 2, 160, 0),
		HIMMELSBUND("himmelsbund", "Himmelsbund", 2, 170, 0),
		ZWILLINGSGESTIRN("zwillingsgestirn", "Zwillingsgestirn", 2, 240, 2);

		/** side: 0 Solara, 1 Lunara, 2 Duo. minPhase: 0 immer, 1 ab Daemmerung, 2 nur Finsternis. */
		public final String id, title; public final int side, duration, minPhase; public final boolean sol;
		Atk(String id, String title, int side, int duration, int minPhase) { this.id = id; this.title = title; this.side = side; this.duration = duration; this.minPhase = minPhase; this.sol = side == 0; }
		public boolean duo() { return side == 2; }
		public static Atk byId(String s) { for (Atk a : values()) if (a.id.equals(s)) return a; return null; }
	}

	public final boolean sol;
	private final ServerBossEvent bossEvent;
	final Random rnd = new Random();

	UUID partnerId = null;
	boolean enraged = false, bondGuard = false, decoy = false, inDuo = false, gestirnUsed = false;
	int decoyLife = 0, stun = 0, phase = 0, ultCd = 600;
	Atk attack = null;
	int atkTick = 0, cooldown = 80;
	float acc = 0f;
	/** Fusion: ein Koerper, zwei unsichtbare Zauber-Helfer (hell/dunkel). */
	boolean fusion = false, puppet = false;
	int fusionGrace = 0;
	GoddessEntity lightP = null, darkP = null, owner = null;
	Atk lastAttack = null;
	Vec3 lock = Vec3.ZERO, ov = null;
	double lift = 0;
	boolean frozen = false;
	FxEntity coreFx = null, aimFx = null, trackFx = null;
	final List<Parts.Part> parts = new ArrayList<>();
	final Set<UUID> marked = new HashSet<>();
	final List<Vec3> spots = new ArrayList<>();
	final List<UUID> decoys = new ArrayList<>();
	final java.util.Map<UUID, Integer> cd = new java.util.HashMap<>();

	public GoddessEntity(EntityType<? extends Monster> type, Level level, boolean sol) {
		super(type, level);
		this.sol = sol;
		this.setNoGravity(true);
		this.setPersistenceRequired();
		this.bossEvent = Fx.bossEvent(Component.literal(sol ? "§6§lSolara §8– §eGöttin der Sonne" : "§9§lLunara §8– §bGöttin des Mondes"));
		this.bossEvent.setColor(sol ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.BLUE);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, BASE_HEALTH)
				.add(Attributes.ARMOR, 10.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
				.add(Attributes.MOVEMENT_SPEED, 0.35)
				.add(Attributes.FOLLOW_RANGE, 96.0)
				.add(Attributes.ATTACK_DAMAGE, 10.0);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(STATE, 0);
	}

	public int getCastState() { return this.entityData.get(STATE); }
	void setCastState(int s) { this.entityData.set(STATE, s); }
	public boolean isSolara() { return sol; }
	public boolean isFusion() { return fusion; }

	/** Macht diese Entity zum Fusionsboss (Eklipsa). */
	public void makeFusion() {
		this.fusion = true;
		this.bossEvent.setName(Component.literal("§5§lEklipsa §8– §fSonne & Mond"));
		this.bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
	}
	public void fusionCast(Atk a) { FusionLogic.cast(this, a); }
	public boolean isDecoy() { return decoy; }

	public boolean isPushable() { return false; }
	protected void pushEntities() { }
	protected void doPush(Entity e) { }

	/** Setzt Lebenspunkte (Skalierung nach Spielerzahl wird vom Befehl berechnet). */
	public void setMaxHp(double hp) {
		var inst = this.getAttribute(Attributes.MAX_HEALTH);
		if (inst != null) inst.setBaseValue(hp);
		this.setHealth((float) hp);
	}

	public void link(GoddessEntity other) { this.partnerId = other.getUUID(); }

	GoddessEntity partner(ServerLevel sl) {
		if (owner != null) return owner.isAlive() ? owner : null;
		if (partnerId == null) return null;
		Entity e = sl.getEntity(partnerId);
		return e instanceof GoddessEntity g && g.isAlive() ? g : null;
	}

	/** Schadensfaktor: Wueterin +30 %, Phase Daemmerung x1.2, Finsternis x1.4. */
	float dmgFactor() { return (enraged ? 1.3f : 1.0f) * (phase == 0 ? 1.0f : phase == 1 ? 1.2f : 1.4f); }

	// ---- Bund: 15 % jedes Treffers gehen auf die Partnerin ----
	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		if (fusion && fusionGrace > 0) return false;
		if (decoy) {
			Vec3 c = this.position().add(0, 2.5, 0);
			Fx.sound(level, c, "minecraft:block.glass.break", 2.0f, 1.5f);
			Fx.flash(level, c, 6, 10);
			this.discard();
			return true;
		}
		// Lunaspiegel: Treffer auf die echte Lunara betaeubt sie, sie nimmt dann mehr Schaden
		if (!bondGuard && attack == Atk.LUNASPIEGEL && atkTick >= 15 && stun == 0) {
			stun = 80;
			SoloLogic.clearDecoys(level, this);
			Fx.sound(level, this.position().add(0, 2.5, 0), "minecraft:entity.shulker.hurt_close", 3.0f, 0.6f);
			Fx.actionbar(level, this.position(), 80, "Lunara ist betäubt – jetzt zuschlagen!", "aqua");
			endAttack();
		}
		float mul = stun > 0 ? 1.8f : 1.0f;
		boolean r = super.hurtServer(level, source, amount * mul);
		if (r && !bondGuard) {
			GoddessEntity p = partner(level);
			if (p != null) {
				p.bondGuard = true;
				Fx.resetIFrames(p);
				p.hurtServer(level, source, amount * BOND);
				p.bondGuard = false;
			}
		}
		return r;
	}

	// ---- Bossleiste ----
	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		if (!decoy) bossEvent.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		bossEvent.removePlayer(player);
	}

	@Override
	public void remove(RemovalReason reason) {
		bossEvent.removeAllPlayers();
		super.remove(reason);
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput out) {
		super.addAdditionalSaveData(out);
		out.putInt("sl_enraged", enraged ? 1 : 0);
		out.putInt("sl_decoy", decoy ? 1 : 0);
		out.putInt("sl_gestirn", gestirnUsed ? 1 : 0);
		out.putInt("sl_fusion", fusion ? 1 : 0);
		if (partnerId != null) out.putString("sl_partner", partnerId.toString());
	}

	@Override
	protected void readAdditionalSaveData(ValueInput in) {
		super.readAdditionalSaveData(in);
		enraged = in.getInt("sl_enraged").orElse(0) == 1;
		decoy = in.getInt("sl_decoy").orElse(0) == 1;
		gestirnUsed = in.getInt("sl_gestirn").orElse(0) == 1;
		if (in.getInt("sl_fusion").orElse(0) == 1) makeFusion();
		in.getString("sl_partner").ifPresent(s -> {
			try { partnerId = UUID.fromString(s); } catch (IllegalArgumentException ignored) { }
		});
	}

	// ---- Tod: die Partnerin wird zur Wueterin ----
	@Override
	public void die(DamageSource source) {
		super.die(source);
		if (decoy) return;
		if (this.level() instanceof ServerLevel sl) {
			SoloLogic.clearDecoys(sl, this);
			Vec3 c = this.position().add(0, 3, 0);
			if (fusion) {
				Fx.title(sl, c, 100, "EKLIPSA IST GEFALLEN", "Sonne und Mond ruhen endlich …", "light_purple");
				Fx.sound(sl, c, "minecraft:entity.ender_dragon.death", 6.0f, 0.8f);
				Fx.flash(sl, c, 80, 40);
				for (int i = 0; i < 12; i++) Fx.cmd(sl, c, "summon minecraft:experience_orb " + c.x + " " + c.y + " " + c.z + " {Value:300s}");
				lightP = null; darkP = null;
				return;
			}
			GoddessEntity p = partner(sl);
			if (p != null && !p.enraged) {
				p.enraged = true;
				p.cooldown = Math.min(p.cooldown, 20);
				if (p.inDuo) p.endAttack();
				Fx.title(sl, c, 90, sol ? "SOLARA IST GEFALLEN" : "LUNARA IST GEFALLEN", p.sol ? "Solara wird zur Wüterin …" : "Lunara wird zur Wüterin …", p.sol ? "gold" : "aqua");
				Fx.sound(sl, c, "minecraft:entity.wither.death", 5.0f, 0.8f);
			} else if (p == null) {
				FusionLogic.spawnFusion(sl, this);
			}
			Fx.flash(sl, c, 80, 40);
			for (int i = 0; i < 6; i++) {
				Fx.cmd(sl, c, "summon minecraft:experience_orb " + c.x + " " + c.y + " " + c.z + " {Value:300s}");
			}
		}
	}

	// ---- Tick ----
	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) return;
		if (!(this.level() instanceof ServerLevel sl)) return;
		if (decoy) { decoyTick(sl); return; }
		serverTick(sl);
	}

	private void decoyTick(ServerLevel sl) {
		this.setDeltaMovement(Vec3.ZERO);
		ServerPlayer t = nearestPlayer(sl);
		if (t != null) face(t);
		if (++decoyLife > 150) this.discard();
	}

	private void serverTick(ServerLevel sl) {
		Fx.currentRed = false;
		Fx.currentBlue = false;
		bossEvent.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0f, 1f));
		GoddessEntity pr = partner(sl);
		updatePhase(sl, pr);
		acc += ATK_SPEED;
		int steps = (int) acc;
		acc -= steps;
		for (int i = 0; i < steps; i++) tickParts(sl);
		if (ultCd > 0) ultCd--;

		ServerPlayer target = nearestPlayer(sl);
		if (target == null) {
			if (attack != null) endAttack();
			this.setDeltaMovement(this.getDeltaMovement().scale(0.9));
			setCastState(0);
			return;
		}
		face(target);
		if (fusion) {
			hover(sl, target);
			FusionLogic.run(this, sl, target, steps);
			return;
		}
		if (stun > 0) {
			stun--;
			this.setDeltaMovement(this.getDeltaMovement().scale(0.5));
			if (stun == 0) cooldown = 30;
			return;
		}
		if (inDuo) {
			// Duo-Zauber werden von der Leiterin gesteuert; Position kommt von dort
			if (pr == null || pr.attack == null || !pr.attack.duo()) { inDuo = false; ov = null; lift = 0; setCastState(0); }
			else { hover(sl, target); return; }
		}
		if (!frozen) hover(sl, target);
		else this.setDeltaMovement(this.getDeltaMovement().scale(0.8));

		if (attack != null) {
			for (int i = 0; i < steps && attack != null; i++) {
				if (!castStep()) continue;
				if (attack.duo()) DuoLogic.run(this, sl, pr, attack, atkTick, target);
				else SoloLogic.run(this, sl, attack, atkTick, target);
				if (attack != null && ++atkTick >= attack.duration) endAttack();
			}
		} else if (--cooldown <= 0) {
			if (pr != null && (pr.inDuo || (pr.attack != null && pr.atkTick < 30))) { cooldown = 5; return; }
			chooseAttack(pr);
		}
	}

	/** Phase nach durchschnittlicher Lebensenergie beider Goettinnen. */
	private void updatePhase(ServerLevel sl, GoddessEntity pr) {
		float a = this.getHealth() / this.getMaxHealth();
		float avg = pr == null ? a : (a + pr.getHealth() / pr.getMaxHealth()) / 2f;
		int np = avg > 0.66f ? 0 : avg > 0.33f ? 1 : 2;
		if (np > phase) {
			phase = np;
			if (sol || pr == null) {
				Vec3 c = this.position().add(0, 3, 0);
				Fx.title(sl, c, 90, np == 1 ? "DÄMMERUNG" : "FINSTERNIS", np == 1 ? "Die Göttinnen werden stärker …" : "Sonne und Mond verschmelzen …", np == 1 ? "gold" : "dark_purple");
				Fx.sound(sl, c, "minecraft:entity.wither.spawn", 4.0f, 1.3f);
			}
		}
		if (pr != null && pr.phase < phase) pr.phase = phase;
	}

	void chooseAttack(GoddessEntity pr) {
		// Duo-Zauber: nur die Leiterin (Solara), beide muessen leben
		if (sol && pr != null && !enraged && !pr.enraged && pr.attack == null && stun == 0 && pr.stun == 0) {
			double chance = phase == 0 ? 0.12 : phase == 1 ? 0.3 : 0.45;
			if (rnd.nextDouble() < chance) {
				List<Atk> d = new ArrayList<>();
				for (Atk a : Atk.values()) if (a.duo() && a != lastAttack && a.minPhase <= phase && !(a == Atk.ZWILLINGSGESTIRN && (gestirnUsed || rnd.nextInt(3) != 0))) d.add(a);
				if (!d.isEmpty()) { startDuo(d.get(rnd.nextInt(d.size())), pr); return; }
			}
		}
		List<Atk> pool = new ArrayList<>();
		for (Atk a : Atk.values()) {
			if (a.duo() || a.sol != sol || a == lastAttack || a.minPhase > phase) continue;
			if (puppet && a == Atk.LUNASPIEGEL) continue;
			if (a.minPhase > 0 && ultCd > 0) continue;
			pool.add(a);
		}
		if (pool.isEmpty()) return;
		start(pool.get(rnd.nextInt(pool.size())));
	}

	/** Startet einen Duo-Zauber; die Partnerin wird mitgesteuert. */
	public void startDuo(Atk a, GoddessEntity pr) {
		if (pr != null) { if (pr.attack != null) pr.endAttack(); pr.inDuo = true; pr.setCastState(1 + a.ordinal()); }
		if (a == Atk.ZWILLINGSGESTIRN) gestirnUsed = true;
		start(a);
		if (pr != null) pr.setCastState(1 + a.ordinal());
	}

	public void start(Atk a) {
		if (attack != null) endAttack();
		attack = a;
		atkTick = 0;
		lastAttack = a;
		marked.clear();
		spots.clear();
		setCastState(1 + a.ordinal());
		if (a.minPhase > 0 && a.side != 2) ultCd = 1500;
		if (this.level() instanceof ServerLevel sl) {
			Fx.sound(sl, this.position().add(0, 3, 0), sol ? "minecraft:block.beacon.activate" : "minecraft:block.amethyst_block.resonate", 4.0f, sol ? 1.2f : 0.8f);
			SoloLogic.begin(this, sl, a);
		}
	}

	void endAttack() {
		if (attack == Atk.LUNASPIEGEL && this.level() instanceof ServerLevel dl) SoloLogic.clearDecoys(dl, this);
		attack = null;
		setCastState(0);
		cooldown = (int) (((enraged ? 40 : 70) + rnd.nextInt(30)) / ATK_SPEED);
		ov = null; lift = 0; frozen = false;
		if (coreFx != null && !coreFx.isRemoved()) coreFx.discard();
		coreFx = null;
		if (trackFx != null && !trackFx.isRemoved()) trackFx.discard();
		trackFx = null;
		if (this.level() instanceof ServerLevel sl) {
			GoddessEntity p = partner(sl);
			if (p != null && p.inDuo) { p.inDuo = false; p.ov = null; p.lift = 0; p.setCastState(0); p.cooldown = Math.max(p.cooldown, 25); }
		}
	}

	private void face(ServerPlayer t) {
		double dx = t.getX() - getX(), dz = t.getZ() - getZ();
		float yaw = (float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
		this.setYRot(yaw);
		this.setYBodyRot(yaw);
		this.setYHeadRot(yaw);
	}

	/** Beide umkreisen den Spieler auf gegenueberliegenden Seiten (oder fliegen zur Zielposition ov). */
	private void hover(ServerLevel sl, ServerPlayer t) {
		double wx, wy, wz, k = 0.016, vmax = 0.12;
		if (ov != null) { wx = ov.x; wy = ov.y; wz = ov.z; k = 0.06; vmax = 0.35; }
		else {
			double ang = tickCount * 0.0024 + (sol ? 0.0 : Math.PI);
			double rad = fusion ? 9.0 : 15.0;
			wx = t.getX() + Math.cos(ang) * rad; wz = t.getZ() + Math.sin(ang) * rad;
			double gy = Fx.groundY(sl, t.getX(), t.getY() + 2, t.getZ());
			wy = gy + 1.5 + lift + Math.sin(tickCount * 0.07 + (sol ? 0 : 1.5)) * 0.3;
		}
		Vec3 to = new Vec3(wx - getX(), wy - getY(), wz - getZ());
		double len = to.length();
		Vec3 v = len > 0.001 ? to.scale(Math.min(len * k, vmax) / len) : Vec3.ZERO;
		Vec3 cur = this.getDeltaMovement();
		this.setDeltaMovement(cur.x + (v.x - cur.x) * 0.2, cur.y + (v.y - cur.y) * 0.2, cur.z + (v.z - cur.z) * 0.2);
	}

	ServerPlayer nearestPlayer(ServerLevel sl) {
		ServerPlayer best = null; double bd = Double.MAX_VALUE;
		for (ServerPlayer p : Fx.players(sl, this.position(), 90)) {
			double dd = p.distanceToSqr(this);
			if (dd < bd) { bd = dd; best = p; }
		}
		return best;
	}

	ServerPlayer randomPlayer(ServerLevel sl) {
		List<ServerPlayer> l = Fx.players(sl, this.position(), 90);
		return l.isEmpty() ? null : l.get(rnd.nextInt(l.size()));
	}

	ServerPlayer playerById(ServerLevel sl, UUID id) {
		for (ServerPlayer p : sl.players()) if (p.getUUID().equals(id) && p.isAlive()) return p;
		return null;
	}

	// ---- Hilfsfunktionen ----
	Vec3 ground(ServerLevel l, double x, double y, double z) { return new Vec3(x, Fx.groundY(l, x, y, z), z); }
	Vec3 hand() { return this.position().add(0, 3.6, 0); }

	void tint(FxEntity f) { if (f != null && !sol) f.setTint(5); }

	void harm(ServerLevel l, ServerPlayer p, float dmg) {
		Fx.resetIFrames(p);
		Fx.damageRaw(l, p, dmg * dmgFactor());
	}

	/** Prozentschaden (Ultimate) - nicht mit dmgFactor skaliert, aber ueber Prozent der max. HP. */
	void harmPct(ServerLevel l, ServerPlayer p, float pct) { Fx.damagePct(l, p, pct); }

	void hit(Vec3 pos, int delay, float r, float dmg, boolean slow) { parts.add(new Parts.Hit(pos, delay, r, dmg, slow)); }

	void startRing(Vec3 c, double max, float dmg, boolean ice) { parts.add(new Parts.Ring(c, max, 0.55, dmg, ice, ice ? 5 : 0)); }

	void tickParts(ServerLevel l) {
		Iterator<Parts.Part> it = parts.iterator();
		while (it.hasNext()) if (it.next().tick(l, this)) it.remove();
	}

	/** Liegt ein festes Dach ueber dem Spieler (Deckung vor der Sonnenkrone)? */
	static boolean covered(ServerLevel l, ServerPlayer p) {
		int x = (int) Math.floor(p.getX()), z = (int) Math.floor(p.getZ()), y = (int) Math.floor(p.getY());
		for (int dy = 2; dy <= 16; dy++) if (!l.getBlockState(new BlockPos(x, y + dy, z)).isAir()) return true;
		return false;
	}

	static double distToSegment(Vec3 p, Vec3 a, Vec3 b) {
		Vec3 ab = b.subtract(a);
		double len2 = ab.lengthSqr();
		double u = len2 < 1e-6 ? 0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
		return p.distanceTo(a.add(ab.scale(u)));
	}
}
