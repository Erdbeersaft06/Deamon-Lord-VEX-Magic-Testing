package de.daemonenlord.duo;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.boss.FxEntity;

/** Duo-Zauber: Solara fuehrt, Lunara wird mitgesteuert (pr.ov / pr.setCastState). */
final class DuoLogic {
	private DuoLogic() {}

	static void run(GoddessEntity g, ServerLevel l, GoddessEntity pr, GoddessEntity.Atk a, int t, ServerPlayer target) {
		if (pr == null) { g.endAttack(); return; }
		switch (a) {
			case SONNENFINSTERNIS -> finsternis(g, l, pr, t, target);
			case ZWIELICHTLANZE -> lanze(g, l, pr, t, target);
			case TAG_NACHT_RAD -> rad(g, l, pr, t, target);
			case HIMMELSBUND -> bund(g, l, pr, t, target);
			case ZWILLINGSGESTIRN -> gestirn(g, l, pr, t, target);
			default -> { }
		}
	}

	static Vec3 at(Vec3 c, double ang, double r, double h) { return new Vec3(c.x + Math.cos(ang) * r, c.y + h, c.z + Math.sin(ang) * r); }

	/** Sonnenfinsternis: Lunara schiebt sich vor Solara; Korona-Ring um die Mitte, Kern ist sicher. */
	static void finsternis(GoddessEntity g, ServerLevel l, GoddessEntity pr, int t, ServerPlayer target) {
		if (t == 5 && target != null) {
			g.lock = g.ground(l, target.getX(), target.getY() + 1, target.getZ());
			g.ov = g.lock.add(-2.5, 1.5, 0);
			pr.ov = g.lock.add(2.5, 1.5, 0);
			Fx.title(l, g.lock, 80, "SONNENFINSTERNIS", "Der Kern ist sicher …", "gold");
		}
		if (t == 20) {
			Parts.Hit h = new Parts.Hit(g.lock, 60, 10f, GoddessEntity.DMG_HEAVY, false);
			h.inner = 2.8f;
			g.parts.add(h);
			FxEntity safe = GoddessEntity.cfx(l, Fx.K_WARN, g.lock.add(0, 0.1, 0), 64, 2.8f / SoloLogic.R_WARN, 1.0f);
			safe.setTint(7);
			Fx.sound(l, g.lock, "minecraft:block.beacon.deactivate", 5.0f, 0.5f);
		}
		if (t == 80) {
			g.hit(g.lock, 40, 8.5f, GoddessEntity.DMG_HEAVY, false);
			Fx.actionbar(l, g.lock, 80, "Raus aus der Mitte!", "gold");
		}
	}

	/** Zwielichtlanze: beide zielen von gegenueberliegenden Seiten auf denselben Spieler. */
	static void lanze(GoddessEntity g, ServerLevel l, GoddessEntity pr, int t, ServerPlayer target) {
		if (t >= 10 && t <= 90 && (t - 10) % 20 == 0 && target != null) {
			Vec3 tp = new Vec3(target.getX(), target.getY() + 1.0, target.getZ());
			Parts.Shot s1 = new Parts.Shot(g.hand().add(0, 1.0, 0), tp, 32, 0, GoddessEntity.DMG_MAIN);
			Parts.Shot s2 = new Parts.Shot(pr.hand().add(0, 1.0, 0), tp, 32, 5, GoddessEntity.DMG_MAIN);
			g.parts.add(s1);
			g.parts.add(s2);
			Fx.sound(l, tp, "minecraft:block.beacon.power_select", 4.0f, 1.2f);
		}
	}

	/** Tag-Nacht-Rad: rotierende Trennlinie, abwechselnd trifft es die Tag- bzw. Nachtseite. */
	static void rad(GoddessEntity g, ServerLevel l, GoddessEntity pr, int t, ServerPlayer target) {
		final double W = 0.0095;
		if (t == 5 && target != null) g.lock = g.ground(l, target.getX(), target.getY() + 1, target.getZ());
		if (t < 5) return;
		Vec3 c = g.lock;
		double th = W * t;
		g.ov = at(c, th, 16, 1.5);
		pr.ov = at(c, th + Math.PI, 16, 1.5);
		Vec3 dir = new Vec3(Math.cos(th), 0, Math.sin(th));
		g.aimFx = GoddessEntity.cbeam(l, g.aimFx, c.add(dir.scale(-22)).add(0, 0.5, 0), c.add(dir.scale(22)).add(0, 0.5, 0), 6, 0.3f);
		if (g.aimFx != null) g.aimFx.setTint(7);
		int[] pulses = {50, 80, 110, 140};
		for (int i = 0; i < pulses.length; i++) {
			int tp = pulses[i];
			int side = (i % 2 == 0) ? 1 : -1; // +1 Tagseite, -1 Nachtseite
			double thp = W * tp;
			double nx = -Math.sin(thp), nz = Math.cos(thp);
			if (t == tp - 20) {
				for (int j = -2; j <= 2; j++) {
					Vec3 pos = g.ground(l, c.x + Math.cos(thp) * j * 7 + nx * side * 8, c.y + 2, c.z + Math.sin(thp) * j * 7 + nz * side * 8);
					FxEntity f = GoddessEntity.cfx(l, Fx.K_WARN, pos.add(0, 0.1, 0), 24, 4.5f / SoloLogic.R_WARN, 1.0f);
					if (side < 0) f.setTint(5);
				}
				Fx.actionbar(l, c, 60, side > 0 ? "☀ Tagseite wird getroffen – wechselt die Seite!" : "☾ Nachtseite wird getroffen – wechselt die Seite!", side > 0 ? "gold" : "aqua");
			}
			if (t == tp) {
				Fx.sound(l, c, side > 0 ? "minecraft:entity.generic.explode" : "minecraft:block.amethyst_block.break", 5.0f, side > 0 ? 1.4f : 0.8f);
				Fx.flash(l, c.add(0, 2, 0), 40, 12);
				for (ServerPlayer p : Fx.players(l, c, 34)) {
					double s = (p.getX() - c.x) * nx + (p.getZ() - c.z) * nz;
					if (s * side > 0 && p.getY() < c.y + 6) g.harm(l, p, GoddessEntity.DMG_MAIN);
				}
			}
		}
	}

	/** Himmelsbund: ein Strahl zwischen den Goettinnen fegt wie ein Leuchtturm ueber die Arena. */
	static void bund(GoddessEntity g, ServerLevel l, GoddessEntity pr, int t, ServerPlayer target) {
		final double W = 0.0156;
		if (t == 5 && target != null) g.lock = g.ground(l, target.getX(), target.getY() + 1, target.getZ());
		if (t < 5) return;
		Vec3 c = g.lock;
		double th = t < 20 ? 0 : W * (t - 20);
		g.ov = at(c, th, 14, 1.0);
		pr.ov = at(c, th + Math.PI, 14, 1.0);
		if (t < 20) {
			if (t == 6) Fx.actionbar(l, c, 80, "Himmelsbund – springt über den Strahl!", "light_purple");
			return;
		}
		Vec3 a = g.position().add(0, 0.8, 0), b = pr.position().add(0, 0.8, 0);
		g.aimFx = GoddessEntity.cbeam(l, g.aimFx, a, b, 6, 0.55f);
		if (g.aimFx != null) g.aimFx.setTint(6);
		if (t % 40 == 0) Fx.sound(l, c, "minecraft:block.beacon.ambient", 4.0f, 1.5f);
		for (ServerPlayer p : Fx.players(l, c, 34)) {
			Vec3 pc = new Vec3(p.getX(), p.getY() + 0.9, p.getZ());
			if (GoddessEntity.distToSegment(pc, a, b) < 1.0) {
				Integer last = g.cd.get(p.getUUID());
				if (last == null || g.tickCount - last > 20) { g.cd.put(p.getUUID(), g.tickCount); g.harm(l, p, GoddessEntity.DMG_MAIN); }
			}
		}
	}

	/** Zwillingsgestirn (nur Finsternis): erst Sonnenkrone-Pruefung (Deckung), dann Mondfinsternis-Pruefung (Mondlicht). */
	static void gestirn(GoddessEntity g, ServerLevel l, GoddessEntity pr, int t, ServerPlayer target) {
		if (t == 0) Fx.title(l, g.position(), 90, "ZWILLINGSGESTIRN", "Erst Deckung – dann Mondlicht!", "gold");
		if (t == 5 && target != null) {
			g.lock = g.ground(l, target.getX(), target.getY() + 1, target.getZ());
			g.ov = g.lock.add(-3, 1.5, 0);
			pr.ov = g.lock.add(3, 1.5, 0);
		}
		Vec3 cs = g.position().add(0, 4.5, 0), cm = pr.position().add(0, 4.5, 0);
		if (t == 5) { g.coreFx = GoddessEntity.cfx(l, Fx.K_CORE, cs, 230, 0.4f, 0.4f); }
		if (g.coreFx != null && !g.coreFx.isRemoved()) {
			g.coreFx.setPos(cs.x, cs.y, cs.z);
			float s = 0.4f + 2.6f * Math.min(1f, t / 110f);
			g.coreFx.setScale(s, s);
		}
		if (t == 110) {
			Fx.flash(l, cs, 90, 40);
			Fx.sound(l, cs, "minecraft:entity.generic.explode", 8.0f, 0.5f);
			for (ServerPlayer p : Fx.players(l, g.position(), 90)) if (!GoddessEntity.covered(l, p)) g.harmPct(l, p, GoddessEntity.ULT_PCT);
			if (g.coreFx != null && !g.coreFx.isRemoved()) g.coreFx.discard();
			g.trackFx = GoddessEntity.cfx(l, Fx.K_CORE, cm, 120, 0.4f, 0.4f);
			g.trackFx.setTint(4);
		}
		if (t == 60 || t == 85 || t == 100) Fx.actionbar(l, c(g), 90, "Sonnenkrone in " + ((110 - t) / 32 + 1) + " … Deckung unter einem Dach!", "gold");
		if (t > 110 && g.trackFx != null && !g.trackFx.isRemoved()) {
			g.trackFx.setPos(cm.x, cm.y, cm.z);
			float s = 0.4f + 2.6f * Math.min(1f, (t - 110) / 100f);
			g.trackFx.setScale(s, s);
		}
		if (t == 120 && target != null) {
			int n = Math.max(2, Fx.players(l, g.position(), 80).size() + 1);
			for (int k = 0; k < n; k++) {
				double ang = k * 6.283 / n;
				Vec3 s = g.ground(l, g.lock.x + Math.cos(ang) * 10, g.lock.y + 1, g.lock.z + Math.sin(ang) * 10);
				g.spots.add(s);
				FxEntity f = GoddessEntity.cfx(l, Fx.K_WARN, s.add(0, 0.08, 0), 110, 4.0f / SoloLogic.R_WARN, 1.0f);
				f.setTint(7);
			}
			for (ServerPlayer p : Fx.players(l, g.position(), 80)) Fx.effect(l, p, "minecraft:darkness", 8, 0);
			Fx.actionbar(l, c(g), 80, "Jetzt in einen Mondlichtkreis!", "aqua");
		}
		if (t == 220) {
			Fx.flash(l, cm, 90, 40);
			Fx.sound(l, cm, "minecraft:entity.wither.break_block", 8.0f, 0.5f);
			for (ServerPlayer p : Fx.players(l, g.position(), 90)) if (!SoloLogic.inSpot(g, p, 4.0)) g.harmPct(l, p, GoddessEntity.ULT_PCT);
			if (g.trackFx != null && !g.trackFx.isRemoved()) g.trackFx.discard();
		}
	}

	private static Vec3 c(GoddessEntity g) { return g.position(); }
}
