package de.daemonenlord.duo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.boss.FxEntity;

/** Kleine Effekt-/Schadensobjekte der Goettinnen. Jedes tick() liefert true, wenn es fertig ist. */
final class Parts {
	private Parts() {}

	interface Part { boolean tick(ServerLevel l, GoddessEntity g); }

	/** Verzoegerter Flaecheneinschlag mit Warnring. */
	static final class Hit implements Part {
		final Vec3 pos; int delay; final int total; final float r, dmg; final boolean slow; boolean init = false; float inner = 0;
		Hit(Vec3 pos, int delay, float r, float dmg, boolean slow) { this.pos = pos; this.delay = delay; this.total = delay; this.r = r; this.dmg = dmg; this.slow = slow; }

		@Override public boolean tick(ServerLevel l, GoddessEntity g) {
			if (!init) {
				init = true;
				if (total > 1) g.tint(Fx.fx(l, Fx.K_WARN, pos.add(0, 0.06, 0), total + 3, r / 12.25f, 1.0f));
			}
			if (--delay > 0) return false;
			g.tint(Fx.fx(l, Fx.K_PILLAR, pos, 14, r / 2.7f * 0.8f, 1.0f));
			Fx.sound(l, pos, g.sol ? "minecraft:entity.generic.explode" : "minecraft:block.amethyst_block.break", 1.6f, g.sol ? 1.5f : 1.1f);
			for (ServerPlayer p : Fx.players(l, pos, r + 2)) {
				double dx = p.getX() - pos.x, dz = p.getZ() - pos.z;
				double dd = Math.sqrt(dx * dx + dz * dz);
				if (dd <= r && dd >= inner && Math.abs(p.getY() - pos.y) < 4.5) {
					g.harm(l, p, dmg);
					if (slow) Fx.effect(l, p, "minecraft:slowness", 3, 1);
				}
			}
			return true;
		}
	}

	/** Sich ausbreitende Welle (ueberspringen mit Sprung). */
	static final class Ring implements Part {
		final Vec3 c; double r = 1; final double max, speed; final float dmg; final boolean ice;
		final int tint; FxEntity fx = null; final Set<UUID> hit = new HashSet<>();
		Ring(Vec3 c, double max, double speed, float dmg, boolean ice, int tint) { this.c = c; this.max = max; this.speed = speed; this.dmg = dmg; this.ice = ice; this.tint = tint; }

		@Override public boolean tick(ServerLevel l, GoddessEntity g) {
			if (fx == null) {
				Fx.fx(l, Fx.K_WARN, c.add(0, 0.08, 0), 18, (float) (Math.min(max, 16) / 12.0), 1.0f);
				fx = Fx.fx(l, Fx.K_RING, c.add(0, 0.05, 0), (int) (max / speed) + 6, 1.0f, 1.2f);
				if (tint > 0) fx.setTint(tint);
			}
			r += speed;
			if (!fx.isRemoved()) fx.setScale((float) (r * 1.0667), 1.2f);
			for (ServerPlayer p : Fx.players(l, c, r + 3)) {
				if (hit.contains(p.getUUID())) continue;
				double dx = p.getX() - c.x, dz = p.getZ() - c.z;
				double d = Math.sqrt(dx * dx + dz * dz);
				if (Math.abs(d - r) < 1.7 && p.getY() < c.y + 1.15) {
					hit.add(p.getUUID());
					if (dmg > 0) g.harm(l, p, dmg);
					if (ice && dmg > 0) Fx.effect(l, p, "minecraft:slowness", 4, 2);
				}
			}
			return r >= max;
		}
	}

	/** Rotierende Lichtscheibe, prallt an der Kante ab, Sprung ueberwindet sie. */
	static final class Disc implements Part {
		double x, z, dx, dz; final double cx, cz, cy; int life; FxEntity ring, glow;
		final Map<UUID, Integer> cd = new HashMap<>();
		Disc(double cx, double cz, double cy, double ang, int life) { this.cx = cx; this.cz = cz; this.cy = cy; this.x = cx; this.z = cz; this.dx = Math.cos(ang); this.dz = Math.sin(ang); this.life = life; }

		@Override public boolean tick(ServerLevel l, GoddessEntity g) {
			x += dx * 0.8; z += dz * 0.8;
			double rx = x - cx, rz = z - cz, d = Math.sqrt(rx * rx + rz * rz);
			if (d > 24) {
				double nx = rx / d, nz = rz / d, dot = dx * nx + dz * nz;
				dx -= 2 * dot * nx; dz -= 2 * dot * nz;
				x = cx + nx * 23.8; z = cz + nz * 23.8;
			}
			double gy = Fx.groundY(l, x, cy + 3, z);
			Vec3 at = new Vec3(x, gy + 0.1, z);
			if (ring == null) {
				ring = Fx.fx(l, Fx.K_RING, at, life + 6, 2.8f, 1.0f);
				glow = Fx.fx(l, Fx.K_WARN, at, life + 6, 2.6f / 12.25f, 1.0f);
			}
			ring.setPos(at.x, at.y, at.z); glow.setPos(at.x, at.y + 0.05, at.z);
			for (ServerPlayer p : Fx.players(l, at, 5)) {
				double ex = p.getX() - x, ez = p.getZ() - z;
				if (Math.sqrt(ex * ex + ez * ez) < 2.8 && p.getY() < gy + 1.1) {
					Integer last = cd.get(p.getUUID());
					if (last == null || g.tickCount - last > 20) { cd.put(p.getUUID(), g.tickCount); g.harm(l, p, GoddessEntity.DMG_MAIN); }
				}
			}
			if (--life <= 0) { ring.discard(); glow.discard(); return true; }
			return false;
		}
	}

	/** Kleine Sonne, wandert langsam auf Spieler zu und verbrennt den Boden unter sich. */
	static final class Sun implements Part {
		double x, z; final double cy; int life; FxEntity core, warn; static final float R = 3.2f;
		Sun(double x, double z, double cy, int life) { this.x = x; this.z = z; this.cy = cy; this.life = life; }

		@Override public boolean tick(ServerLevel l, GoddessEntity g) {
			ServerPlayer near = null; double bd = Double.MAX_VALUE;
			for (ServerPlayer p : Fx.players(l, new Vec3(x, cy, z), 70)) {
				double d = (p.getX() - x) * (p.getX() - x) + (p.getZ() - z) * (p.getZ() - z);
				if (d < bd) { bd = d; near = p; }
			}
			if (near != null) {
				double d = Math.sqrt(bd);
				if (d > 0.5) { x += (near.getX() - x) / d * 0.13; z += (near.getZ() - z) / d * 0.13; }
			}
			double gy = Fx.groundY(l, x, cy + 3, z);
			if (core == null) {
				core = Fx.fx(l, Fx.K_CORE, new Vec3(x, gy + 3, z), life + 6, 0.8f, 0.8f);
				warn = Fx.fx(l, Fx.K_WARN, new Vec3(x, gy + 0.08, z), life + 6, R / 12.25f, 1.0f);
			}
			core.setPos(x, gy + 3, z); warn.setPos(x, gy + 0.08, z);
			if (life % 20 == 0) {
				for (ServerPlayer p : Fx.players(l, new Vec3(x, gy, z), R + 2)) {
					double ex = p.getX() - x, ez = p.getZ() - z;
					if (Math.sqrt(ex * ex + ez * ez) <= R && Math.abs(p.getY() - gy) < 4) g.harm(l, p, GoddessEntity.DMG_ZONE);
				}
			}
			if (--life <= 0) { core.discard(); warn.discard(); return true; }
			return false;
		}
	}

	/** Mondsichel: fliegt nach aussen und kehrt zur Goettin zurueck. */
	static final class Sickle implements Part {
		double x, z, dx, dz; final double cy; int age = 0; FxEntity fx; final Map<UUID, Integer> cd = new HashMap<>();
		Sickle(double x, double z, double cy, double dx, double dz) { this.x = x; this.z = z; this.cy = cy; this.dx = dx; this.dz = dz; }

		@Override public boolean tick(ServerLevel l, GoddessEntity g) {
			age++;
			if (age <= 24) { x += dx * 1.0; z += dz * 1.0; }
			else {
				double tx = g.getX() - x, tz = g.getZ() - z, d = Math.sqrt(tx * tx + tz * tz);
				if (d < 2.5 || age > 90) { if (fx != null) fx.discard(); return true; }
				x += tx / d * 1.1; z += tz / d * 1.1;
			}
			double gy = Fx.groundY(l, x, cy + 3, z);
			Vec3 at = new Vec3(x, gy + 1.4, z);
			if (fx == null) { fx = Fx.fx(l, Fx.K_BLADE, at, 120, 0.7f, 0.7f); fx.setTint(5); }
			fx.setPos(at.x, at.y, at.z);
			for (ServerPlayer p : Fx.players(l, at, 5)) {
				Vec3 pc = new Vec3(p.getX(), p.getY() + 1.0, p.getZ());
				if (pc.distanceTo(at) < 2.2) {
					Integer last = cd.get(p.getUUID());
					if (last == null || g.tickCount - last > 14) { cd.put(p.getUUID(), g.tickCount); g.harm(l, p, GoddessEntity.DMG_MAIN); }
				}
			}
			return false;
		}
	}

	/** Gezielter Strahl: erst duenne Warnlinie, dann dicker Treffer. */
	static final class Shot implements Part {
		final Vec3 from, to; int delay; final int warn; FxEntity aim; final int tint; final float dmg;
		Shot(Vec3 from, Vec3 to, int delay, int tint, float dmg) { this.from = from; this.to = to; this.delay = delay; this.warn = delay; this.tint = tint; this.dmg = dmg; }

		@Override public boolean tick(ServerLevel l, GoddessEntity g) {
			Vec3 end = from.add(to.subtract(from).normalize().scale(70));
			if (delay > 0) {
				aim = Fx.beam(l, aim, from, end, warn + 4, 0.14f);
				if (aim != null && tint > 0) aim.setTint(tint);
				delay--;
				return false;
			}
			if (aim != null) aim.discard();
			FxEntity b = Fx.beam(l, null, from, end, 6, 1.0f);
			if (b != null && tint > 0) b.setTint(tint);
			Fx.sound(l, from, "minecraft:entity.warden.sonic_boom", 3.0f, g.sol ? 1.4f : 1.0f);
			for (ServerPlayer p : Fx.players(l, from, 75)) {
				Vec3 pc = new Vec3(p.getX(), p.getY() + 1.0, p.getZ());
				if (GoddessEntity.distToSegment(pc, from, end) < 1.3) g.harm(l, p, dmg);
			}
			return true;
		}
	}
}
