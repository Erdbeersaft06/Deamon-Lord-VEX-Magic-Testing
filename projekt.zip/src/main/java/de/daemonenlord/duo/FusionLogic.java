package de.daemonenlord.duo;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.entity.ModEntities;

/**
 * Eklipsa: Sonne und Mond verschmolzen. Ein sichtbarer Koerper, dazu zwei unsichtbare Zauber-Helfer
 * (hell = Solara-Zauber, dunkel = Lunara-Zauber), die an den Koerper gebunden sind und gleichzeitig wirken.
 */
final class FusionLogic {
	private FusionLogic() {}

	/** Beide Goettinnen sind gefallen: sie verschmelzen zu Eklipsa. */
	static void spawnFusion(ServerLevel sl, GoddessEntity dying) {
		Vec3 pos = dying.position();
		GoddessEntity f = new GoddessEntity(ModEntities.FUSION, sl, true);
		f.makeFusion();
		f.setPos(pos.x, pos.y, pos.z);
		f.setMaxHp(dying.getMaxHealth() * 2.0);
		f.fusionGrace = 90;
		f.cooldown = 30;
		sl.addFreshEntity(f);
		Vec3 c = pos.add(0, 3, 0);
		Fx.title(sl, c, 120, "VERSCHMELZUNG", "Sonne und Mond werden eins …", "light_purple");
		Fx.flash(sl, c, 100, 50);
		Fx.sound(sl, c, "minecraft:entity.ender_dragon.growl", 8.0f, 0.7f);
		Fx.sound(sl, c, "minecraft:block.beacon.activate", 8.0f, 0.6f);
		Fx.sound(sl, c, "minecraft:block.amethyst_block.resonate", 8.0f, 0.5f);
		Fx.currentRed = false;
		Fx.fx(sl, Fx.K_PILLAR, pos, 70, 1.4f, 1.0f);
		GoddessEntity.fx(sl, Fx.K_SEAL, new Vec3(pos.x, Fx.groundY(sl, pos.x, pos.y + 2, pos.z) + 0.05, pos.z), 120, 3.5f, 1.0f).setTint(4);
		Fx.fx(sl, Fx.K_RING, new Vec3(pos.x, Fx.groundY(sl, pos.x, pos.y + 2, pos.z) + 0.05, pos.z), 40, 14f, 1.2f).setTint(5);
	}

	static GoddessEntity puppet(GoddessEntity f, ServerLevel l, boolean light) {
		GoddessEntity p = light ? f.lightP : f.darkP;
		if (p == null) {
			p = new GoddessEntity(light ? ModEntities.SOLARA : ModEntities.LUNARA, l, light);
			p.puppet = true;
			p.owner = f;
			p.setPos(f.getX(), f.getY(), f.getZ());
			p.cooldown = light ? 30 : 55;
			p.ultCd = light ? 500 : 900;
			if (light) f.lightP = p; else f.darkP = p;
		}
		return p;
	}

	/** Admin-Befehl: einen bestimmten Zauber ueber den passenden Helfer wirken lassen. */
	static void cast(GoddessEntity f, GoddessEntity.Atk a) {
		if (!(f.level() instanceof ServerLevel l)) return;
		GoddessEntity li = puppet(f, l, true), da = puppet(f, l, false);
		if (a.duo()) {
			if (li.attack != null) li.endAttack();
			if (da.attack != null) da.endAttack();
			li.startDuo(a, da);
		} else {
			GoddessEntity p = a.side == 0 ? li : da;
			p.start(a);
		}
	}

	static void run(GoddessEntity f, ServerLevel sl, ServerPlayer target, int steps) {
		GoddessEntity a = puppet(f, sl, true), b = puppet(f, sl, false);
		for (GoddessEntity p : new GoddessEntity[] {a, b}) {
			p.setPos(f.getX(), f.getY(), f.getZ());
			p.phase = f.phase;
			p.tickCount++;
			if (p.ultCd > 0) p.ultCd--;
		}
		f.frozen = a.frozen || b.frozen;
		if (f.fusionGrace > 0) { f.fusionGrace -= steps; f.setCastState(0); a.tickParts(sl); b.tickParts(sl); return; }

		for (int i = 0; i < steps; i++) {
			a.tickParts(sl);
			b.tickParts(sl);
			if (a.attack != null) {
				if (a.attack.duo()) DuoLogic.run(a, sl, b, a.attack, a.atkTick, target);
				else SoloLogic.run(a, sl, a.attack, a.atkTick, target);
				if (a.attack != null && ++a.atkTick >= a.attack.duration) a.endAttack();
			}
			if (b.attack != null) {
				SoloLogic.run(b, sl, b.attack, b.atkTick, target);
				if (b.attack != null && ++b.atkTick >= b.attack.duration) b.endAttack();
			}
		}
		// Duo-Finale beendet? Dann ist die dunkle Seite wieder frei
		if (b.inDuo && (a.attack == null || !a.attack.duo())) { b.inDuo = false; b.ov = null; b.setCastState(0); b.cooldown = Math.max(b.cooldown, 40); }

		// Zwillingsgestirn als Finale (ab Daemmerung, wenn beide Seiten frei sind)
		if (f.phase >= 1 && f.ultCd <= 0 && a.attack == null && b.attack == null && !b.inDuo) {
			f.ultCd = 1800;
			a.startDuo(GoddessEntity.Atk.ZWILLINGSGESTIRN, b);
		}
		if (a.attack == null && !b.inDuo && --a.cooldown <= 0) a.chooseAttack(null);
		if (b.attack == null && !b.inDuo && --b.cooldown <= 0) b.chooseAttack(null);

		int st = a.attack != null ? a.getCastState() : b.attack != null || b.inDuo ? b.getCastState() : 0;
		f.setCastState(st);
	}
}
