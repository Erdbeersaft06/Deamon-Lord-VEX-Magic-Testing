package de.daemonenlord.duo;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.boss.FxEntity;

/** Alle Einzelzauber von Solara und Lunara. */
final class SoloLogic {
	private SoloLogic() {}

	static final float R_WARN = 12.25f;

	/** Wird einmal beim Start eines Zaubers aufgerufen. */
	static void begin(GoddessEntity g, ServerLevel l, GoddessEntity.Atk a) {
		g.frozen = a == GoddessEntity.Atk.LANZE;
		Vec3 gp0 = g.ground(l, g.getX(), g.getY(), g.getZ());
		boolean ult = a.minPhase > 0;
		g.tint(GoddessEntity.fx(l, Fx.K_SEAL, gp0.add(0, 0.05, 0), ult ? 200 : 36, ult ? 3.0f : 1.5f, 1.0f));
		g.tint(GoddessEntity.fx(l, Fx.K_CORE, g.hand(), ult ? 60 : 26, ult ? 1.2f : 0.6f, ult ? 1.2f : 0.6f));
		if (ult) g.startRing(gp0, 22, 0, !g.sol);
		if (a == GoddessEntity.Atk.ZENIT) g.lift = 10;
		if (a == GoddessEntity.Atk.SONNENKRONE) Fx.title(l, g.position(), 90, "SONNENKRONE", "Sucht Deckung unter einem Dach!", "gold");
		if (a == GoddessEntity.Atk.MONDFINSTERNIS) Fx.title(l, g.position(), 90, "MONDFINSTERNIS", "Tretet in die Mondlichtkreise!", "aqua");
	}

	static void clearDecoys(ServerLevel l, GoddessEntity g) {
		for (UUID id : g.decoys) {
			Entity e = l.getEntity(id);
			if (e != null) e.discard();
		}
		g.decoys.clear();
	}

	static void run(GoddessEntity g, ServerLevel l, GoddessEntity.Atk a, int t, ServerPlayer target) {
		switch (a) {
			case SPEERREGEN -> speerregen(g, l, t, target);
			case LANZE -> lanze(g, l, t, target);
			case MORGENROETE -> {
				if (t == 28) g.startRing(g.ground(l, g.getX(), g.getY(), g.getZ()), 34, GoddessEntity.DMG_MAIN, false);
				if (t == 10) {
					g.startRing(g.ground(l, g.getX(), g.getY(), g.getZ()), 34, GoddessEntity.DMG_MAIN, false);
					Fx.sound(l, g.hand(), "minecraft:entity.generic.explode", 3.0f, 1.4f);
					GoddessEntity pr = g.partner(l);
					if (pr != null) pr.heal(pr.getMaxHealth() * 0.03f);
				}
			}
			case SONNENSCHEIBE -> sonnenscheibe(g, l, t, target);
			case FLAMMENFLUEGEL -> flammenfluegel(g, l, t, target);
			case STRAHLENKRANZ -> strahlenkranz(g, l, t, target);
			case LAEUTERNDES_FEUER -> feuer(g, l, t, target);
			case ZENIT -> markAndStrike(g, l, t, 60, 4.5f, GoddessEntity.DMG_HEAVY, 0, "Zenit – ein Spieler ist markiert!");
			case GLUTSCHWUR -> markAndStrike(g, l, t, 70, 7.0f, GoddessEntity.DMG_HEAVY, 1, "Glutschwur – haltet Abstand zum Markierten!");
			case SONNENKRONE -> sonnenkrone(g, l, t);
			case MONDSTURZ -> mondsturz(g, l, t, target);
			case GEZEITENZUG -> gezeitenzug(g, l, t);
			case FROSTMOND -> {
				if (t == 32) g.startRing(g.ground(l, g.getX(), g.getY(), g.getZ()), 34, GoddessEntity.DMG_ZONE, true);
				if (t == 10) { g.startRing(g.ground(l, g.getX(), g.getY(), g.getZ()), 34, GoddessEntity.DMG_ZONE, true); Fx.sound(l, g.hand(), "minecraft:block.glass.break", 3.0f, 0.6f); }
			}
			case SILBERSICHELN -> silbersicheln(g, l, t, target);
			case SCHATTENSCHLEIER -> schleier(g, l, t);
			case LUNASPIEGEL -> spiegel(g, l, t, target);
			case TRAUMFESSEL -> traumfessel(g, l, t, target);
			case NACHTFLUT -> nachtflut(g, l, t, target);
			case STERNENREIGEN -> sternenreigen(g, l, t, target);
			case MONDFINSTERNIS -> mondfinsternis(g, l, t, target);
			default -> { }
		}
	}

	// ------------------------------------------------------------------ Solara
	static void speerregen(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t >= 8 && t < 56 && t % 2 == 0) {
			Vec3 base;
			if (g.rnd.nextInt(100) < 55 && target != null) base = g.ground(l, target.getX(), target.getY() + 1, target.getZ());
			else base = g.ground(l, g.getX() + (g.rnd.nextDouble() - .5) * 34, g.getY(), g.getZ() + (g.rnd.nextDouble() - .5) * 34);
			Vec3 pos = g.ground(l, base.x + (g.rnd.nextDouble() - .5) * 6, base.y + 2, base.z + (g.rnd.nextDouble() - .5) * 6);
			g.hit(pos, 26, 3.0f, GoddessEntity.DMG_MAIN, false);
			if (t % 9 == 8) Fx.sound(l, pos, "minecraft:entity.firework_rocket.launch", 2.0f, 0.8f);
		}
	}

	static void lanze(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		Vec3 c = g.hand().add(0, 1.2, 0);
		if (t == 0) g.coreFx = GoddessEntity.fx(l, Fx.K_CORE, c, 50, 0.3f, 0.3f);
		if (g.coreFx != null && !g.coreFx.isRemoved()) {
			g.coreFx.setPos(c.x, c.y, c.z);
			float s = 0.3f + 0.7f * Math.min(1f, t / 36f);
			g.coreFx.setScale(s, s);
		}
		if (t < 26 && target != null) g.lock = new Vec3(target.getX(), target.getY() + 1.0, target.getZ());
		if (t >= 20 && t < 36) g.aimFx = GoddessEntity.beam(l, g.aimFx, c, c.add(g.lock.subtract(c).normalize().scale(60)), 3, 0.18f);
		if (t == 36) {
			Vec3 end = c.add(g.lock.subtract(c).normalize().scale(60));
			GoddessEntity.beam(l, null, c, end, 12, 2.6f);
			Fx.sound(l, c, "minecraft:entity.warden.sonic_boom", 5.0f, 1.3f);
			for (ServerPlayer p : Fx.players(l, c, 70)) {
				Vec3 pc = new Vec3(p.getX(), p.getY() + 1.0, p.getZ());
				if (GoddessEntity.distToSegment(pc, c, end) < 1.9) g.harm(l, p, GoddessEntity.DMG_MAIN);
			}
			g.aimFx = null;
		}
	}

	static void sonnenscheibe(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 10 && target != null) {
			double a0 = Math.atan2(target.getZ() - g.getZ(), target.getX() - g.getX());
			double cy = target.getY();
			g.parts.add(new Parts.Disc(g.getX(), g.getZ(), cy, a0, 80));
			g.parts.add(new Parts.Disc(g.getX(), g.getZ(), cy, a0 + 0.9, 80));
			g.parts.add(new Parts.Disc(g.getX(), g.getZ(), cy, a0 - 0.9, 80));
			g.parts.add(new Parts.Disc(g.getX(), g.getZ(), cy, a0 + 1.8, 80));
			Fx.sound(l, g.hand(), "minecraft:entity.blaze.shoot", 3.0f, 0.7f);
		}
	}

	static void flammenfluegel(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 8 && target != null) g.lock = new Vec3(Math.atan2(target.getZ() - g.getZ(), target.getX() - g.getX()), 0, 0);
		if (t >= 10 && t <= 46 && (t - 10) % 4 == 0) {
			int k = (t - 10) / 4;
			double dist = 5 + 3.0 * k;
			Vec3 gp = g.ground(l, g.getX(), g.getY(), g.getZ());
			for (int w = 0; w < 4; w++) {
				double ang = g.lock.x + (w == 0 ? -0.55 : w == 1 ? 0.55 : w == 2 ? -1.2 : 1.2);
				Vec3 pos = g.ground(l, gp.x + Math.cos(ang) * dist, gp.y + 3, gp.z + Math.sin(ang) * dist);
				g.hit(pos, 16, 2.8f, GoddessEntity.DMG_MAIN, false);
			}
			if (k == 0) Fx.sound(l, g.hand(), "minecraft:entity.ender_dragon.flap", 4.0f, 0.7f);
		}
	}

	static void strahlenkranz(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if ((t == 10 || t == 40 || t == 70) && target != null) {
			double off = t == 10 ? 0 : t == 40 ? Math.PI / 12 : Math.PI / 24;
			Vec3 from = new Vec3(g.getX(), target.getY() + 1.0, g.getZ());
			for (int k = 0; k < 12; k++) {
				double ang = off + k * Math.PI / 6;
				Vec3 to = from.add(Math.cos(ang) * 60, 0, Math.sin(ang) * 60);
				g.parts.add(new Parts.Shot(from, to, 24, 0, GoddessEntity.DMG_MAIN));
			}
			Fx.sound(l, from, "minecraft:block.beacon.power_select", 4.0f, 1.6f);
		}
	}

	static void feuer(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 10 && target != null) {
			for (int k = 0; k < 5; k++) {
				double ang = k * 1.257 + g.rnd.nextDouble();
				g.parts.add(new Parts.Sun(target.getX() + Math.cos(ang) * 10, target.getZ() + Math.sin(ang) * 10, target.getY(), 90));
			}
			Fx.sound(l, g.hand(), "minecraft:item.firecharge.use", 3.0f, 0.6f);
		}
	}

	/** Zenit (mode 0: Saeule) / Glutschwur (mode 1: Explosion): ein Spieler wird markiert und verfolgt, dann fixiert. */
	static void markAndStrike(GoddessEntity g, ServerLevel l, int t, int lockAt, float r, float dmg, int mode, String msg) {
		if (t == 8) {
			ServerPlayer p = g.randomPlayer(l);
			if (p == null) return;
			g.marked.add(p.getUUID());
			Fx.actionbar(l, p.position(), 80, msg, "gold");
			if (mode == 1) Fx.effect(l, p, "minecraft:glowing", 4, 0);
			g.trackFx = GoddessEntity.fx(l, mode == 0 ? Fx.K_WARN : Fx.K_SEAL, p.position().add(0, 0.1, 0), lockAt, mode == 0 ? r / R_WARN : r / 3f, 1.0f);
		}
		if (g.marked.isEmpty()) return;
		UUID id = g.marked.iterator().next();
		ServerPlayer p = g.playerById(l, id);
		if (t > 8 && t < lockAt && p != null && g.trackFx != null && !g.trackFx.isRemoved()) {
			Vec3 gp = g.ground(l, p.getX(), p.getY() + 1, p.getZ());
			g.trackFx.setPos(gp.x, gp.y + 0.1, gp.z);
			g.lock = gp;
		}
		if (t == lockAt) {
			if (g.trackFx != null && !g.trackFx.isRemoved()) g.trackFx.discard();
			g.trackFx = null;
			g.hit(g.lock, 26, r, dmg, false);
		}
	}

	static void sonnenkrone(GoddessEntity g, ServerLevel l, int t) {
		Vec3 c = g.position().add(0, 7.5, 0);
		if (t == 0) g.coreFx = GoddessEntity.fx(l, Fx.K_CORE, c, 190, 0.4f, 0.4f);
		if (g.coreFx != null && !g.coreFx.isRemoved()) {
			g.coreFx.setPos(c.x, c.y, c.z);
			float s = 0.4f + 3.2f * Math.min(1f, t / 170f);
			g.coreFx.setScale(s, s);
		}
		if (t == 60 || t == 100 || t == 130 || t == 150)
			Fx.actionbar(l, g.position(), 90, "Sonnenkrone in " + ((170 - t) / 32 + 1) + " … Deckung unter einem Dach!", "gold");
		if (t >= 20 && t < 170 && t % 30 == 0) Fx.sound(l, c, "minecraft:block.beacon.ambient", 4.0f, 0.5f + t / 170f);
		if (t == 170) {
			Fx.flash(l, c, 90, 40);
			Fx.sound(l, c, "minecraft:entity.generic.explode", 8.0f, 0.5f);
			for (ServerPlayer p : Fx.players(l, g.position(), 90)) if (!GoddessEntity.covered(l, p)) g.harmPct(l, p, GoddessEntity.ULT_PCT);
		}
	}

	// ------------------------------------------------------------------ Lunara
	static void mondsturz(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t >= 8 && t < 62 && target != null) {
			int i = t - 8;
			double ang = i * 2.399, rad = 2.0 + i * 0.16;
			Vec3 c = g.ground(l, target.getX() + Math.cos(ang) * rad, target.getY() + 1, target.getZ() + Math.sin(ang) * rad);
			g.hit(c, 28, 2.6f, GoddessEntity.DMG_MAIN, true);
			if (t % 8 == 0) Fx.sound(l, c, "minecraft:block.amethyst_cluster.break", 2.0f, 1.2f);
		}
	}

	static void gezeitenzug(GoddessEntity g, ServerLevel l, int t) {
		Vec3 gp = g.ground(l, g.getX(), g.getY(), g.getZ());
		if (t == 0) g.tint(GoddessEntity.fx(l, Fx.K_SEAL, gp.add(0, 0.05, 0), 86, 1.6f, 1.0f));
		if (t < 60) {
			for (ServerPlayer p : Fx.players(l, gp, 60)) {
				Vec3 to = new Vec3(gp.x - p.getX(), 0, gp.z - p.getZ());
				if (to.length() > 3.5) Fx.pull(p, to.normalize().scale(0.2 + 0.003 * t));
			}
		}
		if (t == 62) {
			Fx.sound(l, gp, "minecraft:entity.generic.explode", 5.0f, 0.7f);
			g.tint(GoddessEntity.fx(l, Fx.K_WARN, gp.add(0, 0.08, 0), 16, 8f / R_WARN, 1.0f));
			for (ServerPlayer p : Fx.players(l, gp, 9)) g.harm(l, p, GoddessEntity.DMG_ZONE);
			GoddessEntity pr = g.partner(l);
			if (pr != null) pr.heal(pr.getMaxHealth() * 0.03f);
		}
	}

	static void silbersicheln(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if ((t == 10 || t == 40) && target != null) {
			double a0 = Math.atan2(target.getZ() - g.getZ(), target.getX() - g.getX()) + (t == 40 ? 0.31 : 0);
			for (int k = 0; k < 10; k++) {
				double ang = a0 + k * Math.PI / 5;
				g.parts.add(new Parts.Sickle(g.getX(), g.getZ(), g.getY(), Math.cos(ang), Math.sin(ang)));
			}
			Fx.sound(l, g.hand(), "minecraft:item.trident.throw", 3.0f, 0.6f);
		}
	}

	static void schleier(GoddessEntity g, ServerLevel l, int t) {
		if (t == 8) {
			for (ServerPlayer p : Fx.players(l, g.position(), 80)) Fx.effect(l, p, "minecraft:darkness", 9, 0);
			Fx.actionbar(l, g.position(), 80, "Schattenschleier – bleibt in Bewegung!", "dark_aqua");
		}
		if (t >= 20 && t <= 92 && (t - 20) % 8 == 0)
			for (ServerPlayer p : Fx.players(l, g.position(), 80)) g.hit(g.ground(l, p.getX(), p.getY() + 1, p.getZ()), 26, 2.8f, GoddessEntity.DMG_MAIN, false);
	}

	static void spiegel(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 5 && target != null) {
			Vec3 c = new Vec3(target.getX(), target.getY(), target.getZ());
			double a0 = g.rnd.nextDouble() * 6.28;
			int real = g.rnd.nextInt(3);
			double gy = Fx.groundY(l, c.x, c.y + 2, c.z) + 3.2;
			Vec3[] slots = new Vec3[3];
			for (int k = 0; k < 3; k++) slots[k] = new Vec3(c.x + Math.cos(a0 + k * 2.094) * 11, gy, c.z + Math.sin(a0 + k * 2.094) * 11);
			g.ov = slots[real];
			g.setPos(slots[real].x, slots[real].y, slots[real].z);
			g.setDeltaMovement(Vec3.ZERO);
			g.lock = c;
			for (int k = 0; k < 3; k++) {
				if (k == real) continue;
				GoddessEntity d = new GoddessEntity(de.daemonenlord.entity.ModEntities.LUNARA, l, false);
				d.decoy = true;
				d.setPos(slots[k].x, slots[k].y, slots[k].z);
				l.addFreshEntity(d);
				g.decoys.add(d.getUUID());
			}
			Fx.flash(l, c.add(0, 3, 0), 60, 20);
			Fx.sound(l, c, "minecraft:block.amethyst_block.resonate", 5.0f, 1.8f);
			Fx.actionbar(l, c, 80, "Lunaspiegel – welche ist echt? Trefft sie mit Fernkampf!", "aqua");
		}
		if (t == 62 && target != null) {
			Vec3 tp = new Vec3(target.getX(), target.getY() + 1.0, target.getZ());
			g.parts.add(new Parts.Shot(g.hand(), tp, 28, 5, GoddessEntity.DMG_MAIN));
			for (UUID id : g.decoys) {
				Entity e = l.getEntity(id);
				if (e != null) g.parts.add(new Parts.Shot(e.position().add(0, 3.6, 0), tp, 28, 5, GoddessEntity.DMG_MAIN));
			}
		}
		if (t == 100) clearDecoys(l, g);
	}

	static boolean inSpot(GoddessEntity g, ServerPlayer p, double r) {
		for (Vec3 s : g.spots) {
			double dx = p.getX() - s.x, dz = p.getZ() - s.z;
			if (Math.sqrt(dx * dx + dz * dz) <= r) return true;
		}
		return false;
	}

	static void traumfessel(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 8 && target != null) {
			for (int k = 0; k < 3; k++) {
				double ang = k * 2.094 + g.rnd.nextDouble();
				Vec3 s = g.ground(l, target.getX() + Math.cos(ang) * 6.5, target.getY() + 1, target.getZ() + Math.sin(ang) * 6.5);
				g.spots.add(s);
				FxEntity f = GoddessEntity.fx(l, Fx.K_WARN, s.add(0, 0.08, 0), 110, 2.5f / R_WARN, 1.0f);
				f.setTint(7);
			}
			for (ServerPlayer p : Fx.players(l, g.position(), 80)) {
				g.marked.add(p.getUUID());
				Fx.effect(l, p, "minecraft:slowness", 8, 3);
			}
			Fx.actionbar(l, g.position(), 80, "Traumfessel – erreicht einen weißen Kreis, um die Fesseln zu lösen!", "aqua");
		}
		if (t > 8 && t <= 110) {
			for (UUID id : new ArrayList<>(g.marked)) {
				ServerPlayer p = g.playerById(l, id);
				if (p == null) { g.marked.remove(id); continue; }
				if (inSpot(g, p, 2.5)) {
					Fx.cmd(l, p.position(), "effect clear " + p.getStringUUID() + " minecraft:slowness");
					g.marked.remove(id);
				} else if (t >= 30 && t % 24 == 12) {
					g.hit(g.ground(l, p.getX(), p.getY() + 1, p.getZ()), 26, 2.6f, GoddessEntity.DMG_MAIN, false);
				}
			}
		}
	}

	static void nachtflut(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 8 && target != null) {
			for (int k = 0; k < 4; k++) {
				double ang = k * Math.PI / 2 + g.rnd.nextDouble() * 0.5;
				Vec3 s = g.ground(l, target.getX() + Math.cos(ang) * 8, target.getY() + 1, target.getZ() + Math.sin(ang) * 8);
				g.spots.add(s);
				FxEntity f = GoddessEntity.fx(l, Fx.K_WARN, s.add(0, 0.08, 0), 120, 3.5f / R_WARN, 1.0f);
				f.setTint(7);
			}
			Fx.actionbar(l, g.position(), 80, "Nachtflut – steht auf einer Lichtinsel!", "aqua");
		}
		if (t == 70 || t == 118) {
			Vec3 gp = g.ground(l, g.getX(), g.getY(), g.getZ());
			g.parts.add(new Parts.Ring(gp, 40, 0.9, 0, true, 5));
			Fx.sound(l, gp, "minecraft:entity.generic.splash", 6.0f, 0.5f);
			for (ServerPlayer p : Fx.players(l, g.position(), 70)) {
				if (!inSpot(g, p, 3.5)) { g.harm(l, p, GoddessEntity.DMG_HEAVY); Fx.effect(l, p, "minecraft:slowness", 3, 1); }
			}
		}
	}

	static void sternenreigen(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		if (t == 8 && target != null) g.lock = g.ground(l, target.getX(), target.getY() + 1, target.getZ());
		if (t >= 10 && t < 60) {
			int i = t - 10;
			int e = i / 10;
			double f = (i % 10) / 10.0;
			double R = 11, a0 = 1.57;
			double ax = g.lock.x + Math.cos(a0 + e * 2.513) * R, az = g.lock.z + Math.sin(a0 + e * 2.513) * R;
			double bx = g.lock.x + Math.cos(a0 + (e + 1) * 2.513) * R, bz = g.lock.z + Math.sin(a0 + (e + 1) * 2.513) * R;
			Vec3 pos = g.ground(l, ax + (bx - ax) * f, g.lock.y + 2, az + (bz - az) * f);
			g.hit(pos, 20, 2.4f, GoddessEntity.DMG_MAIN, false);
			if (i % 10 == 0) Fx.sound(l, pos, "minecraft:block.amethyst_block.chime", 3.0f, 1.0f + e * 0.15f);
		}
	}

	static void mondfinsternis(GoddessEntity g, ServerLevel l, int t, ServerPlayer target) {
		Vec3 c = g.position().add(0, 7.5, 0);
		if (t == 0) { g.coreFx = GoddessEntity.fx(l, Fx.K_CORE, c, 210, 0.4f, 0.4f); g.coreFx.setTint(4); }
		if (g.coreFx != null && !g.coreFx.isRemoved()) {
			g.coreFx.setPos(c.x, c.y, c.z);
			float s = 0.4f + 3.2f * Math.min(1f, t / 190f);
			g.coreFx.setScale(s, s);
		}
		if (t == 20 && target != null) {
			int n = Math.max(2, Fx.players(l, g.position(), 80).size() + 1);
			for (int k = 0; k < n; k++) {
				double ang = k * 6.283 / n;
				Vec3 s = g.ground(l, target.getX() + Math.cos(ang) * 10, target.getY() + 1, target.getZ() + Math.sin(ang) * 10);
				g.spots.add(s);
				FxEntity f = GoddessEntity.fx(l, Fx.K_WARN, s.add(0, 0.08, 0), 190, 4.0f / R_WARN, 1.0f);
				f.setTint(7);
			}
			for (ServerPlayer p : Fx.players(l, g.position(), 80)) Fx.effect(l, p, "minecraft:darkness", 10, 0);
		}
		if (t == 100 || t == 140 || t == 165) Fx.actionbar(l, g.position(), 90, "Mondfinsternis in " + ((190 - t) / 32 + 1) + " … in einen Mondlichtkreis!", "aqua");
		if (t == 190) {
			Fx.flash(l, c, 90, 40);
			Fx.sound(l, c, "minecraft:entity.wither.break_block", 8.0f, 0.5f);
			for (ServerPlayer p : Fx.players(l, g.position(), 90)) if (!inSpot(g, p, 4.0)) g.harmPct(l, p, GoddessEntity.ULT_PCT);
		}
	}
}
