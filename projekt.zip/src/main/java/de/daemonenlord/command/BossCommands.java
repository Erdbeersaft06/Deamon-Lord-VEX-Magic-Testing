package de.daemonenlord.command;

import java.util.ArrayList;
import java.util.List;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import de.daemonenlord.boss.Attack;
import de.daemonenlord.boss.DaemonenlordEntity;
import de.daemonenlord.boss.Fx;
import de.daemonenlord.entity.ModEntities;

/**
 * /daemonenlord spawn [pos] | kill | heal | phase <1-3> | attack <name> | list
 */
public final class BossCommands {
	private BossCommands() {}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			List<String> names = new ArrayList<>();
			for (Attack a : Attack.values()) names.add(a.id);

			dispatcher.register(Commands.literal("daemonenlord")
					.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER))
					.then(Commands.literal("spawn")
							.executes(ctx -> spawn(ctx, ctx.getSource().getPosition()))
							.then(Commands.argument("pos", Vec3Argument.vec3())
									.executes(ctx -> spawn(ctx, Vec3Argument.getVec3(ctx, "pos")))))
					.then(Commands.literal("kill").executes(BossCommands::kill))
					.then(Commands.literal("heal").executes(BossCommands::heal))
					.then(Commands.literal("list").executes(BossCommands::list))
					.then(Commands.literal("phase")
							.then(Commands.argument("phase", IntegerArgumentType.integer(1, 3))
									.executes(ctx -> phase(ctx, IntegerArgumentType.getInteger(ctx, "phase")))))
					.then(Commands.literal("attack")
							.then(Commands.argument("name", StringArgumentType.word())
									.suggests((ctx, builder) -> SharedSuggestionProvider.suggest(names, builder))
									.executes(ctx -> attack(ctx, StringArgumentType.getString(ctx, "name"))))));
		});
	}

	private static List<DaemonenlordEntity> bosses(CommandContext<CommandSourceStack> ctx) {
		ServerLevel level = ctx.getSource().getLevel();
		Vec3 p = ctx.getSource().getPosition();
		AABB box = new AABB(p.x - 400, p.y - 400, p.z - 400, p.x + 400, p.y + 400, p.z + 400);
		List<DaemonenlordEntity> out = new ArrayList<>();
		for (Entity e : level.getEntities((Entity) null, box, x -> x instanceof DaemonenlordEntity)) {
			out.add((DaemonenlordEntity) e);
		}
		return out;
	}

	private static int spawn(CommandContext<CommandSourceStack> ctx, Vec3 pos) {
		ServerLevel level = ctx.getSource().getLevel();
		DaemonenlordEntity boss = new DaemonenlordEntity(ModEntities.DAEMONENLORD, level);
		boss.setPos(pos.x, pos.y + 3, pos.z);
		level.addFreshEntity(boss);
		Fx.title(level, pos, 120, "DER DÄMONENLORD ERWACHT", "Das Jüngste Gericht naht …", "gold");
		Fx.flash(level, pos.add(0, 3, 0), 100, 40);
		Fx.sound(level, pos, "minecraft:entity.wither.spawn", 8.0f, 0.5f);
		Fx.sound(level, pos, "minecraft:entity.ender_dragon.growl", 8.0f, 0.6f);
		Fx.p(level, Fx.ROD, pos.x, pos.y + 4, pos.z, 300, 3, 4, 3, 0.5);
		Fx.p(level, Fx.BOOM, pos.x, pos.y + 3, pos.z, 3, 2, 1, 2, 0);
		ctx.getSource().sendSuccess(() -> Component.literal("§6Der Dämonenlord wurde beschworen."), true);
		return Command.SINGLE_SUCCESS;
	}

	private static int kill(CommandContext<CommandSourceStack> ctx) {
		List<DaemonenlordEntity> list = bosses(ctx);
		for (DaemonenlordEntity b : list) b.discard();
		Fx.cmd(ctx.getSource().getLevel(), ctx.getSource().getPosition(), "kill @e[tag=" + Fx.MINION_TAG + "]");
		ctx.getSource().sendSuccess(() -> Component.literal("§e" + list.size() + " Dämonenlord(s) entfernt."), true);
		return list.size();
	}

	private static int heal(CommandContext<CommandSourceStack> ctx) {
		List<DaemonenlordEntity> list = bosses(ctx);
		for (DaemonenlordEntity b : list) b.setHealth(b.getMaxHealth());
		ctx.getSource().sendSuccess(() -> Component.literal("§eDämonenlord geheilt."), true);
		return list.size();
	}

	private static int list(CommandContext<CommandSourceStack> ctx) {
		StringBuilder sb = new StringBuilder("§6Attacken: §f");
		for (Attack a : Attack.values()) sb.append(a.id).append(" (").append(a.title).append(")  ");
		ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
		return Command.SINGLE_SUCCESS;
	}

	private static int phase(CommandContext<CommandSourceStack> ctx, int phase) {
		List<DaemonenlordEntity> list = bosses(ctx);
		for (DaemonenlordEntity b : list) b.forcePhase(phase);
		ctx.getSource().sendSuccess(() -> Component.literal("§ePhase " + phase + " gesetzt."), true);
		return list.size();
	}

	private static int attack(CommandContext<CommandSourceStack> ctx, String name) {
		Attack a = Attack.byId(name);
		if (a == null) {
			ctx.getSource().sendFailure(Component.literal("Unbekannte Attacke. /daemonenlord list"));
			return 0;
		}
		List<DaemonenlordEntity> list = bosses(ctx);
		for (DaemonenlordEntity b : list) b.forceAttack(a);
		ctx.getSource().sendSuccess(() -> Component.literal("§eAttacke: " + a.title), true);
		return list.size();
	}
}
