package de.daemonenlord.command;

import java.util.ArrayList;
import java.util.List;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.duo.GoddessEntity;
import de.daemonenlord.entity.ModEntities;

/** /solunar spawn [pos] | kill | heal | list | attack <name> */
public final class DuoCommands {
	private DuoCommands() {}

	/** Lebenspunkte-Faktor nach Spielerzahl: 1 = 100 %, 2 = 170 %, 3 = 240 %, danach +70 % je Spieler. */
	static double hpFactor(int players) {
		return 1.0 + 0.7 * Math.max(0, players - 1);
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			List<String> names = new ArrayList<>();
			for (GoddessEntity.Atk a : GoddessEntity.Atk.values()) names.add(a.id);
			dispatcher.register(Commands.literal("solunar")
					.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER))
					.then(Commands.literal("spawn")
							.executes(ctx -> spawn(ctx, ctx.getSource().getPosition()))
							.then(Commands.argument("pos", Vec3Argument.vec3())
									.executes(ctx -> spawn(ctx, Vec3Argument.getVec3(ctx, "pos")))))
					.then(Commands.literal("fusion")
							.executes(ctx -> fusion(ctx, ctx.getSource().getPosition())))
					.then(Commands.literal("kill").executes(DuoCommands::kill))
					.then(Commands.literal("heal").executes(DuoCommands::heal))
					.then(Commands.literal("list").executes(DuoCommands::list))
					.then(Commands.literal("attack")
							.then(Commands.argument("name", StringArgumentType.word())
									.suggests((ctx, builder) -> SharedSuggestionProvider.suggest(names, builder))
									.executes(ctx -> attack(ctx, StringArgumentType.getString(ctx, "name"))))));
		});
	}

	private static List<GoddessEntity> gods(CommandContext<CommandSourceStack> ctx) {
		ServerLevel level = ctx.getSource().getLevel();
		Vec3 p = ctx.getSource().getPosition();
		AABB box = new AABB(p.x - 400, p.y - 400, p.z - 400, p.x + 400, p.y + 400, p.z + 400);
		List<GoddessEntity> out = new ArrayList<>();
		for (Entity e : level.getEntities((Entity) null, box, x -> x instanceof GoddessEntity ge && !ge.isDecoy())) out.add((GoddessEntity) e);
		return out;
	}

	private static int spawn(CommandContext<CommandSourceStack> ctx, Vec3 pos) {
		ServerLevel level = ctx.getSource().getLevel();
		int players = Math.max(1, Fx.players(level, pos, 80).size());
		double hp = GoddessEntity.BASE_HEALTH * hpFactor(players);
		GoddessEntity sol = new GoddessEntity(ModEntities.SOLARA, level, true);
		GoddessEntity lun = new GoddessEntity(ModEntities.LUNARA, level, false);
		sol.setPos(pos.x - 7, pos.y + 4, pos.z);
		lun.setPos(pos.x + 7, pos.y + 3, pos.z);
		sol.setMaxHp(hp);
		lun.setMaxHp(hp);
		sol.link(lun);
		lun.link(sol);
		level.addFreshEntity(sol);
		level.addFreshEntity(lun);
		Fx.title(level, pos, 120, "SOLARA & LUNARA", "Sonne und Mond erwachen …", "gold");
		Fx.flash(level, pos.add(0, 3, 0), 100, 40);
		Fx.sound(level, pos, "minecraft:entity.ender_dragon.growl", 8.0f, 1.2f);
		Fx.sound(level, pos, "minecraft:block.beacon.activate", 8.0f, 0.8f);
		ctx.getSource().sendSuccess(() -> Component.literal("§6Solara §7und §9Lunara §7wurden beschworen (" + players + " Spieler, " + (int) hp + " HP je Göttin)."), true);
		return Command.SINGLE_SUCCESS;
	}

	private static int fusion(CommandContext<CommandSourceStack> ctx, Vec3 pos) {
		ServerLevel level = ctx.getSource().getLevel();
		int players = Math.max(1, Fx.players(level, pos, 80).size());
		double hp = GoddessEntity.BASE_HEALTH * 2.0 * hpFactor(players);
		GoddessEntity f = new GoddessEntity(ModEntities.FUSION, level, true);
		f.makeFusion();
		f.setPos(pos.x, pos.y + 1.5, pos.z);
		f.setMaxHp(hp);
		level.addFreshEntity(f);
		Fx.title(level, pos, 120, "VERSCHMELZUNG", "Sonne und Mond werden eins …", "light_purple");
		Fx.flash(level, pos.add(0, 3, 0), 100, 40);
		Fx.sound(level, pos, "minecraft:entity.ender_dragon.growl", 8.0f, 0.7f);
		ctx.getSource().sendSuccess(() -> Component.literal("§dEklipsa §7wurde beschworen (" + players + " Spieler, " + (int) hp + " HP)."), true);
		return Command.SINGLE_SUCCESS;
	}

	private static int kill(CommandContext<CommandSourceStack> ctx) {
		List<GoddessEntity> list = gods(ctx);
		for (GoddessEntity g : list) g.discard();
		Fx.cmd(ctx.getSource().getLevel(), ctx.getSource().getPosition(), "kill @e[type=daemonenlord:fx]");
		ctx.getSource().sendSuccess(() -> Component.literal("§e" + list.size() + " Göttin(nen) entfernt."), true);
		return list.size();
	}

	private static int heal(CommandContext<CommandSourceStack> ctx) {
		List<GoddessEntity> list = gods(ctx);
		for (GoddessEntity g : list) g.setHealth(g.getMaxHealth());
		ctx.getSource().sendSuccess(() -> Component.literal("§eGöttinnen geheilt."), true);
		return list.size();
	}

	private static int list(CommandContext<CommandSourceStack> ctx) {
		StringBuilder sb = new StringBuilder("§6Zauber: §f");
		for (GoddessEntity.Atk a : GoddessEntity.Atk.values()) sb.append(a.id).append(" (").append(a.title).append(", ").append(a.side == 0 ? "Solara" : a.side == 1 ? "Lunara" : "Duo").append(")  ");
		ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
		return Command.SINGLE_SUCCESS;
	}

	private static int attack(CommandContext<CommandSourceStack> ctx, String name) {
		GoddessEntity.Atk a = GoddessEntity.Atk.byId(name);
		if (a == null) {
			ctx.getSource().sendFailure(Component.literal("Unbekannter Zauber. /solunar list"));
			return 0;
		}
		int n = 0;
		List<GoddessEntity> gl = gods(ctx);
		for (GoddessEntity g : gl) if (g.isFusion()) { g.fusionCast(a); n++; }
		gl.removeIf(GoddessEntity::isFusion);
		if (n > 0 && gl.isEmpty()) {
			ctx.getSource().sendSuccess(() -> Component.literal("§eZauber: " + a.title), true);
			return n;
		}
		if (a.duo()) {
			GoddessEntity so = null, lu = null;
			for (GoddessEntity g : gl) { if (g.sol) so = g; else lu = g; }
			if (so == null || lu == null) {
				ctx.getSource().sendFailure(Component.literal("Duo-Zauber brauchen beide Göttinnen."));
				return 0;
			}
			so.startDuo(a, lu);
			n = 2;
		} else {
			for (GoddessEntity g : gl) if ((a.side == 0) == g.sol) { g.start(a); n++; }
		}
		ctx.getSource().sendSuccess(() -> Component.literal("§eZauber: " + a.title), true);
		return n;
	}
}
