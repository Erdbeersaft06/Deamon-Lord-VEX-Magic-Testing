package de.daemonenlord.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import de.daemonenlord.gear.Gear;

/** /gear give <tank|glass|all|item-id>  |  /gear stats  |  /gear list */
public final class GearCommands {
	private GearCommands() {}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			List<String> names = new ArrayList<>(List.of("tank", "glass", "all"));
			for (Gear.Piece p : Gear.Piece.values()) names.add(p.id);
			dispatcher.register(Commands.literal("gear")
					.requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_GAMEMASTER))
					.then(Commands.literal("give")
							.then(Commands.argument("was", StringArgumentType.word())
									.suggests((ctx, builder) -> SharedSuggestionProvider.suggest(names, builder))
									.executes(ctx -> give(ctx, StringArgumentType.getString(ctx, "was")))))
					.then(Commands.literal("stats").executes(GearCommands::stats))
					.then(Commands.literal("list").executes(GearCommands::list)));
		});
	}

	private static int give(CommandContext<CommandSourceStack> ctx, String what) throws CommandSyntaxException {
		ServerPlayer p = ctx.getSource().getPlayerOrException();
		List<Gear.Piece> out = new ArrayList<>();
		for (Gear.Piece pc : Gear.Piece.values()) {
			boolean tank = pc == Gear.Piece.MIDAS_SWORD || pc.set == Gear.Set.TANK;
			boolean glass = pc == Gear.Piece.ARC_SWORD || pc.set == Gear.Set.GLASS;
			if (what.equals("all") || (what.equals("tank") && tank) || (what.equals("glass") && glass) || what.equals(pc.id)) out.add(pc);
		}
		if (out.isEmpty()) {
			ctx.getSource().sendFailure(Component.literal("Unbekannt. /gear give tank | glass | all | <item-id>  (/gear list)"));
			return 0;
		}
		for (Gear.Piece pc : out) {
			ctx.getSource().getServer().getCommands().performPrefixedCommand(ctx.getSource(), pc.giveCommand(p.getScoreboardName()));
		}
		return out.size();
	}

	private static int stats(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer p = ctx.getSource().getPlayerOrException();
		int[] t = Gear.totals(p);
		String s = String.format(Locale.ROOT,
				"§6Stats: §cStärke %d  §9Crit Chance %d%% (Cap 100)  Crit Schaden %d%%  §aDefense %d  §dLeben +%.1f Herzen  §7| Tank-Teile %d/4, Glas-Teile %d/4",
				t[0], t[1], t[2], t[3], t[4] / 2.0, Gear.count(p, Gear.Set.TANK), Gear.count(p, Gear.Set.GLASS));
		ctx.getSource().sendSuccess(() -> Component.literal(s), false);
		return Command.SINGLE_SUCCESS;
	}

	private static int list(CommandContext<CommandSourceStack> ctx) {
		StringBuilder sb = new StringBuilder("§6Gear: §f");
		for (Gear.Piece p : Gear.Piece.values()) sb.append(p.id).append(" (").append(p.name).append(")  ");
		ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
		return Command.SINGLE_SUCCESS;
	}
}
