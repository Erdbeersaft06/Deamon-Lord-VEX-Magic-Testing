package de.daemonenlord.command;

import java.util.List;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import de.daemonenlord.party.PartyManager;

/** /party create | invite <spieler> | accept | decline | leave | kick <spieler> | list | warp | boss <daemonenlord|solunar> (fuer alle Spieler). */
public final class PartyCommands {
	private PartyCommands() {}

	private interface Act { String run(ServerPlayer p) throws CommandSyntaxException; }

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			List<String> bosses = List.of("daemonenlord", "solunar");
			dispatcher.register(Commands.literal("party")
					.then(Commands.literal("create").executes(ctx -> act(ctx, p -> PartyManager.create(p), "§aParty erstellt. Lade Mitspieler mit /party invite <Spieler> ein.")))
					.then(Commands.literal("invite").then(Commands.argument("spieler", EntityArgument.player())
							.executes(ctx -> act(ctx, p -> PartyManager.invite(p, EntityArgument.getPlayer(ctx, "spieler")), "§aEinladung gesendet."))))
					.then(Commands.literal("accept").executes(ctx -> act(ctx, PartyManager::accept, "§aDu bist der Party beigetreten.")))
					.then(Commands.literal("decline").executes(ctx -> act(ctx, PartyManager::decline, "§7Einladung abgelehnt.")))
					.then(Commands.literal("leave").executes(ctx -> act(ctx, PartyManager::leave, null)))
					.then(Commands.literal("kick").then(Commands.argument("spieler", EntityArgument.player())
							.executes(ctx -> act(ctx, p -> PartyManager.kick(p, EntityArgument.getPlayer(ctx, "spieler")), null))))
					.then(Commands.literal("warp").executes(ctx -> act(ctx, PartyManager::warp, null)))
					.then(Commands.literal("boss").then(Commands.argument("boss", StringArgumentType.word())
							.suggests((ctx, builder) -> SharedSuggestionProvider.suggest(bosses, builder))
							.executes(ctx -> act(ctx, p -> PartyManager.boss(p, StringArgumentType.getString(ctx, "boss")), null))))
					.then(Commands.literal("list").executes(PartyCommands::list)));
		});
	}

	private static int act(CommandContext<CommandSourceStack> ctx, Act a, String ok) throws CommandSyntaxException {
		ServerPlayer p = ctx.getSource().getPlayerOrException();
		String err = a.run(p);
		if (err != null) {
			ctx.getSource().sendFailure(Component.literal(err));
			return 0;
		}
		if (ok != null) ctx.getSource().sendSuccess(() -> Component.literal(ok), false);
		return Command.SINGLE_SUCCESS;
	}

	private static int list(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
		ServerPlayer p = ctx.getSource().getPlayerOrException();
		PartyManager.Party party = PartyManager.of(p.getUUID());
		if (party == null) {
			ctx.getSource().sendFailure(Component.literal("Du bist in keiner Party. (/party create)"));
			return 0;
		}
		String text = String.join("\n", PartyManager.describe(ctx.getSource().getServer(), party));
		ctx.getSource().sendSuccess(() -> Component.literal(text), false);
		return Command.SINGLE_SUCCESS;
	}
}
