package de.daemonenlord.client;

import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import net.minecraft.util.Mth;

import com.geckolib.model.DefaultedGeoModel;
import com.geckolib.renderer.GeoArmorRenderer;
import com.geckolib.renderer.base.BoneSnapshots;
import com.geckolib.renderer.base.RenderPassInfo;

import de.daemonenlord.DaemonenlordMod;
import de.daemonenlord.gear.Gear;
import de.daemonenlord.gear.GearArmorItem;

/**
 * Zeichnet die 3D-Ruestung eines Sets (Modell: geckolib/models/armor/&lt;set&gt;.geo.json, Textur: textures/armor/&lt;set&gt;.png).
 * Standard-Bones: armorHead, armorBody, armorLeftArm, armorRightArm, armorLeftLeg, armorRightLeg, armorLeftBoot, armorRightBoot.
 * Zusatz-Bones (Umhang, Fluegel, Heiligenschein) werden hier per Code bewegt.
 */
public class GearArmorRenderer extends GeoArmorRenderer<GearArmorItem, HumanoidRenderState> {
	public GearArmorRenderer(Gear.Set set) {
		super(new DefaultedGeoModel<GearArmorItem>(DaemonenlordMod.id(set.asset)) {
			@Override
			protected String subtype() {
				return "armor";
			}
		});
	}

	@Override
	public void adjustModelBonesForRender(RenderPassInfo<HumanoidRenderState> renderPassInfo, BoneSnapshots snapshots) {
		super.adjustModelBonesForRender(renderPassInfo, snapshots);
		final HumanoidRenderState rs = renderPassInfo.renderState();
		final float t = rs.ageInTicks;
		final float sp = Math.min(1.0f, rs.walkAnimationSpeed);
		final float sneak = rs.isCrouching ? 0.45f : 0.0f;
		// GeckoLib-Rotation = Vanilla-Rotation mit negierten X/Y-Achsen -> Vorwaerts-/Rueckwaerts-Winkel werden abgezogen
		for (String pre : new String[] {"t_", "g_"}) {
			final float cape1 = sp * 0.65f + Mth.sin(t * 0.08f) * 0.03f + sneak;
			final float cape2 = sp * 0.45f + Mth.sin(t * 0.08f + 0.8f) * 0.04f;
			snapshots.ifPresent(pre + "cape", s -> s.setRotX(s.getRotX() - cape1));
			snapshots.ifPresent(pre + "cape2", s -> s.setRotX(s.getRotX() - cape2));
		}
		final float flap = Mth.sin(t * 0.12f) * 0.10f;
		snapshots.ifPresent("g_wing_l", s -> s.setRotZ(s.getRotZ() + flap).setRotY(s.getRotY() - flap * 0.5f));
		snapshots.ifPresent("g_wing_r", s -> s.setRotZ(s.getRotZ() - flap).setRotY(s.getRotY() + flap * 0.5f));
		snapshots.ifPresent("g_halo", s -> s.setRotY(s.getRotY() - t * 0.04f).setTranslateY(s.getTranslateY() + Mth.sin(t * 0.07f) * 0.6f));
	}
}
