package de.daemonenlord.gear;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import net.minecraft.core.component.DataComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * Die Custom-Ausruestung: Stats-Tabelle, Erkennung ueber die item_model-ID und /give-Komponenten.
 * Stats: Staerke (1 = +1 % Schaden), Crit Chance (Cap 100), Crit Schaden (1 = +1 % Crit-Schaden),
 * Defense (1 = -1 % erlittener Schaden), Leben (Max-HP als Attribut-Modifier, 20 Herzen = 40 HP).
 */
public final class Gear {
	private Gear() {}

	public enum Set {
		TANK("Ehrwürdiger Kriegspanzer", "gold", "tank", new int[] {2, 0, 0, 100}),
		GLASS("Himmlischer Mantel", "aqua", "glass", new int[] {10, 10, 15, 0});
		public final String title, color, asset;
		/** Set-Bonus-Stats (4 Teile): {Staerke, Crit Chance, Crit Schaden, Defense}. */
		public final int[] bonus;
		Set(String title, String color, String asset, int[] bonus) { this.title = title; this.color = color; this.asset = asset; this.bonus = bonus; }

		/** Zeile mit den Bonus-Stats. */
		public String bonusText() {
			StringBuilder sb = new StringBuilder();
			String[] n = {"Stärke", "Crit Chance", "Crit Schaden", "Defense"};
			for (int i = 0; i < 4; i++) if (bonus[i] > 0) sb.append(sb.length() > 0 ? ", " : "").append('+').append(bonus[i]).append(i == 1 || i == 2 ? "% " : " ").append(n[i]);
			return sb.toString();
		}
	}

	public enum Piece {
		TANK_HELMET("tank_helmet", "Kriegshaube der Ehrwürdigen", "netherite_helmet", EquipmentSlot.HEAD, Set.TANK, 1, 2, 3, 170, 5),
		TANK_CHEST("tank_chestplate", "Kriegspanzer der Ehrwürdigen", "netherite_chestplate", EquipmentSlot.CHEST, Set.TANK, 2, 3, 4, 270, 5),
		TANK_LEGS("tank_leggings", "Beinplatten der Ehrwürdigen", "netherite_leggings", EquipmentSlot.LEGS, Set.TANK, 1, 2, 3, 220, 5),
		TANK_BOOTS("tank_boots", "Schreitplatten der Ehrwürdigen", "netherite_boots", EquipmentSlot.FEET, Set.TANK, 1, 1, 2, 140, 5),
		MIDAS_SWORD("midas_sword", "Midas' Richtspruch", "netherite_sword", EquipmentSlot.MAINHAND, null, 0, 10, 20, 0, 0),
		GLASS_HELMET("glass_helmet", "Gnadenreif des Himmels", "netherite_helmet", EquipmentSlot.HEAD, Set.GLASS, 4, 6, 12, 25, 2),
		GLASS_CHEST("glass_chestplate", "Himmlischer Mantel", "netherite_chestplate", EquipmentSlot.CHEST, Set.GLASS, 5, 8, 15, 40, 2),
		GLASS_LEGS("glass_leggings", "Flügelgewand des Himmels", "netherite_leggings", EquipmentSlot.LEGS, Set.GLASS, 4, 6, 10, 35, 2),
		GLASS_BOOTS("glass_boots", "Wolkenschreiter", "netherite_boots", EquipmentSlot.FEET, Set.GLASS, 3, 4, 8, 20, 2),
		ARC_SWORD("arc_sword", "Bogenklinge des Zenits", "netherite_sword", EquipmentSlot.MAINHAND, null, 10, 15, 30, 0, 0);

		public final String id, name, base;
		public final EquipmentSlot slot;
		public final Set set;
		public final int str, crit, critDmg, def, hp;   // hp = Lebenspunkte (2 = 1 Herz)

		Piece(String id, String name, String base, EquipmentSlot slot, Set set, int str, int crit, int critDmg, int def, int hp) {
			this.id = id; this.name = name; this.base = base; this.slot = slot; this.set = set;
			this.str = str; this.crit = crit; this.critDmg = critDmg; this.def = def; this.hp = hp;
		}

		public boolean isWeapon() { return slot == EquipmentSlot.MAINHAND; }

		/** Waffenschaden (Basis der Schadensformel). */
		public float weapon() { return this == MIDAS_SWORD ? 1.0f : this == ARC_SWORD ? 5.0f : 0.0f; }

		/** 0 Helm, 1 Brust, 2 Hose, 3 Stiefel. */
		public int index() {
			return switch (slot) { case HEAD -> 0; case CHEST -> 1; case LEGS -> 2; default -> 3; };
		}

		private static String line(String text, String color) {
			return "{text:\"" + text + "\",color:\"" + color + "\",italic:false}";
		}

		private static String slotName(EquipmentSlot s) {
			return switch (s) { case HEAD -> "head"; case CHEST -> "chest"; case LEGS -> "legs"; default -> "feet"; };
		}

		/** Lore-Zeilen (SNBT-Textkomponenten). */
		public List<String> lore() {
			List<String> l = new ArrayList<>();
			if (isWeapon()) l.add(line("Waffenschaden: " + (int) weapon(), "red"));
			if (str > 0) l.add(line("Stärke: +" + str, "red"));
			if (crit > 0) l.add(line("Crit Chance: +" + crit + "%", "blue"));
			if (critDmg > 0) l.add(line("Crit Schaden: +" + critDmg + "%", "blue"));
			if (def > 0) l.add(line("Defense: +" + def, "green"));
			if (hp > 0) l.add(line("Leben: +" + String.format(Locale.ROOT, "%.1f", hp / 2.0) + " Herzen", "light_purple"));
			l.add(line("", "gray"));
			if (set == Set.TANK) {
				l.add(line("Set: " + set.title + " (4 Teile)", "gold"));
				l.add(line("Set-Bonus: " + set.bonusText(), "green"));
				l.add(line("Eidschwur: Unter 40% Leben +250 Defense und", "gray"));
				l.add(line("Regeneration für 10s. Abklingzeit 30s.", "gray"));
			} else if (set == Set.GLASS) {
				l.add(line("Set: " + set.title + " (4 Teile)", "aqua"));
				l.add(line("Set-Bonus: " + set.bonusText(), "green"));
				l.add(line("Sternensturm: Crits springen als 50%-Blitz auf", "gray"));
				l.add(line("bis zu 4 Gegner in 5 Blöcken. Kills geben 5s +20 Stärke.", "gray"));
			} else if (this == MIDAS_SWORD) {
				l.add(line("Fähigkeit: Goldener Urteilsspruch (Rechtsklick)", "gold"));
				l.add(line("Schockwelle (Radius 6): verletzt und verlangsamt Gegner,", "gray"));
				l.add(line("heilt dich um 10% deines Lebens. Abklingzeit 8s.", "gray"));
			} else {
				l.add(line("Fähigkeit: Bogenschnitt (Rechtsklick)", "aqua"));
				l.add(line("Dash 8 Blöcke nach vorn, ein Sichelschnitt trifft", "gray"));
				l.add(line("alles auf dem Weg. Abklingzeit 6s.", "gray"));
			}
			l.add(line("", "gray"));
			for (String f : flavor()) l.add("{text:\"" + f + "\",color:\"dark_purple\",italic:true}");
			return l;
		}

		/** Geschichte des Items (steht unten in der Beschreibung). */
		public String[] flavor() {
			return switch (this) {
				case TANK_HELMET -> new String[] {"Geschmiedet am letzten Tag der Belagerung,", "ihre Hörner trotzten tausend Schwüren."};
				case TANK_CHEST -> new String[] {"Kein Pfeil fand je den Weg durch dieses Gold.", "Es heißt, der Panzer erinnert sich an jeden Schlag."};
				case TANK_LEGS -> new String[] {"Wer standhaft bleibt, braucht keine Eile.", "Diese Platten kennen nur einen Schritt: vorwärts."};
				case TANK_BOOTS -> new String[] {"Der Boden bebt unter ihrem Gang,", "und er weicht keinen Fußbreit."};
				case MIDAS_SWORD -> new String[] {"Midas sprach ein Urteil, und alles,", "was er richtete, erstarrte zu Gold."};
				case GLASS_HELMET -> new String[] {"Ein Reif aus Himmelslicht, gewebt aus", "dem ersten Morgen der Welt."};
				case GLASS_CHEST -> new String[] {"Wer ihn trägt, wiegt weniger als eine Feder", "und schlägt härter als ein Sturm."};
				case GLASS_LEGS -> new String[] {"Der Saum berührt den Boden nie,", "nur den Wind."};
				case GLASS_BOOTS -> new String[] {"Schritte auf Wolken, doch der Himmel", "bebt, wenn sie landen."};
				default -> new String[] {"Geschnitten aus einem Stück Zenit.", "Die Klinge verfehlt nie, nur das Ziel verblasst."};
			};
		}

		/** Vollstaendiger /give-Befehl fuer dieses Item. */
		public String giveCommand(String target) {
			String color = set != null ? set.color : (this == MIDAS_SWORD ? "gold" : "aqua");
			String item = isWeapon() ? "minecraft:" + base : "daemonenlord:" + id;   // Ruestung = eigenes Item (GeckoLib), Schwert = Netherite-Basis
			StringBuilder sb = new StringBuilder("give ").append(target).append(' ').append(item).append('[');
			sb.append("item_model=\"daemonenlord:").append(id).append('"');
			sb.append(",custom_name=").append(line(name, color));
			sb.append(",lore=[").append(String.join(",", lore())).append(']');
			sb.append(",unbreakable={}");
			sb.append(",enchantment_glint_override=true");
			if (!isWeapon()) {
				sb.append(",equippable={slot:\"").append(slotName(slot)).append("\",asset_id:\"daemonenlord:" + (set != null ? set.asset : "tank") + "\"}");
				sb.append(",attribute_modifiers=[");
				if (hp > 0) {
					sb.append("{type:\"minecraft:max_health\",id:\"daemonenlord:").append(id).append("_hp\",amount:").append(hp)
							.append(".0d,operation:\"add_value\",slot:\"").append(slotName(slot)).append("\"}");
				}
				sb.append(']');
			}
			sb.append(']');
			return sb.toString();
		}
	}

	private static final Map<String, Piece> BY_ID = new HashMap<>();
	static { for (Piece p : Piece.values()) BY_ID.put(p.id, p); }

	public static Piece byId(String id) { return BY_ID.get(id); }

	/** Erkennt ein Custom-Item ueber seine item_model-ID (daemonenlord:<id>). */
	public static Piece of(ItemStack stack) {
		if (stack == null || stack.isEmpty()) return null;
		Identifier id = stack.get(DataComponents.ITEM_MODEL);
		if (id == null || !"daemonenlord".equals(id.getNamespace())) return null;
		return BY_ID.get(id.getPath());
	}

	/** Stueck, das im passenden Slot getragen wird (Ruestung im Ruestungsslot, Schwert in der Haupthand). */
	public static Piece worn(LivingEntity e, EquipmentSlot slot) {
		Piece p = of(e.getItemBySlot(slot));
		return p != null && p.slot == slot ? p : null;
	}

	private static final EquipmentSlot[] SLOTS = {EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	/** {Staerke, Crit Chance, Crit Schaden, Defense, Leben(HP)} */
	public static int[] totals(LivingEntity e) {
		int[] t = new int[5];
		for (EquipmentSlot s : SLOTS) {
			Piece p = worn(e, s);
			if (p == null) continue;
			t[0] += p.str; t[1] += p.crit; t[2] += p.critDmg; t[3] += p.def; t[4] += p.hp;
		}
		for (Set set : Set.values()) {
			if (count(e, set) < 4) continue;
			for (int i = 0; i < 4; i++) t[i] += set.bonus[i];
		}
		return t;
	}

	/** Traegt/haelt die Entity mindestens ein Custom-Item? (Nur dann gilt die Staerke-Formel, sonst Vanilla-Schaden.) */
	public static boolean wearing(LivingEntity e) {
		for (EquipmentSlot s : SLOTS) if (worn(e, s) != null) return true;
		return false;
	}

	public static int count(LivingEntity e, Set set) {
		int n = 0;
		for (EquipmentSlot s : SLOTS) {
			Piece p = worn(e, s);
			if (p != null && p.set == set) n++;
		}
		return n;
	}

	/** Bit (set*4 + index) je getragenem Ruestungsteil – fuer den 3D-Renderer. */
	public static int mask(LivingEntity e) {
		int m = 0;
		for (EquipmentSlot s : SLOTS) {
			if (s == EquipmentSlot.MAINHAND) continue;
			Piece p = worn(e, s);
			if (p != null && p.set != null) m |= 1 << (p.set.ordinal() * 4 + p.index());
		}
		return m;
	}
}
