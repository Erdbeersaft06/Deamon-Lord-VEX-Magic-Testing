package de.daemonenlord.gear;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

import de.daemonenlord.DaemonenlordMod;

/** Registriert die 8 Ruestungsteile als eigene Items (daemonenlord:tank_helmet ...). Schwerter bleiben Netherite-Schwerter mit Komponenten. */
public final class ModItems {
	private ModItems() {}

	public static void initialize() {
		for (Gear.Piece p : Gear.Piece.values()) {
			if (p.isWeapon()) continue;
			ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, DaemonenlordMod.id(p.id));
			Registry.register(BuiltInRegistries.ITEM, key, new GearArmorItem(new Item.Properties().setId(key).stacksTo(1), p.set));
		}
	}
}
