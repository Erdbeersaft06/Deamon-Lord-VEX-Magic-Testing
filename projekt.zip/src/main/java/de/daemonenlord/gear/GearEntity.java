package de.daemonenlord.gear;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.level.Level;

/**
 * Traegt die 3D-Ruestung eines Spielers: Der Client zeichnet diese Entity an der Position/Drehung des Besitzers
 * (siehe GearRenderer). Der Server haelt sie nur in der Naehe des Spielers, damit sie bei den Clients getrackt wird.
 */
public class GearEntity extends Mob {
	private static final EntityDataAccessor<Integer> OWNER = SynchedEntityData.defineId(GearEntity.class, EntityDataSerializers.INT);

	public GearEntity(EntityType<? extends Mob> type, Level level) {
		super(type, level);
		this.setNoAi(true);
		this.setNoGravity(true);
		this.setInvulnerable(true);
		this.setSilent(true);
		this.setPersistenceRequired();
		try {
			java.lang.reflect.Field f = net.minecraft.world.entity.Entity.class.getField("noCulling");
			f.setBoolean(this, true);
		} catch (Throwable ignored) { }
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes();
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(OWNER, -1);
	}

	public void setOwnerId(int id) {
		if (this.entityData.get(OWNER) != id) this.entityData.set(OWNER, id);
	}

	public int getOwnerId() { return this.entityData.get(OWNER); }

	// nie anstossen, nie anklickbar
	public void push(net.minecraft.world.entity.Entity e) { }
	public void push(double x, double y, double z) { }
	protected void pushEntities() { }
	protected void doPush(net.minecraft.world.entity.Entity e) { }

	@Override
	public boolean isPickable() { return false; }

	@Override
	public boolean isPushable() { return false; }
}
