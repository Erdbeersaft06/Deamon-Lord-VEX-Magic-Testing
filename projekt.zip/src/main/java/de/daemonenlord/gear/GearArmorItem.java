package de.daemonenlord.gear;

import java.util.function.Consumer;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import com.geckolib.animatable.GeoItem;
import com.geckolib.animatable.client.GeoRenderProvider;
import com.geckolib.animatable.instance.AnimatableInstanceCache;
import com.geckolib.animatable.manager.AnimatableManager;
import com.geckolib.renderer.GeoArmorRenderer;
import com.geckolib.util.GeckoLibUtil;

import de.daemonenlord.client.GearArmorRenderer;

/**
 * Ein Teil der Custom-Ruestung. Das Item selbst ist nur ein Traeger (Stats/Lore kommen per /give-Komponenten);
 * GeckoLib zeichnet beim Tragen das 3D-Modell (assets/daemonenlord/geckolib/models/armor/&lt;set&gt;.geo.json).
 */
public class GearArmorItem extends Item implements GeoItem {
	private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
	public final Gear.Set set;

	public GearArmorItem(Item.Properties properties, Gear.Set set) {
		super(properties);
		this.set = set;
	}

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
		// keine Keyframe-Animationen noetig: Umhang, Fluegel und Heiligenschein werden im Renderer per Code bewegt
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return this.cache;
	}

	@Override
	public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
		final Gear.Set s = this.set;
		consumer.accept(new GeoRenderProvider() {
			private GeoArmorRenderer<?, ?> renderer;

			@Override
			public GeoArmorRenderer<?, ?> getGeoArmorRenderer(ItemStack itemStack, EquipmentSlot equipmentSlot) {
				if (this.renderer == null) this.renderer = new GearArmorRenderer(s);
				return this.renderer;
			}
		});
	}
}
