package de.daemonenlord.gear;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;

import de.daemonenlord.boss.Fx;
import de.daemonenlord.boss.FxEntity;
import de.daemonenlord.party.PartyManager;

/** Stats-Schaden, Set-Boni, Schwert-Faehigkeiten und das Mitfuehren der 3D-Ruestungs-Entity. */
public final class GearEvents {
	private GearEvents() {}

	private static boolean guard = false;
	private static final Map<UUID, Long> EID_ACTIVE = new HashMap<>();
	private static final Map<UUID, Long> EID_READY = new HashMap<>();
	private static final Map<UUID, Long> KILL_BUFF = new HashMap<>();
	private static final Map<String, Long> COOLDOWN = new HashMap<>();

	public static void register() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register(GearEvents::allowDamage);
		ServerLivingEntityEvents.AFTER_DEATH.register(GearEvents::afterDeath);
		UseItemCallback.EVENT.register(GearEvents::use);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			EID_ACTIVE.clear(); EID_READY.clear(); KILL_BUFF.clear(); COOLDOWN.clear();
		});
	}

	// ------------------------------------------------------------------ Schaden
	private static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
		if (guard) return true;
		if (!(entity.level() instanceof ServerLevel level)) return true;
		// kein Friendly Fire in der Party
		if (entity instanceof ServerPlayer v && source.getEntity() instanceof ServerPlayer a && a != v && PartyManager.sameParty(a, v)) return false;
		float out = modify(level, entity, source, amount);
		if (Math.abs(out - amount) < 0.0005f) return true;
		guard = true;
		try {
			entity.hurtServer(level, source, out);
		} finally {
			guard = false;
		}
		return false;
	}

	/** Staerke -> Crit -> Defense des Opfers. Schaden ohne Angreifer (Void, /kill) wird nicht angefasst. */
	private static float modify(ServerLevel level, LivingEntity victim, DamageSource src, float amount) {
		if (amount <= 0.0f || src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return amount;
		long now = level.getGameTime();
		float dmg = amount;
		Entity atk = src.getEntity();
		if (atk instanceof ServerPlayer p && src.getDirectEntity() == p) {
			int[] a = Gear.totals(p);
			int str = a[0];
			boolean glass = Gear.count(p, Gear.Set.GLASS) >= 4;
			if (glass && KILL_BUFF.getOrDefault(p.getUUID(), 0L) > now) str += 20;
			if (Gear.wearing(p)) {
				// (Waffenschaden + 5) x (1 + Staerke/100); amount/8 erhaelt Angriffs-Abklingzeit, Vanilla-Crit und Ability-Schaden
				Gear.Piece w = Gear.worn(p, net.minecraft.world.entity.EquipmentSlot.MAINHAND);
				dmg = amount / 8.0f * ((w != null ? w.weapon() : 0.0f) + 5.0f) * (1.0f + str / 100.0f);
			}
			int cc = Math.min(100, a[1]);
			if (cc > 0 && level.getRandom().nextInt(100) < cc) {
				dmg *= 1.0f + a[2] / 100.0f;
				Fx.cmd(level, victim.position(), "particle minecraft:crit ~ ~1 ~ 0.4 0.5 0.4 0.3 14");
				if (glass) chain(level, p, victim, dmg * 0.5f);
			}
		}
		int def = Gear.totals(victim)[3];
		boolean tank = victim instanceof ServerPlayer && Gear.count(victim, Gear.Set.TANK) >= 4;
		UUID id = victim.getUUID();
		if (tank && EID_ACTIVE.getOrDefault(id, 0L) > now) def += 250;
		float out = dmg * 100.0f / (100.0f + def);
		if (tank && EID_ACTIVE.getOrDefault(id, 0L) <= now && EID_READY.getOrDefault(id, 0L) <= now
				&& victim.getHealth() - out < victim.getMaxHealth() * 0.4f) {
			EID_ACTIVE.put(id, now + 200);
			EID_READY.put(id, now + 600);
			def += 250;
			out = dmg * 100.0f / (100.0f + def);
			Fx.cmd(level, victim.position(), "effect give " + victim.getStringUUID() + " minecraft:regeneration 10 1 true");
			Fx.cmd(level, victim.position(), "particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.8 0.5 0.3 30");
			Fx.cmd(level, victim.position(), "playsound minecraft:item.totem.use player @a ~ ~ ~ 0.6 1.4");
			bar(level, (ServerPlayer) victim, "§6Eidschwur! §7+250 Defense und Regeneration");
		}
		// Party-Tank (4/4 Tank-Set) faengt einen Teil des Schadens der anderen Mitglieder ab
		if (victim instanceof ServerPlayer vp) {
			PartyManager.Party party = PartyManager.of(vp.getUUID());
			if (party != null) {
				ServerPlayer t = PartyManager.tank(level.getServer(), party);
				if (t != null && t != vp && t.level() == level && t.distanceToSqr(vp) <= PartyManager.TANK_RANGE * PartyManager.TANK_RANGE) {
					float share = out * PartyManager.TANK_SHARE;
					out -= share;
					t.hurtServer(level, level.damageSources().generic(), share);
					Fx.cmd(level, t.position(), "particle minecraft:enchanted_hit ~ ~1 ~ 0.4 0.6 0.4 0.2 12");
				}
			}
		}
		return out;
	}

	/** Sternensturm: Blitz-Sprung auf bis zu 4 Gegner in 5 Bloecken. */
	private static void chain(ServerLevel level, ServerPlayer p, LivingEntity first, float dmg) {
		List<LivingEntity> near = level.getEntitiesOfClass(LivingEntity.class, first.getBoundingBox().inflate(5.0),
				e -> e != first && e != p && e.isAlive() && e instanceof Mob && !(e instanceof FxEntity));
		int n = 0;
		for (LivingEntity e : near) {
			if (n++ >= 4) break;
			e.hurtServer(level, level.damageSources().magic(), dmg);
			Fx.cmd(level, e.position(), "particle minecraft:electric_spark ~ ~1 ~ 0.3 0.5 0.3 0.2 14");
		}
		if (n > 0) Fx.cmd(level, first.position(), "playsound minecraft:entity.lightning_bolt.impact player @a ~ ~ ~ 0.5 1.8");
	}

	private static void bar(ServerLevel level, ServerPlayer p, String text) {
		Fx.cmd(level, p.position(), "title " + p.getStringUUID() + " actionbar {text:\"" + text + "\"}");
	}

	private static void afterDeath(LivingEntity entity, DamageSource src) {
		if (src.getEntity() instanceof ServerPlayer p && entity.level() instanceof ServerLevel level && Gear.count(p, Gear.Set.GLASS) >= 4) {
			KILL_BUFF.put(p.getUUID(), level.getGameTime() + 100);
			bar(level, p, "§bSternensturm! §7+20 Stärke für 5s");
		}
	}

	// ------------------------------------------------------------------ Faehigkeiten (Rechtsklick)
	private static InteractionResult use(Player player, Level level, InteractionHand hand) {
		if (level.isClientSide() || hand != InteractionHand.MAIN_HAND || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;
		ServerLevel lv = (ServerLevel) level;
		Gear.Piece pc = Gear.of(player.getItemInHand(hand));
		if (pc == Gear.Piece.MIDAS_SWORD) {
			if (!ready(sp, lv, "midas", 160)) return InteractionResult.PASS;
			midas(sp, lv);
			return InteractionResult.SUCCESS;
		}
		if (pc == Gear.Piece.ARC_SWORD) {
			if (!ready(sp, lv, "arc", 120)) return InteractionResult.PASS;
			arc(sp, lv);
			return InteractionResult.SUCCESS;
		}
		return InteractionResult.PASS;
	}

	private static boolean ready(ServerPlayer p, ServerLevel lv, String key, int ticks) {
		String k = p.getUUID() + key;
		long now = lv.getGameTime();
		long until = COOLDOWN.getOrDefault(k, 0L);
		if (until > now) {
			bar(lv, p, "§7Abklingzeit: §f" + String.format(Locale.ROOT, "%.1f", (until - now) / 20.0) + "s");
			return false;
		}
		COOLDOWN.put(k, now + ticks);
		return true;
	}

	private static boolean target(Entity x, Player p) {
		return x != p && x instanceof Mob && x.isAlive() && !(x instanceof FxEntity);
	}

	/** Goldener Urteilsspruch: Schockwelle, Verlangsamung, 10 % Heilung. */
	private static void midas(ServerPlayer p, ServerLevel lv) {
		DamageSource ds = lv.damageSources().playerAttack(p);
		AABB box = p.getBoundingBox().inflate(6.0, 2.5, 6.0);
		List<LivingEntity> list = lv.getEntitiesOfClass(LivingEntity.class, box, x -> target(x, p) && x.distanceToSqr(p) <= 36.0);
		for (LivingEntity e : list) {
			e.hurtServer(lv, ds, 8.0f);
			Fx.cmd(lv, e.position(), "effect give " + e.getStringUUID() + " minecraft:slowness 3 2 true");
		}
		p.heal(p.getMaxHealth() * 0.10f);
		Vec3 c = p.position();
		Fx.cmd(lv, c, "particle minecraft:totem_of_undying ~ ~0.3 ~ 3 0.2 3 0.15 90");
		Fx.cmd(lv, c, "particle minecraft:end_rod ~ ~0.5 ~ 3 0.4 3 0.05 60");
		Fx.cmd(lv, c, "playsound minecraft:block.bell.use player @a ~ ~ ~ 1.2 0.6");
		Fx.cmd(lv, c, "playsound minecraft:item.totem.use player @a ~ ~ ~ 0.4 1.6");
	}

	/** Bogenschnitt: Dash nach vorn, Sichelschnitt trifft alles auf dem Weg. */
	private static void arc(ServerPlayer p, ServerLevel lv) {
		Vec3 look = p.getLookAngle();
		Vec3 dir = new Vec3(look.x, 0.0, look.z);
		dir = dir.lengthSqr() < 1.0e-4 ? new Vec3(0, 0, 1) : dir.normalize();
		Vec3 start = p.position();
		Vec3 end = start;
		for (double d = 0.5; d <= 8.0; d += 0.5) {
			Vec3 t = start.add(dir.scale(d));
			AABB bb = p.getBoundingBox().move(t.subtract(start));
			if (!lv.noCollision(p, bb)) break;
			end = t;
		}
		DamageSource ds = lv.damageSources().playerAttack(p);
		Vec3 a = start, b = end;
		AABB box = new AABB(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z), Math.max(a.x, b.x), Math.max(a.y, b.y) + 2.0, Math.max(a.z, b.z)).inflate(2.0);
		for (LivingEntity e : lv.getEntitiesOfClass(LivingEntity.class, box, x -> target(x, p))) {
			if (segDist(a, b, e.position()) <= 2.0) e.hurtServer(lv, ds, 10.0f);
		}
		double len = end.subtract(start).length();
		for (double d = 0.0; d <= len; d += 1.2) {
			Vec3 q = start.add(dir.scale(d));
			Fx.cmd(lv, q, "particle minecraft:sweep_attack ~ ~1.0 ~ 0.2 0.3 0.2 0 1");
			Fx.cmd(lv, q, "particle minecraft:electric_spark ~ ~1.0 ~ 0.3 0.4 0.3 0.2 6");
		}
		Fx.cmd(lv, start, "playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1.2 1.3");
		Fx.cmd(lv, start, String.format(Locale.ROOT, "tp %s %.3f %.3f %.3f", p.getStringUUID(), end.x, end.y, end.z));
		Fx.cmd(lv, end, "playsound minecraft:item.trident.return player @a ~ ~ ~ 0.8 1.6");
	}

	private static double segDist(Vec3 a, Vec3 b, Vec3 q) {
		Vec3 ab = b.subtract(a);
		double l2 = ab.lengthSqr();
		double t = l2 < 1.0e-6 ? 0.0 : Math.max(0.0, Math.min(1.0, q.subtract(a).dot(ab) / l2));
		return a.add(ab.scale(t)).distanceTo(q);
	}
}
