package de.daemonenlord.boss;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.DaemonenlordEntity.Shock;

/** Wiederbelebung (einmalig): "Der Richter erhebt sich erneut" - ab jetzt Rot statt Gold. Dauer 220 Ticks. */
final class ReviveLogic {
	private ReviveLogic() {}

	static final int DURATION = 220;
	private static final java.util.Random R = new java.util.Random();

	static void tick(DaemonenlordEntity b, ServerLevel l, int t) {
		Fx.currentRed = true;
		Vec3 g = new Vec3(b.getX(), Fx.groundY(l, b.getX(), b.getY(), b.getZ()), b.getZ());
		Vec3 c = b.position().add(0, 5.6, 0);

		boolean second = b.reviveSecond;
		if (t == 0) {
			if (second) {
				var mh = b.getAttribute(Attributes.MAX_HEALTH);
				if (mh != null) mh.setBaseValue(300.0); // HP auf ein Fuenftel
			}
			Fx.title(l, c, 120, second ? "DIE LETZTE VERDAMMNIS" : "ES IST NOCH NICHT VORBEI",
					second ? "Schneller. Tödlicher. Zerbrechlich." : "Der Richter fällt … und erhebt sich erneut", "dark_red");
			Fx.flash(l, c, 100, 30);
			Fx.sound(l, c, "minecraft:entity.wither.death", 8.0f, 0.5f);
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 8.0f, 0.4f);
			Fx.p(l, Fx.SMOKE, c, 80, 2.5, 0.05);
		}
		if (t == 10) {
			Fx.fx(l, Fx.K_SEAL, g.add(0, 0.05, 0), 205, 1.3f, 1.0f);
			for (int k = 0; k < 8; k++) {
				double ang = Math.PI * 2 * k / 8;
				b.pillars.add(Fx.fx(l, Fx.K_PILLAR, g.add(Math.cos(ang) * 15, 0, Math.sin(ang) * 15), 200, 0.5f, 0.7f));
			}
			Fx.sound(l, g, "minecraft:block.beacon.activate", 8.0f, 0.4f);
		}

		// Boss sinkt zu Boden, zittert
		if (t < 100) {
			double wantY = g.y + 1.5;
			b.setDeltaMovement((R.nextDouble() - 0.5) * 0.08, Math.max(-0.35, Math.min(0.2, (wantY - b.getY()) * 0.1)), (R.nextDouble() - 0.5) * 0.08);
		}
		// Dunkelrote Energie sammelt sich
		if (t >= 10 && t < 100) {
			for (int i = 0; i < 5; i++) {
				double th = R.nextDouble() * Math.PI * 2, ph = Math.acos(2 * R.nextDouble() - 1);
				Vec3 o = new Vec3(Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th));
				double rad = 18 - (t - 10) * 0.15;
				Fx.dir(l, Fx.SOUL, c.add(o.scale(rad)), o.scale(-1), 0.5);
			}
			if (t % 10 == 0) Fx.sound(l, c, "minecraft:block.beacon.power_select", 6.0f, 0.4f + (t - 10) * 0.006f);
			Fx.ring(l, Fx.FLAME, g, 15, 50, 0.2);
		}
		// Lebensleiste fuellt sich bis 60 %
		if (t >= 40 && t <= 200) {
			float f = (second ? 1.0f : 0.6f) * (t - 40) / 160.0f;
			b.setHealth(Math.max(1.0f, b.getMaxHealth() * f));
		}
		if (t == 100) {
			b.setRevivals(b.getRevivals() + 1);
			b.redBar();
			Fx.flash(l, c, 120, 60);
			Fx.title(l, c, 120, second ? "WUT DER VERDAMMNIS" : "VERDAMMNIS", second ? "60 % schneller – doppelter Schaden" : "Rot ist die Farbe des Urteils", "dark_red");
			Fx.sound(l, c, "minecraft:entity.generic.explode", 10.0f, 0.4f);
			Fx.sound(l, c, "minecraft:entity.lightning_bolt.thunder", 10.0f, 0.4f);
			Fx.p(l, Fx.BOOM, c, 6, 4, 0);
			Fx.p(l, Fx.SOUL, c, 400, 4, 1.0);
			Fx.p(l, Fx.FLAME, c, 300, 3, 0.8);
			for (ServerPlayer p : Fx.players(l, g, 14)) {
				Fx.damageRaw(l, p, 10f);
				Fx.push(p, new Vec3(p.getX() - g.x, 0, p.getZ() - g.z).normalize().scale(1.4).add(0, 1.0, 0));
			}
			b.shocks.add(new Shock(g, 1.0, 40, 12f, 1));
		}
		if (t == 112 || t == 124) b.shocks.add(new Shock(g, 1.0, 40, 12f, t == 112 ? 0 : 1));
		// Boss steigt wieder auf
		if (t >= 140 && t < 200) {
			double wantY = g.y + 5.5;
			b.setDeltaMovement(0, Math.max(0.0, Math.min(0.45, (wantY - b.getY()) * 0.1)), 0);
			if (t % 3 == 0) Fx.p(l, Fx.SOUL, b.getX(), b.getY() + 3, b.getZ(), 6, 1.5, 2.5, 1.5, 0.05);
		}
		if (t == 140) {
			b.addFollower(l, Fx.K_BLADERING, new Vec3(0, 6.2, 0), 70, 1.1f);
			b.addFollower(l, Fx.K_CORE, new Vec3(0, 6.8, 0), 70, 0.7f);
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 10.0f, 0.5f);
		}
		if (t >= DURATION) {
			b.reviving = false;
			b.setInvulnerable(false);
			b.setHealth(b.getMaxHealth() * (second ? 1.0f : 0.6f));
			b.clearFx();
			b.ult2Done = false;
			if (second) b.ult1Done = false;
			b.cooldown = 40;
			b.freezeHover = false;
			b.phase = 3;
			if (second) DomainLogic.start(b, l);
			else Fx.title(l, c, 120, "DER RICHTER IST ZURÜCK", "Zeigt ihm keine Gnade", "dark_red");
		}
	}
}
