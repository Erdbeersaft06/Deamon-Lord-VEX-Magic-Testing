package de.daemonenlord.boss;

public enum Attack {
	// Phase 1
	HELLFIRE("hoellenfeuer", "Höllenfeuer-Salve", 1, 100),
	BLADES("klingenhagel", "Klingenhagel", 1, 90),
	SHOCKWAVE("seelenwelle", "Seelenfeuer-Welle", 1, 70),
	SUMMON("schatten", "Schattenbeschwörung", 1, 90),
	// Phase 2
	STARFALL("sternenfall", "Sternenfall", 2, 105),
	VOID("sog", "Dunkler Sog", 2, 95),
	BEAM("strahl", "Strahl des Urteils", 2, 90),
	HALO("strahlenkranz", "Strahlenkranz", 2, 120),
	// Phase 3
	SLAM("himmelsbruch", "Himmelsbruch", 3, 85),
	SWORDS("schwerter", "Schwertgericht", 3, 100),
	DRAIN("aderlass", "Seelenaderlass", 3, 190),
	HINRICHTUNG("hinrichtung", "Arkane Hinrichtung", 3, 130),
	LINK("seelenbund", "Seelenbund", 3, 140),
	ULTIMATE("juengstes_gericht", "Das Jüngste Gericht der Asche", 99, 250),
	AUSLOESCHUNG("ausloeschung", "Pforte der Auslöschung", 99, 330);

	public final String id;
	public final String title;
	public final int minPhase;
	public final int duration;

	Attack(String id, String title, int minPhase, int duration) {
		this.id = id;
		this.title = title;
		this.minPhase = minPhase;
		this.duration = duration;
	}

	public static Attack byId(String id) {
		for (Attack a : values()) if (a.id.equalsIgnoreCase(id)) return a;
		return null;
	}
}
