package de.daemonenlord.boss;

public enum Attack {
	HELLFIRE("hoellenfeuer", "Höllenfeuer-Salve", 1, 100),
	BLADES("klingenhagel", "Klingenhagel", 1, 90),
	SHOCKWAVE("seelenwelle", "Seelenfeuer-Welle", 1, 70),
	STARFALL("sternenfall", "Sternenfall", 1, 105),
	VOID("sog", "Dunkler Sog", 2, 95),
	SUMMON("schatten", "Schattenbeschwörung", 1, 70),
	BEAM("strahl", "Strahl des Urteils", 2, 125),
	SLAM("himmelsbruch", "Himmelsbruch", 2, 85),
	ULTIMATE("juengstes_gericht", "Das Jüngste Gericht der Asche", 99, 160);

	public final String id;
	public final String title;
	public final int minPhase;
	public final int duration;

	Attack(String id, String title, int minPhase, int duration) {
		this.id = id;
		this.title = title;
		this.minPhase = minPhase;
		this.duration = duration;
	}

	public static Attack byId(String id) {
		for (Attack a : values()) if (a.id.equalsIgnoreCase(id)) return a;
		return null;
	}
}
