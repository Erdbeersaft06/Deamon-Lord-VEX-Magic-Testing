package de.daemonenlord.boss;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.DaemonenlordEntity.Shock;

/**
 * Domaene der Verdammnis (nach der 2. Wiederbelebung): ein Runenkreis, der von Anfang an gross ist und staendig schrumpft.
 * Bei Radius 0: Boss heilt 50 % und es gibt eine Explosion (80 % der max. HP jedes Spielers im Bereich).
 */
final class DomainLogic {
	private DomainLogic() {}

	static void start(DaemonenlordEntity b, ServerLevel l) {
		b.domainActive = true;
		b.domainTick = 0;
		b.domainCenter = new Vec3(b.getX(), Fx.groundY(l, b.getX(), b.getY(), b.getZ()), b.getZ());
		Fx.title(l, b.domainCenter, 120, "DOMÄNE DER VERDAMMNIS", "Sie schrumpft … erschlagt ihn, bevor sie erlischt", "dark_red");
		Fx.sound(l, b.domainCenter, "minecraft:block.beacon.activate", 10.0f, 0.4f);
	}

	static void stop(DaemonenlordEntity b) {
		b.domainActive = false;
		if (b.domainSeal != null && !b.domainSeal.isRemoved()) b.domainSeal.fade();
		b.domainSeal = null;
	}

	static void tick(DaemonenlordEntity b, ServerLevel l) {
		if (!b.domainActive) return;
		int total = Math.max(20, DaemonenlordEntity.domainSeconds * 20);
		int t = b.domainTick++;
		double start = DaemonenlordEntity.domainRadius;
		double r = start * (1.0 - (double) t / total);
		Vec3 c = b.domainCenter;
		if (r <= 0.5) {
			finish(b, l);
			return;
		}
		float sc = (float) (r / 15.3);
		if (b.domainSeal == null || b.domainSeal.isRemoved()) {
			b.domainSeal = Fx.fx(l, Fx.K_SEAL, c.add(0, 0.05, 0), total + 40, sc, 1.0f);
		} else {
			b.domainSeal.setScale(sc, 1.0f);
		}
		if (t % 2 == 0) {
			int n = (int) Math.min(140, Math.max(24, r * 2.2));
			Fx.ring(l, Fx.SOUL, c, r, n, 0.3);
			Fx.ring(l, Fx.FLAME, c, r, n / 2, 2.6);
			for (int k = 0; k < 18; k++) {
				double a = Math.PI * 2 * k / 18 + t * 0.01;
				for (double y = 0.5; y < 8; y += 2.0) {
					Fx.p(l, Fx.SOUL, c.x + Math.cos(a) * r, c.y + y, c.z + Math.sin(a) * r, 1, 0.1, 0.2, 0.1, 0.0);
				}
			}
		}
		if (t % 20 == 0) {
			Fx.actionbar(l, c, start + 40, "☠ DOMÄNE: " + (int) Math.ceil(r) + " Blöcke ☠", "dark_red");
			Fx.sound(l, c, "minecraft:block.beacon.ambient", 4.0f, 0.5f);
		}
	}

	private static void finish(DaemonenlordEntity b, ServerLevel l) {
		Vec3 c = b.domainCenter.add(0, 2, 0);
		stop(b);
		b.heal(b.getMaxHealth() * 0.5f);
		Fx.flash(l, c, 150, 60);
		Fx.title(l, c, 120, "DIE DOMÄNE ZERBRICHT", "Der Richter heilt sich – und die Welt brennt", "dark_red");
		Fx.sound(l, c, "minecraft:entity.generic.explode", 12.0f, 0.4f);
		Fx.sound(l, c, "minecraft:entity.lightning_bolt.thunder", 12.0f, 0.4f);
		Fx.sound(l, c, "minecraft:entity.wither.death", 10.0f, 0.5f);
		Fx.p(l, Fx.BOOM, c, 10, 6, 0);
		Fx.p(l, Fx.SOUL, c, 500, 6, 1.2);
		Fx.p(l, Fx.FLAME, c, 400, 6, 1.0);
		double reach = DaemonenlordEntity.domainRadius;
		for (ServerPlayer p : Fx.players(l, c, reach)) {
			Fx.damageRaw(l, p, p.getMaxHealth() * 0.8f); // 80 % der max. HP
			Fx.push(p, new Vec3(p.getX() - c.x, 0, p.getZ() - c.z).normalize().scale(1.6).add(0, 1.0, 0));
		}
		Vec3 g = new Vec3(c.x, b.domainCenter.y, c.z);
		b.shocks.add(new Shock(g, 1.3, Math.min(reach, 60), 0f, 1));
	}
}
