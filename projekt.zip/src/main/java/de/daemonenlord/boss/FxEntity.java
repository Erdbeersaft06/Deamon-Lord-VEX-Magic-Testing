package de.daemonenlord.boss;

import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Reine Effekt-Entity: zeigt Teile des Blockbench-Modells (Siegel, Kern, Klingen, Lichtsaeule, Welle ...).
 * Wird nur vom Boss erzeugt, lebt kurz und wird nie gespeichert.
 */
public class FxEntity extends Mob {
	private static final EntityDataAccessor<Integer> KIND = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> LIFE = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Float> SXZ = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.FLOAT);
	private static final EntityDataAccessor<Float> SY = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.FLOAT);
	private static final EntityDataAccessor<Float> AX = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.FLOAT);
	private static final EntityDataAccessor<Integer> TINT = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Boolean> BLUE = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.BOOLEAN);
	private static final EntityDataAccessor<Boolean> RED = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.BOOLEAN);
	private static final EntityDataAccessor<Float> AY = SynchedEntityData.defineId(FxEntity.class, EntityDataSerializers.FLOAT);

	/** Offset zum Boss, falls dieser Effekt dem Boss folgen soll. */
	public Vec3 follow = null;

	public FxEntity(EntityType<? extends Mob> type, Level level) {
		super(type, level);
		this.setNoAi(true);
		this.setNoGravity(true);
		this.setInvulnerable(true);
		this.setPersistenceRequired();
		try {
			java.lang.reflect.Field f = net.minecraft.world.entity.Entity.class.getField("noCulling");
			f.setBoolean(this, true);
		} catch (Throwable ignored) { }
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Mob.createMobAttributes();
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(KIND, 0);
		builder.define(LIFE, 0);
		builder.define(SXZ, 1.0f);
		builder.define(SY, 1.0f);
		builder.define(AX, 0.0f);
		builder.define(AY, 0.0f);
		builder.define(RED, false);
		builder.define(BLUE, false);
		builder.define(TINT, 0);
	}

	public void setup(int kind, int life, float sxz, float sy) {
		this.entityData.set(KIND, kind);
		this.entityData.set(LIFE, life);
		this.entityData.set(SXZ, sxz);
		this.entityData.set(SY, sy);
	}

	public void setScale(float sxz, float sy) {
		this.entityData.set(SXZ, sxz);
		this.entityData.set(SY, sy);
	}

	/** Richtet die Modell-Achse (Lichtsaeule/Strahl) entlang der Weltrichtung d aus. */
	public void setAim(Vec3 d) {
		Vec3 n = d.normalize();
		this.entityData.set(AX, (float) Math.acos(Math.max(-1.0, Math.min(1.0, n.y))));
		this.entityData.set(AY, (float) Math.atan2(-n.x, n.z));
	}

	/** 0 = Standard (Gold/Rot/Blau), 3..6 = Gruen/Violett/Cyan/Magenta, 7 = Weiss. */
	public void setTint(int t) { this.entityData.set(TINT, t); }
	public int getTint() { return this.entityData.get(TINT); }
	/** Drehgeschwindigkeit (nur Kind 10, nutzt das AX-Feld). */
	public void setSpin(float s) { this.entityData.set(AX, s); }

	// Effekt-Entities stossen niemanden weg und werden nicht weggestossen
	public boolean isPushable() { return false; }
	public void push(net.minecraft.world.entity.Entity e) { }
	public void push(double x, double y, double z) { }
	protected void pushEntities() { }
	protected void doPush(net.minecraft.world.entity.Entity e) { }

	public void setBlue(boolean r) { this.entityData.set(BLUE, r); }
	public boolean isBlue() { return this.entityData.get(BLUE); }
	public void setRed(boolean r) { this.entityData.set(RED, r); }
	public boolean isRed() { return this.entityData.get(RED); }

	public void fade() {
		this.entityData.set(LIFE, this.tickCount + 8);
	}

	public int getKind() { return this.entityData.get(KIND); }
	public int getLife() { return this.entityData.get(LIFE); }
	public float getSxz() { return this.entityData.get(SXZ); }
	public float getSy() { return this.entityData.get(SY); }
	public float getAx() { return this.entityData.get(AX); }
	public float getAy() { return this.entityData.get(AY); }

	@Override
	public boolean isPickable() { return false; }

	@Override
	public boolean isPushable() { return false; }

	@Override
	public void tick() {
		super.tick();
		if (!this.level().isClientSide() && this.tickCount > this.getLife()) {
			this.discard();
		}
	}
}
