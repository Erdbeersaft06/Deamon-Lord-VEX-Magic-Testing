package de.daemonenlord.boss;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Der Daemonenlord: schwebender Endboss mit 3 Phasen, 8 Attacken und dem Ultimate "Das Juengste Gericht der Asche". */
public class DaemonenlordEntity extends Monster {
	private static final EntityDataAccessor<Integer> STATE =
			SynchedEntityData.defineId(DaemonenlordEntity.class, EntityDataSerializers.INT);
	private static final EntityDataAccessor<Integer> REVIVALS =
			SynchedEntityData.defineId(DaemonenlordEntity.class, EntityDataSerializers.INT);
	public static final int ST_IDLE = 0, ST_CAST = 1, ST_ULT = 2;

	/** Globaler Schaden in Prozent (100 = Standard), per /daemonenlord damage <prozent> aenderbar. Gilt fuer neue und bestehende Bosse. */
	public static int defaultDmgPercent = 100;

	private final ServerBossEvent bossEvent = Fx.bossEvent(Component.literal("§6§lDämonenlord §8– §eRichter der Asche"));

	// ---- Zustand (nur Server) ----
	int phase = 1;
	Attack attack = null;
	int atkTick = 0;
	int cooldown = 60;
	int stun = 0;
	boolean ult1Done = false, ult2Done = false;
	Attack queued = null;
	LivingTargetRef targetRef = new LivingTargetRef();
	boolean freezeHover = false;
	final List<Strike> strikes = new ArrayList<>();
	final List<Shock> shocks = new ArrayList<>();
	Vec3 beamDir = Vec3.ZERO;
	double beamSweep = 0;
	Vec3 lockPos = Vec3.ZERO;
	double ultBaseY = 0;
	Vec3 ultCenter = Vec3.ZERO;
	Attack lastAttack = null;
	final List<FxEntity> followers = new ArrayList<>();
	final List<FxEntity> pillars = new ArrayList<>();
	FxEntity beamFx = null;
	public int dmgPercent = defaultDmgPercent;
	boolean reviving = false;
	int reviveTick = 0;
	int minionQueue = 0;
	AttackLogic.Exec exec = null;
	AttackLogic.Ann ann = null;
	FxEntity ultScale = null;
	final java.util.Set<java.util.UUID> ultPlayers = new java.util.HashSet<>();
	boolean finalDone = false;
	Attack prevAttack = null;
	int heavyCd = 0;
	boolean reviveSecond = false;
	float speedAcc = 0f;
	int linkLife = new java.util.Random().nextInt(2); // 0 = 1. Leben, 1 = 2. Leben
	boolean linkDone = false;
	final java.util.Map<java.util.UUID, Vec3> frozen = new java.util.HashMap<>();
	// Domaene
	public static int domainRadius = 60, domainSeconds = 60;
	boolean domainActive = false;
	int domainTick = 0;
	Vec3 domainCenter = Vec3.ZERO;
	final java.util.Set<java.util.UUID> domainPlayers = new java.util.HashSet<>();
	FxEntity domainSeal = null;
	final List<Sword> swords = new ArrayList<>();
	final List<DrainCircle> drains = new ArrayList<>();
	final Map<java.util.UUID, FxEntity> linkBeams = new HashMap<>();
	final List<FxEntity> haloBeams = new ArrayList<>();
	final java.util.Random rnd = new java.util.Random();
	private boolean redApplied = false;

	public DaemonenlordEntity(EntityType<? extends Monster> type, Level level) {
		super(type, level);
		this.setNoGravity(true);
		this.setPersistenceRequired();
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, 1500.0)
				.add(Attributes.ARMOR, 14.0)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
				.add(Attributes.MOVEMENT_SPEED, 0.35)
				.add(Attributes.FOLLOW_RANGE, 96.0)
				.add(Attributes.ATTACK_DAMAGE, 18.0);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(STATE, ST_IDLE);
		builder.define(REVIVALS, 0);
	}

	public int getCastState() { return this.entityData.get(STATE); }
	public int getRevivals() { return this.entityData.get(REVIVALS); }
	public boolean isRevived() { return getRevivals() >= 1; }
	void setRevivals(int v) { this.entityData.set(REVIVALS, v); }

	/** Ab der 2. Wiederbelebung: Attacken & Bewegung 60 % schneller. */
	float speedFactor() { return getRevivals() >= 2 ? 1.5f : 1.0f; }

	/** Gesamt-Schadensfaktor (Befehl + Wiederbelebung). */
	public float damageMultiplier() {
		int r = getRevivals();
		return (dmgPercent / 100.0f) * (r == 0 ? 1.0f : r == 1 ? 1.35f : 2.7f);
	}
	private void setCastState(int s) { this.entityData.set(STATE, s); }

	@Override
	public boolean isPushable() { return false; }

	// ---- Bossleiste ----
	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		bossEvent.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		bossEvent.removePlayer(player);
	}

	@Override
	public void remove(RemovalReason reason) {
		bossEvent.removeAllPlayers();
		clearFx();
		clearSwords();
		DomainLogic.stop(this);
		super.remove(reason);
	}

	// ---- Speichern ----
	@Override
	protected void addAdditionalSaveData(ValueOutput out) {
		super.addAdditionalSaveData(out);
		out.putInt("dl_phase", phase);
		out.putInt("dl_dmg", dmgPercent);
		out.putInt("dl_revived", getRevivals());
		out.putInt("dl_ult1", ult1Done ? 1 : 0);
		out.putInt("dl_ult2", ult2Done ? 1 : 0);
		out.putInt("dl_linklife", linkLife);
		out.putInt("dl_linkdone", linkDone ? 1 : 0);
	}

	@Override
	protected void readAdditionalSaveData(ValueInput in) {
		super.readAdditionalSaveData(in);
		phase = in.getInt("dl_phase").orElse(1);
		dmgPercent = in.getInt("dl_dmg").orElse(defaultDmgPercent);
		setRevivals(in.getInt("dl_revived").orElse(0));
		ult1Done = in.getInt("dl_ult1").orElse(0) == 1;
		ult2Done = in.getInt("dl_ult2").orElse(0) == 1;
		linkLife = in.getInt("dl_linklife").orElse(linkLife);
		linkDone = in.getInt("dl_linkdone").orElse(0) == 1;
	}

	// ---- Tod ----
	@Override
	public void die(DamageSource source) {
		if (reviving) return;
		if (getRevivals() < 2 && this.level() instanceof ServerLevel rsl) {
			startRevive(rsl);
			return;
		}
		super.die(source);
		clearFx();
		DomainLogic.stop(this);
		if (this.level() instanceof ServerLevel sl) {
			Vec3 c = this.position().add(0, 4, 0);
			Fx.flash(sl, c, 90, 60);
			Fx.title(sl, c, 90, "DER RICHTER IST GEFALLEN", "Die Asche verstummt …", "gold");
			Fx.sound(sl, c, "minecraft:entity.wither.death", 6.0f, 0.6f);
			Fx.sound(sl, c, "minecraft:entity.ender_dragon.death", 6.0f, 0.8f);
			for (int i = 0; i < 6; i++) Fx.p(sl, Fx.BOOM, c, 1, 4, 0);
			Fx.p(sl, Fx.TOTEM, c, 400, 5, 0.9);
			Fx.p(sl, Fx.ROD, c, 300, 6, 0.6);
			for (int i = 0; i < 8; i++) {
				Fx.cmd(sl, c, "summon minecraft:experience_orb " + c.x + " " + c.y + " " + c.z + " {Value:400s}");
			}
			Fx.cmd(sl, c, "kill @e[tag=" + Fx.MINION_TAG + ",distance=..120]");
		}
	}

	// ---- Blockbench-Effekte ----
	void addFollower(ServerLevel l, int kind, Vec3 offset, int life, float scale) {
		FxEntity f = Fx.fx(l, kind, this.position().add(offset), life, scale, scale);
		f.follow = offset;
		followers.add(f);
	}

	void clearFx() {
		if (exec != null) { exec.clear(); exec = null; }
		if (ann != null) { ann.clear(); ann = null; }
		if (ultScale != null && !ultScale.isRemoved()) ultScale.fade();
		ultScale = null;
		ultPlayers.clear();
		frozen.clear();
		for (FxEntity f : followers) if (!f.isRemoved()) f.fade();
		for (FxEntity f : pillars) if (!f.isRemoved()) f.fade();
		followers.clear();
		pillars.clear();
		beamFx = null;
		for (DrainCircle d : drains) d.fade();
		drains.clear();
		for (FxEntity f : linkBeams.values()) if (!f.isRemoved()) f.fade();
		linkBeams.clear();
		for (FxEntity f : haloBeams) if (!f.isRemoved()) f.fade();
		haloBeams.clear();
	}

	void clearSwords() {
		for (Sword sw : swords) if (sw.fx != null && !sw.fx.isRemoved()) sw.fx.fade();
		swords.clear();
	}

	public void startDomain(ServerLevel sl) {
		DomainLogic.stop(this);
		DomainLogic.start(this, sl);
	}

	private boolean blueApplied = false;

	void blueBar() {
		bossEvent.setColor(BossEvent.BossBarColor.BLUE);
		bossEvent.setName(Component.literal("§9§lDämonenlord §8– §bDie letzte Verdammnis"));
		blueApplied = true;
	}

	void redBar() {
		bossEvent.setColor(BossEvent.BossBarColor.RED);
		bossEvent.setName(Component.literal("§4§lDämonenlord §8– §cDer Verdammte"));
		redApplied = true;
	}

	// ---- Wiederbelebung ----
	public void startRevive(ServerLevel sl) {
		if (reviving || getRevivals() >= 2) return;
		reviveSecond = getRevivals() >= 1;
		endAttack();
		reviving = true;
		reviveTick = 0;
		this.setHealth(1.0f);
		this.setInvulnerable(true);
		setCastState(ST_ULT);
	}

	private void updateFollowers() {
		for (FxEntity f : followers) {
			if (!f.isRemoved() && f.follow != null) {
				Vec3 p = this.position().add(f.follow);
				f.setPos(p.x, p.y, p.z);
			}
		}
	}

	// ---- Steuerung durch Befehle ----
	public void forceAttack(Attack a) {
		queued = a;
		cooldown = 0;
		if (attack != null) endAttack();
	}

	public void forcePhase(int p) {
		float f = p <= 1 ? 0.95f : p == 2 ? 0.6f : 0.3f;
		this.setHealth(this.getMaxHealth() * f);
	}

	// ---- Haupt-Tick ----
	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) return;
		if (!(this.level() instanceof ServerLevel sl)) return;
		serverTick(sl);
		groundHold(sl);
	}

	// Der Boss stoesst Spieler nicht weg
	protected void pushEntities() { }
	protected void doPush(net.minecraft.world.entity.Entity e) { }

	/** Der Boss steht auf dem Boden (kein Schweben). */
	private void groundHold(ServerLevel sl) {
		if (reviving || attack == Attack.SLAM) return;
		double gy = Fx.groundY(sl, getX(), getY(), getZ());
		double dy = gy - getY();
		Vec3 d = this.getDeltaMovement();
		this.setDeltaMovement(d.x, Math.abs(dy) < 0.05 ? 0 : Mth.clamp(dy * 0.5, -1.5, 1.0), d.z);
	}

	private void serverTick(ServerLevel sl) {
		Fx.currentRed = isRevived();
		Fx.currentBlue = getRevivals() >= 2;
		if (isRevived() && !redApplied) redBar();
		if (getRevivals() >= 2 && !blueApplied) blueBar();
		bossEvent.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0f, 1f));
		tickSwords(sl);
		if (tickCount % 20 == 0 && !reviving) Fx.cmd(sl, this.position(), "kill @e[tag=" + Fx.MINION_TAG + ",distance=50..]");
		DomainLogic.tick(this, sl);

		if (reviving) {
			ReviveLogic.tick(this, sl, reviveTick++);
			updateFollowers();
			tickStrikes(sl);
			tickShocks(sl);
			return;
		}

		float ratio = this.getHealth() / this.getMaxHealth();
		int newPhase = ratio > 0.66f ? 1 : ratio > 0.33f ? 2 : 3;
		if (newPhase > phase) {
			phase = newPhase;
			Vec3 c = this.position().add(0, 4, 0);
			Fx.title(sl, c, 100, phase == 2 ? "PHASE II" : "PHASE III", phase == 2 ? "Der Himmel bricht auf" : "Das Urteil ist gesprochen", "gold");
			Fx.sound(sl, c, "minecraft:entity.ender_dragon.growl", 5.0f, 0.7f);
			Fx.sound(sl, c, "minecraft:block.beacon.activate", 4.0f, 0.5f);
			Fx.p(sl, Fx.ROD, c, 200, 3, 0.5);
			Fx.p(sl, Fx.BOOM, c, 1, 0, 0);
			shocks.add(new Shock(Vec3.ZERO.add(this.getX(), Fx.groundY(sl, getX(), getY(), getZ()), this.getZ()), 0.8, 30, 10f, 0));
			// neue Zauber dieser Phase: einer davon kommt als Naechstes (Debuet)
			List<Attack> fresh = new ArrayList<>();
			for (Attack a : Attack.values()) if (a.minPhase == phase && a != Attack.LINK) fresh.add(a);
			if (!fresh.isEmpty() && queued == null) queued = fresh.get(this.random.nextInt(fresh.size()));
		}
		phase = Math.max(phase, newPhase);

		// Ziel
		ServerPlayer target = nearestPlayer(sl);
		targetRef.player = target;

		updateFollowers();
		tickStrikes(sl);
		tickShocks(sl);
		ambient(sl);

		if (target == null) {
			if (attack != null) endAttack();
			this.setDeltaMovement(this.getDeltaMovement().scale(0.9));
			setCastState(ST_IDLE);
			return;
		}

		face(target);

		if (stun > 0) {
			stun--;
			double gy = Fx.groundY(sl, getX(), getY(), getZ()) + 2.0;
			this.setDeltaMovement(0, Mth.clamp((gy - getY()) * 0.1, -0.3, 0.3), 0);
			if (stun % 4 == 0) Fx.p(sl, Fx.SMOKE, getX(), getY() + 3, getZ(), 3, 1.2, 1.5, 1.2, 0.01);
			return;
		}

		if (attack != null) {
			Attack current = attack;
			speedAcc += speedFactor();
			int steps = (int) speedAcc;
			speedAcc -= steps;
			for (int st = 0; st < steps && attack != null; st++) {
				AttackLogic.tick(this, sl, current, atkTick, target);
				if (attack != null) {
					atkTick++;
					if (atkTick >= current.duration) endAttack();
				}
			}
		} else {
			hover(sl, target);
			if (--cooldown <= 0) chooseAttack(sl);
		}
	}

	private void ambient(ServerLevel sl) {
		// goldene Aura + Heiligenschein-Funken
		if (tickCount % 3 == 0) {
			Fx.p(sl, isRevived() ? Fx.SOUL : Fx.ROD, getX(), getY() + 3.0, getZ(), 2, 1.4, 2.2, 1.4, 0.01);
			Vec3 halo = this.position().add(Math.sin(tickCount * 0.1) * 0.0, 7.0, 0);
			Fx.p(sl, Fx.FLAME, halo.x, halo.y, halo.z, 1, 0.8, 0.8, 0.8, 0.01);
		}
	}

	private void chooseAttack(ServerLevel sl) {
		float ratio = this.getHealth() / this.getMaxHealth();
		Attack next;
		if (queued != null) { next = queued; queued = null; }
		else if (!finalDone && ((getRevivals() == 1 && ratio <= 0.15f) || (getRevivals() == 2 && ratio <= 0.5f))) { next = Attack.AUSLOESCHUNG; finalDone = true; }
		else if (!ult1Done && ratio <= 0.5f) next = Attack.ULTIMATE;
		else if (!ult2Done && ratio <= 0.15f) next = Attack.ULTIMATE;
		else if (ratio <= 0.15f && !linkDone && getRevivals() == linkLife) { next = Attack.LINK; linkDone = true; }
		else {
			// gewichtete Auswahl: Hoellenfeuer haeufig, Aderlass/Hinrichtung selten und mit Pause
			List<Attack> pool = new ArrayList<>();
			List<Float> wts = new ArrayList<>();
			float total = 0f;
			for (Attack a : Attack.values()) {
				if (a == Attack.ULTIMATE || a == Attack.AUSLOESCHUNG || a == Attack.LINK || a.minPhase > phase || a == lastAttack) continue;
				boolean heavy = a == Attack.DRAIN || a == Attack.HINRICHTUNG;
				if (heavy && heavyCd > 0) continue;
				float w = a == Attack.HELLFIRE ? 3.0f : heavy ? 0.5f : 1.0f;
				if (getRevivals() >= 2) {
					// 3. Leben: staerkere Angriffe bevorzugen, Salve/Sternenfall/Einsteigerzauber selten
					w = switch (a) {
						case HELLFIRE -> 0.8f; case STARFALL -> 0.6f;
						case BLADES, SHOCKWAVE, SUMMON -> 0.3f;
						case VOID, BEAM, HALO -> 1.3f;
						case SLAM, SWORDS -> 2.2f;
						case DRAIN, HINRICHTUNG -> 0.9f;
						default -> w;
					};
				}
				if (a == prevAttack) w *= 0.3f;
				pool.add(a); wts.add(w); total += w;
			}
			float roll = this.random.nextFloat() * total;
			next = pool.get(pool.size() - 1);
			for (int i = 0; i < pool.size(); i++) {
				roll -= wts.get(i);
				if (roll <= 0f) { next = pool.get(i); break; }
			}
		}
		if (heavyCd > 0) heavyCd--;
		if (next == Attack.DRAIN || next == Attack.HINRICHTUNG) heavyCd = 5;
		prevAttack = lastAttack;
		if (next == Attack.ULTIMATE) {
			if (!ult1Done && ratio <= 0.5f) ult1Done = true; else if (!ult2Done && ratio <= 0.15f) ult2Done = true;
		}
		attack = next;
		lastAttack = next;
		atkTick = 0;
		freezeHover = false;
		setCastState(next == Attack.ULTIMATE ? ST_ULT : 10 + next.ordinal());
		Fx.actionbar(sl, this.position(), 90, "⚔ " + next.title + " ⚔", next == Attack.ULTIMATE ? "white" : "gold");
		AttackLogic.start(this, sl, next);
	}

	void endAttack() {
		clearFx();
		attack = null;
		atkTick = 0;
		freezeHover = false;
		this.setInvulnerable(false);
		setCastState(ST_IDLE);
		cooldown = switch (phase) { case 1 -> 70; case 2 -> 50; default -> 32; };
		if (isRevived()) cooldown = (int) (cooldown * 0.7);
		cooldown = (int) (cooldown / speedFactor());
	}

	// ---- Bewegung ----
	private void face(ServerPlayer t) {
		double dx = t.getX() - getX(), dz = t.getZ() - getZ();
		float yaw = (float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
		this.setYRot(yaw);
		this.setYBodyRot(yaw);
		this.setYHeadRot(yaw);
	}

	private void hover(ServerLevel sl, ServerPlayer t) {
		if (freezeHover) return;
		Vec3 to = new Vec3(t.getX() - getX(), 0, t.getZ() - getZ());
		double d = to.length();
		Vec3 dir = d > 0.001 ? to.scale(1.0 / d) : Vec3.ZERO;
		double speed = (phase == 3 ? 0.55 : 0.4);
		Vec3 want = Vec3.ZERO;
		if (d > 20) want = dir.scale(speed);
		else if (d < 11) want = dir.scale(-speed * 0.8);
		Vec3 side = new Vec3(-dir.z, 0, dir.x).scale(Math.sin(tickCount * 0.03) * 0.18);
		want = want.add(side);
		double gy = Fx.groundY(sl, t.getX(), t.getY() + 2, t.getZ());
		double wantY = gy + 4.0 + Math.sin(tickCount * 0.07) * 0.8;
		double vy = Mth.clamp((wantY - getY()) * 0.12, -0.5, 0.5);
		Vec3 cur = this.getDeltaMovement();
		this.setDeltaMovement(cur.x + (want.x - cur.x) * 0.15, cur.y + (vy - cur.y) * 0.2, cur.z + (want.z - cur.z) * 0.15);
	}

	private ServerPlayer nearestPlayer(ServerLevel sl) {
		ServerPlayer best = null;
		double bd = Double.MAX_VALUE;
		for (ServerPlayer p : Fx.players(sl, this.position(), 80)) {
			double dd = p.distanceToSqr(this);
			if (dd < bd) { bd = dd; best = p; }
		}
		return best;
	}

	// ---- Schlaege ----
	private void tickSwords(ServerLevel sl) {
		Iterator<Sword> it = swords.iterator();
		while (it.hasNext()) {
			if (it.next().tick(sl, this)) it.remove();
		}
	}

	private void tickStrikes(ServerLevel sl) {
		Iterator<Strike> it = strikes.iterator();
		while (it.hasNext()) {
			Strike s = it.next();
			if (s.tick(sl, this)) it.remove();
		}
	}

	private void tickShocks(ServerLevel sl) {
		Iterator<Shock> it = shocks.iterator();
		while (it.hasNext()) {
			Shock s = it.next();
			if (s.tick(sl, this)) it.remove();
		}
	}

	public int minionCount(ServerLevel sl) {
		AABB box = this.getBoundingBox().inflate(80);
		return sl.getEntities((net.minecraft.world.entity.Entity) null, box, AttackLogic::isMinion).size();
	}

	/** Platzhalter, damit AttackLogic das aktuelle Ziel lesen kann. */
	static class LivingTargetRef { ServerPlayer player; }

	// ---- Strike ----
	/** Verzoegerter Flaecheneinschlag mit Warnring. kind: 0 Feuer, 1 Gold-Klinge, 2 Stern, 3 Lichtsaeule */
	static class Strike {
		final Vec3 pos; int delay; final int total; final float radius; final float dmg; final int kind;
		boolean init = false;
		FxEntity fall = null;
		float bladeScale = 1f;
		Strike(Vec3 pos, int delay, float radius, float dmg, int kind) {
			this.pos = pos; this.delay = delay; this.total = delay; this.radius = radius; this.dmg = dmg; this.kind = kind;
		}

		boolean tick(ServerLevel l, DaemonenlordEntity boss) {
			if (!init) {
				init = true;
				bladeScale = 0.5f + radius * 0.2f;
				// Warnkreis (Blockbench-Welle) + fallendes Modell
				Fx.fx(l, Fx.K_RUNE, pos.add(0, 0.06, 0), total + 3, (float) (radius / 12.25), 1.0f); // aeusserer Ring = Schadensradius
				if (kind == 0) {
					float cs = 0.12f + radius * 0.04f;
					fall = Fx.fx(l, Fx.K_CORE, pos.add(0, total * 1.6 + 0.6, 0), total + 2, cs, cs);
				} else if (kind == 1 || kind == 2) {
					fall = Fx.fx(l, Fx.K_BLADE, pos.add(0, total * 1.6 + 2.8 * bladeScale, 0), total + 2, bladeScale, bladeScale);
				}
			}
			delay--;
			if (fall != null && !fall.isRemoved()) {
				double off = kind == 0 ? 0.6 : 2.8 * bladeScale;
				fall.setPos(pos.x, pos.y + Math.max(delay, 0) * 1.6 + off, pos.z);
			}
			double prog = 1.0 - (double) Math.max(delay, 0) / total;
			if (delay % 2 == 0) {
				var warn = kind == 1 || kind == 3 ? Fx.ROD : kind == 2 ? Fx.SOUL : Fx.FLAME;
				Fx.ring(l, warn, pos, radius, Math.max(10, (int) (radius * 7)), 0.15);
				Fx.ring(l, warn, pos, radius * prog, Math.max(6, (int) (radius * 4)), 0.15);
			}
			// fallende Bahn
			double h = Math.max(delay, 0) * (kind == 3 ? 3.0 : 1.6);
			if (kind != 0 || delay < 14) {
				var trail = kind == 2 ? Fx.ROD : kind == 3 ? Fx.ROD : kind == 1 ? Fx.FLAME : Fx.FLAME;
				for (int i = 0; i < 3; i++) Fx.p(l, trail, pos.x, pos.y + h + i * 0.7, pos.z, 1, 0.12, 0.12, 0.12, 0.0);
			}
			if (kind == 3) {
				for (double y = 0; y < 40; y += 4) Fx.p(l, Fx.ROD, pos.x, pos.y + y, pos.z, 1, 0.1, 0, 0.1, 0);
			}
			if (delay > 0) return false;

			// Einschlag
			if (fall != null) fall.fade();
			Fx.fx(l, Fx.K_RING, pos.add(0, 0.1, 0), 8, (float) (radius * 1.1), 0.8f);
			if (kind != 3) Fx.fx(l, Fx.K_PILLAR, pos, 10, (float) (radius / 2.7 * 0.5), 0.5f);
			if (kind == 3) Fx.fx(l, Fx.K_PILLAR, pos, 14, (float) (radius / 2.7 * 0.8), 1.0f);
			Fx.p(l, Fx.FLAME, pos.x, pos.y + 0.5, pos.z, 40, radius * 0.5, 0.3, radius * 0.5, 0.15);
			Fx.p(l, Fx.ROD, pos.x, pos.y + 1.0, pos.z, 30, radius * 0.4, 1.0, radius * 0.4, 0.25);
			Fx.p(l, Fx.CRIT, pos.x, pos.y + 1.0, pos.z, 20, radius * 0.4, 0.6, radius * 0.4, 0.4);
			if (radius >= 3) Fx.p(l, Fx.BOOM, pos.x, pos.y + 1, pos.z, 1, 0, 0, 0, 0);
			Fx.ring(l, Fx.ROD, pos, radius, 36, 0.3);
			Fx.sound(l, pos, kind == 3 ? "minecraft:entity.lightning_bolt.thunder" : "minecraft:entity.generic.explode", radius >= 3 ? 2.5f : 1.5f, kind == 1 ? 1.4f : 0.9f);
			float scale = 1.0f + 0.2f * (boss.phase - 1);
			for (ServerPlayer p : Fx.players(l, pos, radius + 4)) {
				double dx = p.getX() - pos.x, dz = p.getZ() - pos.z;
				if (Math.sqrt(dx * dx + dz * dz) <= radius && Math.abs(p.getY() - pos.y) < 4.5) {
					Fx.damage(l, p, boss, dmg * scale, kind >= 2);
					Fx.push(p, new Vec3(dx, 0, dz).normalize().scale(0.5).add(0, 0.5, 0));
					if (kind == 0) Fx.effect(l, p, "minecraft:slowness", 3, 1);
					if (kind == 3) Fx.effect(l, p, "minecraft:blindness", 2, 0);
				}
			}
			return true;
		}
	}

	// ---- Schockwelle (Ring am Boden, ueberspringen!) ----
	static class Shock {
		final Vec3 c; double r = 1; final double speed; final double maxR; final float dmg; final int kind; final float pct;
		final Set<UUID> hit = new HashSet<>();
		FxEntity fx = null;
		Shock(Vec3 c, double speed, double maxR, float dmg, int kind) { this(c, speed, maxR, dmg, kind, 0f); }

		Shock(Vec3 c, double speed, double maxR, float dmg, int kind, float pct) {
			this.c = c; this.speed = speed; this.maxR = maxR; this.dmg = dmg; this.kind = kind; this.pct = pct;
		}

		boolean tick(ServerLevel l, DaemonenlordEntity boss) {
			if (fx == null) Fx.fx(l, Fx.K_RUNE, c.add(0, 0.08, 0), 18, (float) (Math.min(maxR, 16) / 12.0), 1.0f);
			if (fx == null) fx = Fx.fx(l, Fx.K_RING, c.add(0, 0.05, 0), (int) (maxR / speed) + 6, 1.0f, 1.2f);
			r += speed;
			if (!fx.isRemoved()) fx.setScale((float) (r * 1.0667), 1.2f);
			int pts = (int) Math.min(120, Math.max(24, r * 7));
			var main = kind == 1 ? Fx.SOUL : Fx.FLAME;
			Fx.ring(l, main, c, r, pts, 0.25);
			Fx.ring(l, Fx.ROD, c, r - 0.5, pts / 2, 0.6);
			Fx.ring(l, Fx.CRIT, c, r + 0.4, pts / 3, 0.2);
			if ((int) r % 3 == 0) Fx.sound(l, c.add(Math.cos(r) * r, 0, Math.sin(r) * r), "minecraft:block.beacon.power_select", 1.0f, 1.6f);
			float scale = 1.0f + 0.2f * (boss.phase - 1);
			for (ServerPlayer p : Fx.players(l, c, r + 3)) {
				if (hit.contains(p.getUUID())) continue;
				double dx = p.getX() - c.x, dz = p.getZ() - c.z;
				double d = Math.sqrt(dx * dx + dz * dz);
				if (Math.abs(d - r) < 1.7 && p.getY() < c.y + 1.15) {
					hit.add(p.getUUID());
					if (pct > 0) Fx.damagePct(l, p, pct);
					else Fx.damage(l, p, boss, dmg * scale, true);
					Fx.push(p, new Vec3(dx, 0, dz).normalize().scale(0.9).add(0, 0.6, 0));
				}
			}
			return r >= maxR;
		}
	}
}
