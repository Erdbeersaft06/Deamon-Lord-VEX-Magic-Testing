package de.daemonenlord.boss;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.DaemonenlordEntity.Shock;

/** Schwert, das im Boden stecken bleibt und nach 5-15 s eine Schockwelle (35 % max. HP) ausloest. */
final class Sword {
	final Vec3 pos;
	int fall;
	int fuse;
	FxEntity fx;
	final float scale = 1.3f;

	Sword(Vec3 ground, int fallTicks, int fuseTicks) {
		this.pos = ground;
		this.fall = fallTicks;
		this.fuse = fuseTicks;
	}

	/** true = fertig, entfernen */
	boolean tick(ServerLevel l, DaemonenlordEntity boss) {
		if (fx == null) {
			fx = Fx.fx(l, Fx.K_BLADE, pos.add(0, 2.8 * scale + fall * 2.0, 0), fall + fuse + 14, scale, scale);
		}
		if (fall > 0) {
			fall--;
			if (!fx.isRemoved()) fx.setPos(pos.x, pos.y + 2.8 * scale + fall * 2.0, pos.z);
			Fx.p(l, Fx.ROD, pos.x, pos.y + fall * 2.0 + 3, pos.z, 2, 0.15, 0.4, 0.15, 0.0);
			if (fall == 0) {
				Fx.p(l, Fx.CRIT, pos.x, pos.y + 0.3, pos.z, 25, 0.6, 0.2, 0.6, 0.3);
				Fx.p(l, Fx.FLAME, pos.x, pos.y + 0.3, pos.z, 10, 0.4, 0.2, 0.4, 0.05);
				Fx.sound(l, pos, "minecraft:block.anvil.land", 1.6f, 0.7f);
			}
			return false;
		}
		fuse--;
		if (fuse % 8 == 0) Fx.p(l, Fx.FLAME, pos.x, pos.y + 1.0, pos.z, 2, 0.2, 0.8, 0.2, 0.01);
		if (fuse < 40 && fuse % 2 == 0) {
			Fx.ring(l, Fx.ROD, pos, 1.0 + (40 - fuse) * 0.06, 12, 0.2);
			Fx.p(l, Fx.CRIT, pos.x, pos.y + 2.0, pos.z, 3, 0.3, 1.0, 0.3, 0.1);
		}
		if (fuse <= 0) {
			Fx.sound(l, pos, "minecraft:entity.generic.explode", 3.0f, 0.8f);
			Fx.p(l, Fx.BOOM, pos.x, pos.y + 1, pos.z, 1, 0, 0, 0, 0);
			Fx.p(l, Fx.ROD, pos.x, pos.y + 1.5, pos.z, 60, 1.0, 1.5, 1.0, 0.5);
			boss.shocks.add(new Shock(pos, 0.7, 14, 0f, 0, 0.35f));
			if (!fx.isRemoved()) fx.fade();
			return true;
		}
		return false;
	}
}
