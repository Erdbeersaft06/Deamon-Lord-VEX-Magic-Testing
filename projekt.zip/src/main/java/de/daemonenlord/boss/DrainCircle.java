package de.daemonenlord.boss;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

/** Magiekreis des Seelenaderlass: Strahl zum eingefrorenen Spieler, saugt HP und heilt den Boss. */
final class DrainCircle {
	final Vec3 pos;
	final ServerPlayer target;
	final FxEntity seal;
	FxEntity beam;

	DrainCircle(Vec3 pos, ServerPlayer target, FxEntity seal) {
		this.pos = pos;
		this.target = target;
		this.seal = seal;
	}

	void fade() {
		if (seal != null && !seal.isRemoved()) seal.fade();
		if (beam != null && !beam.isRemoved()) beam.fade();
		if (target.level() instanceof ServerLevel sl) {
			Fx.cmd(sl, target.position(), "effect clear " + target.getStringUUID() + " minecraft:slowness");
			Fx.cmd(sl, target.position(), "effect clear " + target.getStringUUID() + " minecraft:jump_boost");
		}
	}
}
