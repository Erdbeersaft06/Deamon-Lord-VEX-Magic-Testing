package de.daemonenlord.boss;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.Random;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.DaemonenlordEntity.Shock;
import de.daemonenlord.boss.DaemonenlordEntity.Strike;

/** Ablauf aller Attacken. t = Tick seit Attackenbeginn. */
final class AttackLogic {
	private AttackLogic() {}

	private static final Random R = new Random();

	static Vec3 core(DaemonenlordEntity b) { return b.position().add(0, 5.6, 0); }

	static Vec3 ground(ServerLevel l, double x, double y, double z) { return new Vec3(x, Fx.groundY(l, x, y, z), z); }

	static Vec3 groundAt(ServerLevel l, ServerPlayer p) { return ground(l, p.getX(), p.getY() + 1, p.getZ()); }

	static void start(DaemonenlordEntity b, ServerLevel l, Attack a) {
		Vec3 c = core(b);
		Fx.sound(l, c, "minecraft:entity.wither.ambient", 4.0f, 0.6f);
		Fx.p(l, Fx.ROD, c, 60, 1.5, 0.3);
		b.lockPos = Vec3.ZERO;
		b.beamSweep = R.nextBoolean() ? 1 : -1;
		switch (a) {
			case HELLFIRE, BLADES, STARFALL, SUMMON, VOID, SLAM -> b.addFollower(l, Fx.K_CORE, new Vec3(0, 6.8, 0), a.duration + 6, 0.35f);
			case BEAM -> b.addFollower(l, Fx.K_CORE, new Vec3(0, 6.8, 0), a.duration + 6, 0.6f);
			case SWORDS, DRAIN, HALO, LINK, HINRICHTUNG -> b.addFollower(l, Fx.K_CORE, new Vec3(0, 6.8, 0), a.duration + 6, 0.5f);
			default -> { }
		}
		if (a == Attack.ULTIMATE) {
			b.ultBaseY = Fx.groundY(l, b.getX(), b.getY(), b.getZ()) + 12;
			b.ultCenter = ground(l, b.getX(), b.getY(), b.getZ());
			b.freezeHover = true;
			b.setInvulnerable(true);
			b.addFollower(l, Fx.K_CORE, new Vec3(0, 6.8, 0), a.duration + 6, 1.0f);
			b.addFollower(l, Fx.K_BLADERING, new Vec3(0, 6.2, 0), a.duration + 6, 1.1f);
			Fx.fx(l, Fx.K_SEAL, b.ultCenter.add(0, 0.05, 0), a.duration + 6, 1.45f, 1.0f);
			for (int k = 0; k < 8; k++) b.pillars.add(Fx.fx(l, Fx.K_PILLAR, b.ultCenter, 60, 0.6f, 0.8f));
			Fx.title(l, c, 110, "DAS JÜNGSTE GERICHT", "der Asche", "white");
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 8.0f, 0.5f);
			Fx.sound(l, c, "minecraft:block.beacon.activate", 8.0f, 0.5f);
		}
	}

	static void tick(DaemonenlordEntity b, ServerLevel l, Attack a, int t, ServerPlayer target) {
		switch (a) {
			case HELLFIRE -> hellfire(b, l, t);
			case BLADES -> blades(b, l, t, target);
			case SHOCKWAVE -> shockwave(b, l, t);
			case STARFALL -> starfall(b, l, t, target);
			case VOID -> voidPull(b, l, t);
			case SUMMON -> summon(b, l, t, target);
			case BEAM -> beam(b, l, t, target);
			case SLAM -> slam(b, l, t, target);
			case SWORDS -> swords(b, l, t, target);
			case DRAIN -> drain(b, l, t);
			case HALO -> halo(b, l, t);
			case LINK -> link(b, l, t);
			case HINRICHTUNG -> execution(b, l, t, target);
			case ULTIMATE -> ultimate(b, l, t);
			case AUSLOESCHUNG -> annihilate(b, l, t);
		}
	}

	private static void charge(DaemonenlordEntity b, ServerLevel l, int t, int upto) {
		if (t < upto && t % 2 == 0) {
			Vec3 c = core(b);
			for (int i = 0; i < 3; i++) {
				double th = R.nextDouble() * Math.PI * 2, ph = Math.acos(2 * R.nextDouble() - 1);
				Vec3 o = new Vec3(Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th));
				Fx.dir(l, Fx.ROD, c.add(o.scale(4.0)), o.scale(-1), 0.35);
			}
		}
	}

	// ---------- 1. Hoellenfeuer-Salve ----------
	private static void hellfire(DaemonenlordEntity b, ServerLevel l, int t) {
		charge(b, l, t, 10);
		if (t >= 10 && t < 80 && (t - 10) % 14 == 0) {
			Vec3 c = core(b);
			Fx.sound(l, c, "minecraft:entity.blaze.shoot", 3.0f, 0.6f);
			for (ServerPlayer p : Fx.players(l, b.position(), 70)) {
				Vec3 vel = p.getDeltaMovement();
				for (int i = 0; i < 3; i++) {
					double ox = i == 0 ? 0 : (R.nextDouble() - 0.5) * 9, oz = i == 0 ? 0 : (R.nextDouble() - 0.5) * 9;
					Vec3 g = ground(l, p.getX() + vel.x * 14 + ox, p.getY() + 1, p.getZ() + vel.z * 14 + oz);
					b.strikes.add(new Strike(g, 22, 3.2f, 11f, 0));
					Fx.line(l, Fx.FLAME, c, g.add(0, 12, 0), 0.9);
				}
			}
		}
	}

	// ---------- 2. Klingenhagel ----------
	private static void blades(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		charge(b, l, t, 6);
		if (t == 6 || t == 36) {
			Fx.sound(l, core(b), "minecraft:item.trident.thunder", 3.0f, 1.2f);
			for (ServerPlayer p : Fx.players(l, b.position(), 70)) {
				Vec3 g = groundAt(l, p);
				int n = t == 6 ? 10 : 7;
				double rad = t == 6 ? 7 : 4.5;
				for (int i = 0; i < n; i++) {
					double ang = Math.PI * 2 * i / n;
					b.strikes.add(new Strike(ground(l, g.x + Math.cos(ang) * rad, g.y + 2, g.z + Math.sin(ang) * rad), 28 + i * 2, 2.3f, 12f, 1));
				}
			}
		}
		if (t == 62) {
			for (ServerPlayer p : Fx.players(l, b.position(), 70)) b.strikes.add(new Strike(groundAt(l, p), 22, 3.4f, 15f, 1));
		}
	}

	// ---------- 3. Seelenfeuer-Welle ----------
	private static void shockwave(DaemonenlordEntity b, ServerLevel l, int t) {
		Vec3 g = ground(l, b.getX(), b.getY(), b.getZ());
		if (t == 0) Fx.fx(l, Fx.K_SEAL, g.add(0, 0.05, 0), 44, 0.45f, 1.0f);
		if (t < 22) {
			Fx.ring(l, Fx.SOUL, g, 3 + t * 0.3, 24, 0.2);
			if (t % 4 == 0) Fx.p(l, Fx.ROD, g.x, g.y + 1, g.z, 10, 1.5, 0.5, 1.5, 0.1);
		}
		if (t == 24) {
			Fx.sound(l, g, "minecraft:entity.warden.sonic_boom", 5.0f, 0.7f);
			b.shocks.add(new Shock(g, 0.9, 28, 14f, 1));
		}
		if (t == 44) b.shocks.add(new Shock(g, 0.9, 28, 14f, 0));
		if (b.phase >= 3 && t == 56) b.shocks.add(new Shock(g, 1.1, 28, 14f, 1));
	}

	// ---------- 4. Sternenfall ----------
	private static void starfall(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		charge(b, l, t, 10);
		if (t >= 10 && t < 85 && t % 3 == 0) {
			Vec3 base;
			if (R.nextInt(100) < 60 && target != null) base = groundAt(l, target);
			else base = ground(l, b.getX() + (R.nextDouble() - 0.5) * 36, b.getY(), b.getZ() + (R.nextDouble() - 0.5) * 36);
			Vec3 pos = ground(l, base.x + (R.nextDouble() - 0.5) * 6, base.y + 2, base.z + (R.nextDouble() - 0.5) * 6);
			b.strikes.add(new Strike(pos, 24, 3f, 9f, 2));
			if (t % 9 == 0) Fx.sound(l, pos, "minecraft:entity.firework_rocket.launch", 2.0f, 0.8f);
		}
	}

	// ---------- 5. Dunkler Sog ----------
	private static void voidPull(DaemonenlordEntity b, ServerLevel l, int t) {
		Vec3 g = ground(l, b.getX(), b.getY(), b.getZ());
		Vec3 c = core(b);
		if (t == 0) Fx.fx(l, Fx.K_SEAL, g.add(0, 0.05, 0), 66, 1.6f, 1.0f);
		if (t < 60) {
			if (t % 10 == 0) Fx.sound(l, c, "minecraft:block.portal.ambient", 4.0f, 0.5f);
			for (int i = 0; i < 10; i++) {
				double ang = R.nextDouble() * Math.PI * 2, rad = 14 + R.nextDouble() * 28;
				Vec3 o = new Vec3(Math.cos(ang) * rad, 2 + R.nextDouble() * 6, Math.sin(ang) * rad);
				Vec3 at = g.add(o);
				Fx.dir(l, Fx.PORTAL, at, new Vec3(-o.x, -o.y + 5, -o.z).scale(0.06), 1.0);
			}
			Fx.ring(l, Fx.SOUL, g, 26 - t * 0.35, 56, 0.2);
			for (ServerPlayer p : Fx.players(l, g, 65)) {
				Vec3 to = new Vec3(g.x - p.getX(), 0, g.z - p.getZ());
				if (to.length() > 3.5) Fx.pull(p, to.normalize().scale(0.24 + 0.004 * t));
			}
		}
		if (t == 62) {
			Fx.sound(l, g, "minecraft:entity.generic.explode", 6.0f, 0.5f);
			Fx.p(l, Fx.BOOM, g.x, g.y + 2, g.z, 3, 2, 1, 2, 0);
			Fx.p(l, Fx.ROD, g.x, g.y + 3, g.z, 200, 3, 3, 3, 0.8);
			float scale = 1.0f + 0.2f * (b.phase - 1);
			for (ServerPlayer p : Fx.players(l, g, 15)) {
				Fx.damage(l, p, b, 26f * scale, true);
				Fx.push(p, new Vec3(p.getX() - g.x, 0, p.getZ() - g.z).normalize().scale(1.2).add(0, 0.8, 0));
			}
			b.shocks.add(new Shock(g, 0.9, 24, 12f, 1));
		}
	}

	// ---------- 6. Schattenbeschwoerung ----------
	static boolean isMinion(Entity e) {
		return e.isAlive() && e.getType().toShortString().equals("wither_skeleton");
	}

	static int minionWant(DaemonenlordEntity b) {
		return switch (b.phase) {
			case 1 -> 5 + R.nextInt(6);    // 5-10
			case 2 -> 11 + R.nextInt(5);   // 11-15
			default -> 20 + R.nextInt(11); // 20-30
		};
	}

	private static void summon(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		if (t == 0) {
			b.lockPos = target == null ? b.position() : groundAt(l, target);
			Fx.fx(l, Fx.K_SEAL, b.lockPos.add(0, 0.05, 0), 34, 0.95f, 1.0f);
		}
		if (t < 22) {
			Vec3 c = b.lockPos;
			Fx.ring(l, Fx.SOUL, c, 14, 60, 0.2);
			for (int i = 0; i < 6; i++) {
				double ang = Math.PI * 2 * i / 6 + t * 0.2;
				Fx.p(l, Fx.SOUL, c.x + Math.cos(ang) * 12, c.y + t * 0.3, c.z + Math.sin(ang) * 12, 4, 0.2, 0.8, 0.2, 0.02);
			}
		}
		if (t == 22) {
			Fx.sound(l, b.position(), "minecraft:entity.evoker.prepare_summon", 5.0f, 0.5f);
			int existing = b.minionCount(l);
			b.minionQueue = Math.max(0, Math.min(minionWant(b), 150 - existing));
			Fx.actionbar(l, b.position(), 90, "☠ " + b.minionQueue + " Schattendiener erwachen ☠", "dark_red");
		}
		if (t >= 22 && b.minionQueue > 0) {
			spawnBatch(b, l, b.lockPos, 5, 15, 6);
		}
	}

	/** Spawnt bis zu perTick Diener aus der Warteschlange im Ring rmin..rmax um center. */
	private static void spawnBatch(DaemonenlordEntity b, ServerLevel l, Vec3 center, double rmin, double rmax, int perTick) {
		if (b.minionQueue <= 0) return;
		int n = Math.min(perTick, b.minionQueue);
		for (int i = 0; i < n; i++) {
			double ang = R.nextDouble() * Math.PI * 2, rad = rmin + R.nextDouble() * (rmax - rmin);
			Vec3 g = ground(l, center.x + Math.cos(ang) * rad, center.y + 3, center.z + Math.sin(ang) * rad);
			Fx.cmd(l, g, String.format(Locale.ROOT,
					"summon minecraft:wither_skeleton %.2f %.2f %.2f {Tags:[\"%s\",\"dl_new\"],PersistenceRequired:1b}",
					g.x, g.y, g.z, Fx.MINION_TAG));
			Fx.fx(l, Fx.K_RING, g.add(0, 0.1, 0), 10, 1.2f, 0.8f);
		}
		b.minionQueue -= n;
		if (b.minionQueue == 0) buffMinions(l, b);
	}

	/** Mehr Leben, mehr Schaden, Netherit-Schwert, auffaelliger Name Tag. */
	private static void buffMinions(ServerLevel l, DaemonenlordEntity b) {
		Vec3 at = b.position();
		String as = "execute as @e[tag=dl_new] run ";
		Fx.cmd(l, at, as + "attribute @s minecraft:max_health base set 30");
		Fx.cmd(l, at, as + "attribute @s minecraft:attack_damage base set 6");
		Fx.cmd(l, at, as + "attribute @s minecraft:armor base set 2");
		Fx.cmd(l, at, as + "attribute @s minecraft:movement_speed base set 0.3");
		Fx.cmd(l, at, as + "item replace entity @s weapon.mainhand with minecraft:netherite_sword");
		Fx.cmd(l, at, as + "data merge entity @s {Health:30f,CustomNameVisible:1b,Glowing:1b}");
		Fx.cmd(l, at, as + "data merge entity @s {CustomName:{text:\"☠ Schattendiener ☠\",color:\"dark_red\",bold:true}}");
		Fx.cmd(l, at, "effect give @e[tag=dl_new] minecraft:speed 99999 0 true");
		Fx.cmd(l, at, "tag @e[tag=dl_new] remove dl_new");
	}

	// ---------- 7. Strahl des Urteils (kurz, duenn, 30 Bloecke) ----------
	private static final double BEAM_LEN = 30.0;

	private static void beam(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		Vec3 c = core(b);
		if (t < 30) {
			if (target != null) b.beamDir = target.getEyePosition().subtract(c).normalize();
			charge(b, l, t, 30);
			if (t % 4 == 0) {
				Fx.line(l, Fx.CRIT, c, c.add(b.beamDir.scale(BEAM_LEN)), 2.5);
				Fx.p(l, Fx.ROD, c, 6, 0.5, 0.1);
			}
			if (t == 12) Fx.sound(l, c, "minecraft:block.beacon.ambient", 5.0f, 0.5f);
		} else if (t < 82) {
			if (t == 30) {
				Fx.sound(l, c, "minecraft:entity.warden.sonic_boom", 6.0f, 0.5f);
				b.beamFx = Fx.fx(l, Fx.K_BEAM, c, 56, 1.6f, (float) BEAM_LEN);
			}
			double ang = Math.toRadians(1.3 * b.beamSweep);
			double cs = Math.cos(ang), sn = Math.sin(ang);
			b.beamDir = new Vec3(b.beamDir.x * cs - b.beamDir.z * sn, b.beamDir.y * 0.995 - 0.002, b.beamDir.x * sn + b.beamDir.z * cs).normalize();
			Vec3 end = c.add(b.beamDir.scale(BEAM_LEN));
			if (b.beamFx != null && !b.beamFx.isRemoved()) {
				b.beamFx.setPos(c.x, c.y, c.z);
				b.beamFx.setAim(b.beamDir);
				b.beamFx.setScale(1.6f, (float) BEAM_LEN);
			}
			if (t % 3 == 0) Fx.line(l, Fx.ROD, c, end, 2.0);
			if (t % 4 == 0) {
				float scale = 1.0f + 0.2f * (b.phase - 1);
				for (ServerPlayer p : Fx.players(l, c, BEAM_LEN + 5)) {
					Vec3 q = p.position().add(0, 1, 0).subtract(c);
					double proj = Math.max(0, Math.min(BEAM_LEN, q.dot(b.beamDir)));
					double dist = q.subtract(b.beamDir.scale(proj)).length();
					if (dist < 1.4) Fx.damage(l, p, b, 6f * scale, true);
				}
				Fx.sound(l, c.add(b.beamDir.scale(15)), "minecraft:entity.lightning_bolt.thunder", 1.0f, 1.8f);
			}
			Vec3 gp = ground(l, end.x, end.y + 10, end.z);
			if (t % 2 == 0) Fx.p(l, Fx.SPARK, gp.x, gp.y + 0.5, gp.z, 5, 0.5, 0.3, 0.5, 0.3);
		}
	}

	// ---------- 8. Himmelsbruch ----------
	private static void slam(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		b.freezeHover = true;
		if (t < 30) {
			b.setDeltaMovement(0, 0.55, 0);
			if (t % 3 == 0) Fx.p(l, Fx.ROD, b.getX(), b.getY() + 1, b.getZ(), 6, 1.5, 0.2, 1.5, 0.1);
			if (target != null) b.lockPos = groundAt(l, target);
			Fx.ring(l, Fx.FLAME, b.lockPos, 9 * (t / 30.0), 24, 0.2);
		} else if (t < 40) {
			if (t == 30) Fx.fx(l, Fx.K_SEAL, b.lockPos.add(0, 0.05, 0), 44, 0.6f, 1.0f);
			b.setDeltaMovement(0, 0, 0);
			Fx.ring(l, Fx.ROD, b.lockPos, 9, 40, 0.2);
			Fx.ring(l, Fx.FLAME, b.lockPos, 9, 40, 0.2);
			if (t == 30) Fx.sound(l, b.position(), "minecraft:entity.ender_dragon.growl", 5.0f, 1.0f);
		} else if (t == 40) {
			b.setPos(b.lockPos.x, b.lockPos.y + 16, b.lockPos.z);
			b.setDeltaMovement(0, -2.3, 0);
		} else if (t < 70) {
			b.setDeltaMovement(0, -2.3, 0);
			Fx.p(l, Fx.FLAME, b.getX(), b.getY() + 3, b.getZ(), 15, 1.2, 2, 1.2, 0.05);
			Fx.p(l, Fx.ROD, b.getX(), b.getY() + 6, b.getZ(), 6, 0.6, 3, 0.6, 0.0);
			if (b.getY() <= b.lockPos.y + 3.2 || t == 69) {
				Vec3 g = b.lockPos;
				b.setDeltaMovement(0, 0, 0);
				b.setPos(g.x, g.y + 3.0, g.z);
				Fx.sound(l, g, "minecraft:entity.generic.explode", 8.0f, 0.5f);
				Fx.sound(l, g, "minecraft:entity.iron_golem.death", 8.0f, 0.5f);
				Fx.p(l, Fx.BOOM, g.x, g.y + 2, g.z, 4, 3, 0.5, 3, 0);
				Fx.p(l, Fx.ROD, g.x, g.y + 2, g.z, 250, 4, 2, 4, 0.9);
				Fx.p(l, Fx.FLAME, g.x, g.y + 1, g.z, 200, 5, 0.5, 5, 0.3);
				float scale = 1.0f + 0.2f * (b.phase - 1);
				for (ServerPlayer p : Fx.players(l, g, 11)) {
					Fx.damage(l, p, b, 22f * scale, false);
					Fx.push(p, new Vec3(p.getX() - g.x, 0, p.getZ() - g.z).normalize().scale(1.1).add(0, 0.9, 0));
				}
				b.shocks.add(new Shock(g, 1.0, 30, 14f, 0));
				b.atkTick = Attack.SLAM.duration;
			}
		}
	}

	// ---------- 10. Schwertgericht ----------
	private static void swords(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		Vec3 up = b.position().add(0, 13, 0);
		if (t == 0) {
			Fx.fx(l, Fx.K_SEAL, up, 88, 0.95f, 1.0f);
			Fx.sound(l, up, "minecraft:block.beacon.activate", 6.0f, 0.6f);
		}
		if (t < 85 && t % 2 == 0) {
			Fx.ring(l, Fx.ROD, up, 14, 48, 0);
			Fx.ring(l, Fx.FLAME, up, 9, 32, 0);
		}
		if (t >= 8 && t <= 75 && t % 3 == 0 && b.swords.size() < 60) {
			int n = 1 + R.nextInt(2);
			for (int i = 0; i < n; i++) {
				Vec3 base = (R.nextInt(100) < 55 && target != null) ? groundAt(l, target)
						: ground(l, b.getX() + (R.nextDouble() - 0.5) * 50, b.getY(), b.getZ() + (R.nextDouble() - 0.5) * 50);
				Vec3 pos = ground(l, base.x + (R.nextDouble() - 0.5) * 10, base.y + 2, base.z + (R.nextDouble() - 0.5) * 10);
				b.swords.add(new Sword(pos, 14 + R.nextInt(8), 100 + R.nextInt(201))); // 5-15 s Zuendschnur
			}
			Fx.sound(l, up, "minecraft:item.trident.throw", 3.0f, 0.7f);
		}
	}

	// ---------- 11. Seelenaderlass ----------
	private static void drain(DaemonenlordEntity b, ServerLevel l, int t) {
		if (t == 0) {
			Fx.sound(l, b.position(), "minecraft:entity.warden.sonic_boom", 6.0f, 0.4f);
			for (ServerPlayer p : Fx.players(l, b.position(), 75)) {
				Fx.effect(l, p, "minecraft:slowness", 10, 255);
				b.frozen.put(p.getUUID(), p.position());
				Fx.fx(l, Fx.K_SEAL, p.position().add(0, 0.05, 0), 170, 0.18f, 1.0f);
				Fx.p(l, Fx.SOUL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 1.0, 0.6, 0.05);
			}
			Fx.title(l, b.position(), 90, "SEELENADERLASS", "Du bist gefangen – der Richter ist unverwundbar", "dark_red");
			b.setInvulnerable(true);
		}
		if (t == 10) {
			for (ServerPlayer p : Fx.players(l, b.position(), 75)) {
				int n = 8 + R.nextInt(5);
				double off = R.nextDouble() * Math.PI * 2;
				for (int i = 0; i < n; i++) {
					double ang = off + Math.PI * 2 * i / n;
					double dist = 25 + R.nextDouble() * 10; // 25-35 Bloecke
					Vec3 pos = ground(l, p.getX() + Math.cos(ang) * dist, p.getY() + 3, p.getZ() + Math.sin(ang) * dist);
					FxEntity seal = Fx.fx(l, Fx.K_SEAL, pos.add(0, 0.05, 0), 175, 0.3f, 1.0f);
					b.drains.add(new DrainCircle(pos, p, seal));
					Fx.p(l, Fx.SOUL, pos.x, pos.y + 1, pos.z, 30, 1, 1.5, 1, 0.05);
				}
			}
			Fx.sound(l, b.position(), "minecraft:block.beacon.activate", 6.0f, 0.4f);
		}
		if (t >= 1 && t % 2 == 0) {
			for (ServerPlayer p : Fx.players(l, b.position(), 90)) {
				Vec3 home = b.frozen.get(p.getUUID());
				if (home != null && p.position().distanceToSqr(home) > 0.25) {
					Fx.cmd(l, p.position(), String.format(Locale.ROOT, "tp %s %.2f %.2f %.2f", p.getStringUUID(), home.x, home.y, home.z));
				}
			}
		}
		if (t >= 30 && t < 172) {
			for (DrainCircle d : b.drains) {
				if (!d.target.isAlive()) continue;
				Vec3 start = d.pos.add(0, 1.5, 0);
				Vec3 end = d.target.getBoundingBox().getCenter();
				Vec3 dir = end.subtract(start);
				double len = dir.length();
				if (len < 0.5) continue;
				float sy = (float) len;
				if (d.beam == null || d.beam.isRemoved()) {
					d.beam = Fx.fx(l, Fx.K_BEAM, start, 145, 0.9f, sy);
				}
				d.beam.setPos(start.x, start.y, start.z);
				d.beam.setAim(dir);
				d.beam.setScale(0.9f, sy);
				if (t % 4 == 0) Fx.line(l, Fx.SOUL, start, end, 2.2);
				if (t % 20 == 0) {
					float drained = 0.2f;
					Fx.damage(l, d.target, b, drained, true);
					b.heal(drained / Math.max(1f, d.target.getMaxHealth()) * 0.05f * b.getMaxHealth());
					Fx.p(l, Fx.TOTEM, b.getX(), b.getY() + 5.6, b.getZ(), 2, 0.8, 0.8, 0.8, 0.2);
				}
			}
		}
		if (t == 172) {
			for (DrainCircle d : b.drains) d.fade();
			b.drains.clear();
		}
	}

	// ---------- 12. Strahlenkranz (Schein des Bosses) ----------
	private static void halo(DaemonenlordEntity b, ServerLevel l, int t) {
		b.freezeHover = true;
		b.setDeltaMovement(b.getDeltaMovement().scale(0.8));
		Vec3 gr = ground(l, b.getX(), b.getY(), b.getZ());
		Vec3 g = gr.add(0, 0.6, 0);
		int beams = 8;
		if (t == 0) {
			Fx.fx(l, Fx.K_SEAL, gr.add(0, 0.05, 0), 124, 0.6f, 1.0f);
			Fx.sound(l, b.position(), "minecraft:block.beacon.power_select", 6.0f, 0.5f);
		}
		if (t < 20 && t % 4 == 0) {
			for (int i = 0; i < beams; i++) {
				double a = Math.PI * 2 * i / beams;
				Fx.line(l, Fx.CRIT, g, g.add(Math.cos(a) * 22, 0, Math.sin(a) * 22), 2.0);
			}
		}
		if (t == 20) {
			Fx.sound(l, b.position(), "minecraft:entity.warden.sonic_boom", 6.0f, 0.6f);
			for (int i = 0; i < beams; i++) b.haloBeams.add(Fx.fx(l, Fx.K_BEAM, g, 100, 1.2f, 22f));
		}
		if (t >= 20 && t < 118) {
			double base = (t - 20) * Math.toRadians(1.8) * (b.beamSweep >= 0 ? 1 : -1);
			for (int i = 0; i < beams; i++) {
				double a = base + Math.PI * 2 * i / beams;
				Vec3 dir = new Vec3(Math.cos(a), 0, Math.sin(a));
				if (i < b.haloBeams.size() && !b.haloBeams.get(i).isRemoved()) {
					b.haloBeams.get(i).setPos(g.x, g.y, g.z);
					b.haloBeams.get(i).setAim(dir);
				}
				if (t % 2 == 0) Fx.line(l, Fx.ROD, g, g.add(dir.scale(22)), 1.8);
				if (t % 6 == 0) {
					for (ServerPlayer p : Fx.players(l, g, 26)) {
						double rx = p.getX() - g.x, rz = p.getZ() - g.z;
						double proj = rx * dir.x + rz * dir.z;
						double side = Math.abs(rx * dir.z - rz * dir.x);
						if (proj > 0 && proj < 22 && side < 1.2 && p.getY() < gr.y + 1.1) { // ueberspringen moeglich
							Fx.damage(l, p, b, 13f, false);
							Fx.push(p, new Vec3(-dir.z, 0.4, dir.x).scale(0.7));
						}
					}
				}
			}
		}
	}

	// ---------- 13. Seelenbund (nur letzte 15 %) ----------
	private static void link(DaemonenlordEntity b, ServerLevel l, int t) {
		b.freezeHover = true;
		b.setDeltaMovement(0, 0, 0);
		Vec3 c = core(b);
		if (t == 0) {
			Fx.sound(l, c, "minecraft:entity.evoker.prepare_summon", 8.0f, 0.4f);
			Fx.title(l, c, 90, "SEELENBUND", "Tötet die Diener – bevor er sich heilt!", "dark_red");
			b.minionQueue = Math.max(0, Math.min(60 + R.nextInt(61), 150 - b.minionCount(l)));
			Fx.actionbar(l, c, 90, "☠ " + b.minionQueue + " Schattendiener werden beschworen ☠", "dark_red");
		}
		spawnBatch(b, l, b.position(), 6, 28, 8);
		List<Entity> ms = new ArrayList<>();
		for (Entity e : l.getEntities((Entity) null, b.getBoundingBox().inflate(50), AttackLogic::isMinion)) {
			if (e.position().distanceTo(b.position()) <= 50) ms.add(e);
		}
		Set<UUID> present = new HashSet<>();
		int lines = 0;
		for (Entity m : ms) {
			if (present.size() >= 130) break;
			present.add(m.getUUID());
			Vec3 end = m.getBoundingBox().getCenter();
			Vec3 dir = end.subtract(c);
			double len = dir.length();
			if (len < 0.5) continue;
			float sy = (float) len;
			FxEntity beam = b.linkBeams.get(m.getUUID());
			if (beam == null || beam.isRemoved()) {
				beam = Fx.fx(l, Fx.K_BEAM, c, 115, 0.7f, sy);
				b.linkBeams.put(m.getUUID(), beam);
			}
			beam.setPos(c.x, c.y, c.z);
			beam.setAim(dir);
			beam.setScale(0.7f, sy);
			if (t % 3 == 0 && lines++ < 14) Fx.line(l, Fx.SOUL, c, end, 2.4);
		}
		java.util.Iterator<java.util.Map.Entry<UUID, FxEntity>> it = b.linkBeams.entrySet().iterator();
		while (it.hasNext()) {
			var e = it.next();
			if (!present.contains(e.getKey())) {
				if (!e.getValue().isRemoved()) e.getValue().fade();
				it.remove();
			}
		}
		if (t == Attack.LINK.duration - 3) {
			int count = present.size();
			float heal = count * 0.005f * b.getMaxHealth();
			b.heal(heal);
			Fx.actionbar(l, c, 90, "Seelenbund: " + count + " Diener  →  +" + String.format(Locale.ROOT, "%.1f", count * 0.5f) + " % Leben", "dark_red");
			Fx.p(l, Fx.TOTEM, c, 150, 3, 0.7);
			Fx.sound(l, c, "minecraft:entity.player.levelup", 6.0f, 0.5f);
		}
	}

	// ---------- 9. ULTIMATE: Das Juengste Gericht der Asche ----------
	private static final double ULT_R = 22;
	private static final int ULT_BOOM = 216;
	/** {Tick, Stufe} der Lichttuer (Stufe 0 = ausblenden). */
	private static final int[][] DOOR = {
			{100, 1}, {104, 2}, {108, 3}, {112, 2}, {116, 1}, {120, 0},
			{130, 2}, {134, 3}, {138, 4}, {142, 5}, {146, 3}, {150, 2}, {154, 0},
			{162, 3}, {166, 4}, {170, 5}, {174, 6}, {178, 7}, {182, 5}, {186, 3}, {190, 0},
			{196, 2}, {199, 3}, {202, 4}, {205, 5}, {208, 6}, {211, 7}, {214, 8}};

	private static void ultimate(DaemonenlordEntity b, ServerLevel l, int t) {
		Vec3 cc = b.ultCenter;
		Vec3 c = core(b);
		b.freezeHover = true;
		b.setDeltaMovement(0, 0, 0);
		b.setInvulnerable(true);
		if (t < ULT_BOOM) DomainLogic.hold(l, cc, ULT_R, b.ultPlayers);

		// Waage ueber dem Boss
		if (t == 12) {
			b.ultScale = Fx.fx(l, Fx.K_SCALE, cc.add(0, 14, 0), ULT_BOOM - 12 + 6, 0.5f, 0.5f);
			Fx.sound(l, c, "minecraft:block.beacon.activate", 8.0f, 0.4f);
		}
		if (b.ultScale != null && !b.ultScale.isRemoved() && t >= 12 && t < 60) {
			double x = (t - 12) / 48.0;
			float s = (float) (0.5 + 4.5 * x * x * (3 - 2 * x));
			b.ultScale.setScale(s, s);
		}
		// rotierende Lichtsaeulen am Rand
		if (t < 60) {
			for (int k = 0; k < b.pillars.size(); k++) {
				double ang = Math.PI * 2 * k / 8 + t * 0.03;
				var pf = b.pillars.get(k);
				if (!pf.isRemoved()) pf.setPos(cc.x + Math.cos(ang) * 22, cc.y, cc.z + Math.sin(ang) * 22);
			}
			if (t % 12 == 0) Fx.sound(l, c, "minecraft:block.beacon.power_select", 6.0f, 0.5f + t * 0.01f);
		}
		// Urteile auf die Spieler
		if (t == 30 || t == 60) {
			for (ServerPlayer p : Fx.players(l, cc, 60)) {
				Vec3 g = groundAt(l, p);
				for (int i = 0; i < 4; i++) {
					double ang = Math.PI * 2 * i / 4;
					b.strikes.add(new Strike(ground(l, g.x + Math.cos(ang) * 5, g.y + 2, g.z + Math.sin(ang) * 5), 25 + i * 3, 2.5f, 30f, 1));
				}
			}
		}
		if (t >= 80 && t < 190 && t % 18 == 0) {
			for (ServerPlayer p : Fx.players(l, cc, 60)) b.strikes.add(new Strike(groundAt(l, p), 16, 3f, 40f, 3));
		}
		if (t == 90) Fx.title(l, c, 110, "DAS LICHT ÖFFNET SICH", "Es gibt kein Entkommen", "gold");
		// Lichttuer
		for (int[] d : DOOR) if (d[0] == t) Fx.door(l, c, 110, d[1]);
		if (t == ULT_BOOM) {
			Fx.flash(l, c, 110, 60);
			Fx.sound(l, c, "minecraft:entity.generic.explode", 12.0f, 0.5f);
			Fx.sound(l, c, "minecraft:entity.lightning_bolt.thunder", 12.0f, 0.5f);
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 10.0f, 0.4f);
			Fx.fx(l, Fx.K_RING, cc.add(0, 0.2, 0), 16, (float) (ULT_R * 1.07), 1.0f);
			Fx.fx(l, Fx.K_PILLAR, cc, 22, 3.5f, 3.0f);
			for (ServerPlayer p : Fx.players(l, cc, ULT_R + 3)) {
				Fx.damage(l, p, b, 30f, true);
				Fx.damagePct(l, p, 0.65f);
			}
		}
		if (t == ULT_BOOM + 22) {
			Fx.title(l, c, 110, "DIE ASCHE LEGT SICH", "Der Richter ist erschöpft – schlagt zu!", "gold");
			b.endAttack();
			b.stun = 110;
		}
	}

	// ---------- 15. Pforte der Ausloeschung ----------
	static final class Flight {
		FxEntity fx; Vec3 a, b; int t0, dur;
	}

	static final class Ann {
		Vec3 center;
		final List<FxEntity> circles = new ArrayList<>();
		final List<Flight> flights = new ArrayList<>();
		FxEntity seal, beam;
		void clear() {
			if (beam != null && !beam.isRemoved()) beam.fade();
			for (FxEntity f : circles) if (f != null && !f.isRemoved()) f.fade();
			for (Flight f : flights) if (f.fx != null && !f.fx.isRemoved()) f.fx.fade();
			if (seal != null && !seal.isRemoved()) seal.fade();
			circles.clear(); flights.clear(); seal = null;
		}
	}

	private static final double[] ANN_R = {60, 48, 36, 34, 32, 26, 24, 22, 20, 15, 14, 13, 12, 11};
	private static final double ANN_ZONE = 60;
	private static final int ANN_KILL = 284;

	private static void annihilate(DaemonenlordEntity b, ServerLevel l, int t) {
		b.freezeHover = true;
		b.setDeltaMovement(0, 0, 0);
		Vec3 c = core(b);
		Ann a = b.ann;
		if (t == 0) {
			a = b.ann = new Ann();
			a.center = ground(l, b.getX(), b.getY(), b.getZ());
			a.seal = Fx.fx(l, Fx.K_SEAL, a.center.add(0, 0.05, 0), ANN_KILL + 40, 0.1f, 1.0f);
			Fx.title(l, c, 130, "PFORTE DER AUSLÖSCHUNG", "Verlasst den Bereich – oder sterbt", "dark_purple");
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 10.0f, 0.4f);
			Fx.sound(l, c, "minecraft:block.beacon.activate", 10.0f, 0.4f);
		}
		if (a == null) return;
		Vec3 g = a.center;
		// Bodensiegel zeichnet die Gefahrenzone
		if (a.seal != null && !a.seal.isRemoved() && t < 60) {
			double x = t / 60.0;
			float s = (float) (ANN_ZONE / 15.3 * x * x * (3 - 2 * x));
			a.seal.setScale(Math.max(0.1f, s), 1.0f);
		}
		// Kreise: der Boss zeichnet sie, Runen fliegen in den Himmel
		for (int j = 0; j < ANN_R.length; j++) {
			int t0 = 20 + j * 16;
			double h = 80.0 - j * (55.0 / (ANN_R.length - 1));
			Vec3 cp = g.add(0, h, 0);
			if (t == t0) {
				FxEntity f = Fx.fx(l, j < 6 ? 11 : Fx.K_RUNE, cp, ANN_KILL - t0 + 40, 0.05f, 1.0f);
				f.setTint(8);
				f.setSpin((j % 2 == 0 ? 1 : -1) * (0.6f + R.nextFloat() * 1.0f));
				a.circles.add(f);
				Fx.sound(l, c, "minecraft:block.enchantment_table.use", 6.0f, 0.5f + j * 0.04f);
			}
			if (t >= t0 && t < t0 + 34 && j < a.circles.size()) {
				FxEntity f = a.circles.get(j);
				double x = Math.min(1.0, (t - t0) / 30.0);
				float s = (float) (ANN_R[j] / (j < 6 ? 5.94 : 12.25) * x * x * (3 - 2 * x));
				if (!f.isRemoved()) f.setScale(Math.max(0.05f, s), 1.0f);
			}
			if (t >= t0 && t < t0 + 24 && t % 3 == 0) {
				Flight fl = new Flight();
				double ang = R.nextDouble() * Math.PI * 2;
				fl.a = c.add(Math.cos(ang) * 1.5, 0.5, Math.sin(ang) * 1.5);
				fl.b = cp.add(Math.cos(ang) * ANN_R[j] * 0.9, 0, Math.sin(ang) * ANN_R[j] * 0.9);
				fl.t0 = t; fl.dur = 30;
				fl.fx = Fx.fx(l, Fx.K_RING, fl.a, fl.dur + 4, 0.6f, 1.0f);
				fl.fx.setTint(8);
				a.flights.add(fl);
			}
		}
		java.util.Iterator<Flight> it = a.flights.iterator();
		while (it.hasNext()) {
			Flight fl = it.next();
			double x = (double) (t - fl.t0) / fl.dur;
			if (x >= 1.0 || fl.fx.isRemoved()) { if (!fl.fx.isRemoved()) fl.fx.fade(); it.remove(); continue; }
			double e = x * x * (3 - 2 * x);
			Vec3 q = fl.a.lerp(fl.b, e).add(0, Math.sin(x * Math.PI) * 6, 0);
			fl.fx.setPos(q.x, q.y, q.z);
		}
		if (t > 20 && t < ANN_KILL && t % 40 == 0) {
			Fx.actionbar(l, g, 150, "☠ Verlasst die Zone – Auslöschung in " + (ANN_KILL - t) / 20 + " s ☠", "light_purple");
		}
		// grellweisser Strahl praescht von oben durch die Mitte in den Boden
		int tb = ANN_KILL - 14;
		if (t == tb) {
			a.beam = Fx.fx(l, Fx.K_BEAM, g.add(0, 82, 0), 40, 14f, 1.0f);
			a.beam.setTint(7);
			a.beam.setAim(new Vec3(0, -1, 0));
			Fx.sound(l, g.add(0, 40, 0), "minecraft:entity.warden.sonic_boom", 12.0f, 0.5f);
			Fx.sound(l, g, "minecraft:block.beacon.power_select", 12.0f, 2.0f);
		}
		if (t >= tb && t < ANN_KILL && a.beam != null && !a.beam.isRemoved()) {
			double x = (t - tb + 1) / 14.0;
			a.beam.setScale(14f, (float) (82.0 * x * x));
		}
		if (t == ANN_KILL) {
			Fx.flash(l, g, 160, 50);
			Fx.fx(l, Fx.K_RING, g.add(0, 0.2, 0), 14, 12.0f, 1.0f);
			FxEntity pil = Fx.fx(l, Fx.K_PILLAR, g, 24, 6f, 4f);
			pil.setTint(7);
			Fx.sound(l, c, "minecraft:entity.generic.explode", 12.0f, 0.6f);
			Fx.sound(l, c, "minecraft:entity.firework_rocket.twinkle", 12.0f, 0.5f);
			Fx.sound(l, c, "minecraft:ui.toast.challenge_complete", 12.0f, 0.6f);
			for (ServerPlayer p : Fx.players(l, g, 400)) {
				double dx = p.getX() - g.x, dz = p.getZ() - g.z;
				if (Math.sqrt(dx * dx + dz * dz) <= ANN_ZONE && !p.isCreative()) {
					// toedlicher Magieschaden: ein Totem der Unsterblichkeit kann ihn verhindern
					p.setAbsorptionAmount(0.0f);
					Fx.resetIFrames(p);
					Fx.damageRaw(l, p, 100000f);
				}
			}
		}
		if (t == ANN_KILL + 10) Fx.rainbow(l, g, 160, 70);
		if (t == ANN_KILL + 30) {
			Fx.title(l, c, 120, "DIE PFORTE SCHLIESST SICH", "Der Richter ist erschöpft", "gold");
			b.endAttack();
			b.stun = 150;
		}
	}

	// ---------- 14. Arkane Hinrichtung ----------
	static final class Exec {
		ServerPlayer target;
		Vec3 home, center;
		final List<Vec3> pos = new ArrayList<>();
		final List<FxEntity> runes = new ArrayList<>();
		final List<FxEntity> orbs = new ArrayList<>();
		final List<FxEntity> shots = new ArrayList<>();
		int[] fire, travel;
		void clear() {
			for (FxEntity f : runes) if (f != null && !f.isRemoved()) f.fade();
			for (FxEntity f : orbs) if (f != null && !f.isRemoved()) f.fade();
			for (FxEntity f : shots) if (f != null && !f.isRemoved()) f.fade();
			runes.clear(); orbs.clear(); shots.clear();
		}
	}

	private static final int EXEC_HIT = 96;

	private static void execution(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer tgt) {
		b.freezeHover = true;
		b.setDeltaMovement(0, 0, 0);
		Exec e = b.exec;
		if (t == 0) {
			if (tgt == null) { b.endAttack(); return; }
			e = b.exec = new Exec();
			e.target = tgt;
			e.home = tgt.position();
			e.center = e.home.add(0, 7.0, 0);
			Fx.effect(l, tgt, "minecraft:slowness", 10, 255);
			Fx.title(l, tgt.position(), 80, "ARKANE HINRICHTUNG", "Du wirst emporgehoben …", "dark_purple");
			Fx.sound(l, tgt.position(), "minecraft:block.beacon.activate", 6.0f, 0.5f);
		}
		if (e == null || e.target == null) return;
		ServerPlayer p = e.target;
		if (!p.isAlive()) { b.endAttack(); return; }
		if (t <= EXEC_HIT) {
			double x = Math.min(1.0, t / 30.0);
			double lift = 6.0 * x * x * (3 - 2 * x);
			Vec3 hold = e.home.add(0, lift, 0);
			Fx.cmd(l, hold, String.format(Locale.ROOT, "tp %s %.2f %.2f %.2f", p.getStringUUID(), hold.x, hold.y, hold.z));
		}
		if (t == 30) {
			int n = 8;
			e.fire = new int[n];
			e.travel = new int[n];
			for (int i = 0; i < n; i++) {
				double ang = Math.PI * 2 * i / n + R.nextDouble() * 0.5;
				double dist = 6 + R.nextDouble() * 10;
				double h = -1.0 + R.nextDouble() * 7.0;
				double px = e.center.x + Math.cos(ang) * dist, pz = e.center.z + Math.sin(ang) * dist;
				double py = Math.max(e.center.y + h, Fx.groundY(l, px, e.center.y, pz) + 2.5);
				Vec3 pos = new Vec3(px, py, pz);
				e.pos.add(pos);
				FxEntity rune = Fx.fx(l, Fx.K_RUNE_AIM, pos, 80, 0.28f, 1.0f);
				rune.setTint(3 + i % 4);
				rune.setAim(e.center.subtract(pos));
				e.runes.add(rune);
				e.orbs.add(Fx.fx(l, Fx.K_CORE, pos, 80, 0.15f, 0.15f));
				int tr = (int) Math.ceil(e.center.distanceTo(pos) / 1.5);
				e.travel[i] = tr;
				e.fire[i] = EXEC_HIT - tr;
			}
			Fx.sound(l, e.center, "minecraft:block.beacon.power_select", 6.0f, 0.6f);
		}
		if (t > 30 && t < EXEC_HIT && !e.orbs.isEmpty()) {
			float s = 0.15f + 0.25f * Math.min(1f, (t - 30) / 40f);
			for (FxEntity o : e.orbs) if (!o.isRemoved()) o.setScale(s, s);
		}
		if (e.fire != null) {
			for (int i = 0; i < e.fire.length; i++) {
				if (t == e.fire[i]) {
					e.shots.add(Fx.fx(l, Fx.K_CORE, e.pos.get(i), e.travel[i] + 6, 0.4f, 0.4f));
					Fx.sound(l, e.pos.get(i), "minecraft:entity.blaze.shoot", 2.0f, 0.6f);
				}
				if (t > e.fire[i] && t <= EXEC_HIT) {
					double f = (double) (t - e.fire[i]) / e.travel[i];
					Vec3 q = e.pos.get(i).lerp(e.center, Math.min(1.0, f));
					int si = e.shots.size() - e.fire.length + i; // Reihenfolge der Schuesse
					FxEntity shot = shotFor(e, i);
					if (shot != null && !shot.isRemoved()) shot.setPos(q.x, q.y, q.z);
				}
			}
		}
		if (t == EXEC_HIT) {
			Fx.damagePct(l, p, 0.5f);
			Fx.sound(l, e.center, "minecraft:entity.generic.explode", 8.0f, 0.7f);
			Fx.sound(l, e.center, "minecraft:entity.lightning_bolt.thunder", 6.0f, 1.2f);
			Fx.fx(l, Fx.K_RING, e.center, 14, 3.0f, 1.0f);
			Fx.fx(l, Fx.K_PILLAR, e.center.add(0, -6.5, 0), 12, 0.6f, 0.5f);
			Fx.cmd(l, p.position(), "effect clear " + p.getStringUUID() + " minecraft:slowness");
			Fx.effect(l, p, "minecraft:slow_falling", 6, 0);
			for (FxEntity f : e.shots) if (!f.isRemoved()) f.fade();
			for (FxEntity f : e.runes) if (!f.isRemoved()) f.fade();
			for (FxEntity f : e.orbs) if (!f.isRemoved()) f.fade();
		}
	}

	private static FxEntity shotFor(Exec e, int i) {
		// Schuesse werden in Abschuss-Reihenfolge angelegt -> nach Abschusszeit sortierter Index
		int rank = 0;
		for (int k = 0; k < e.fire.length; k++) if (e.fire[k] < e.fire[i] || (e.fire[k] == e.fire[i] && k < i)) rank++;
		return rank < e.shots.size() ? e.shots.get(rank) : null;
	}
}
