package de.daemonenlord.boss;

import java.util.Locale;
import java.util.Random;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.boss.DaemonenlordEntity.Shock;
import de.daemonenlord.boss.DaemonenlordEntity.Strike;

/** Ablauf aller Attacken. t = Tick seit Attackenbeginn. */
final class AttackLogic {
	private AttackLogic() {}

	private static final Random R = new Random();

	static Vec3 core(DaemonenlordEntity b) { return b.position().add(0, 5.6, 0); }

	static Vec3 ground(ServerLevel l, double x, double y, double z) { return new Vec3(x, Fx.groundY(l, x, y, z), z); }

	static Vec3 groundAt(ServerLevel l, ServerPlayer p) { return ground(l, p.getX(), p.getY() + 1, p.getZ()); }

	static void start(DaemonenlordEntity b, ServerLevel l, Attack a) {
		Vec3 c = core(b);
		Fx.sound(l, c, "minecraft:entity.wither.ambient", 4.0f, 0.6f);
		Fx.p(l, Fx.ROD, c, 60, 1.5, 0.3);
		b.lockPos = Vec3.ZERO;
		b.beamSweep = R.nextBoolean() ? 1 : -1;
		if (a == Attack.ULTIMATE) {
			b.ultBaseY = Fx.groundY(l, b.getX(), b.getY(), b.getZ()) + 12;
			b.ultCenter = ground(l, b.getX(), b.getY(), b.getZ());
			b.freezeHover = true;
			b.setInvulnerable(true);
			Fx.title(l, c, 110, "DAS JÜNGSTE GERICHT", "der Asche", "white");
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 8.0f, 0.5f);
			Fx.sound(l, c, "minecraft:block.beacon.activate", 8.0f, 0.5f);
		}
	}

	static void tick(DaemonenlordEntity b, ServerLevel l, Attack a, int t, ServerPlayer target) {
		switch (a) {
			case HELLFIRE -> hellfire(b, l, t);
			case BLADES -> blades(b, l, t, target);
			case SHOCKWAVE -> shockwave(b, l, t);
			case STARFALL -> starfall(b, l, t, target);
			case VOID -> voidPull(b, l, t);
			case SUMMON -> summon(b, l, t, target);
			case BEAM -> beam(b, l, t, target);
			case SLAM -> slam(b, l, t, target);
			case ULTIMATE -> ultimate(b, l, t);
		}
	}

	private static void charge(DaemonenlordEntity b, ServerLevel l, int t, int upto) {
		if (t < upto && t % 2 == 0) {
			Vec3 c = core(b);
			for (int i = 0; i < 3; i++) {
				double th = R.nextDouble() * Math.PI * 2, ph = Math.acos(2 * R.nextDouble() - 1);
				Vec3 o = new Vec3(Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th));
				Fx.dir(l, Fx.ROD, c.add(o.scale(4.0)), o.scale(-1), 0.35);
			}
		}
	}

	// ---------- 1. Hoellenfeuer-Salve ----------
	private static void hellfire(DaemonenlordEntity b, ServerLevel l, int t) {
		charge(b, l, t, 10);
		if (t >= 10 && t < 80 && (t - 10) % 14 == 0) {
			Vec3 c = core(b);
			Fx.sound(l, c, "minecraft:entity.blaze.shoot", 3.0f, 0.6f);
			for (ServerPlayer p : Fx.players(l, b.position(), 70)) {
				Vec3 vel = p.getDeltaMovement();
				for (int i = 0; i < 3; i++) {
					double ox = i == 0 ? 0 : (R.nextDouble() - 0.5) * 9, oz = i == 0 ? 0 : (R.nextDouble() - 0.5) * 9;
					Vec3 g = ground(l, p.getX() + vel.x * 14 + ox, p.getY() + 1, p.getZ() + vel.z * 14 + oz);
					b.strikes.add(new Strike(g, 22, 3.2f, 11f, 0));
					Fx.line(l, Fx.FLAME, c, g.add(0, 12, 0), 0.9);
				}
			}
		}
	}

	// ---------- 2. Klingenhagel ----------
	private static void blades(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		charge(b, l, t, 6);
		if (t == 6 || t == 36) {
			Fx.sound(l, core(b), "minecraft:item.trident.thunder", 3.0f, 1.2f);
			for (ServerPlayer p : Fx.players(l, b.position(), 70)) {
				Vec3 g = groundAt(l, p);
				int n = t == 6 ? 10 : 7;
				double rad = t == 6 ? 7 : 4.5;
				for (int i = 0; i < n; i++) {
					double ang = Math.PI * 2 * i / n;
					b.strikes.add(new Strike(ground(l, g.x + Math.cos(ang) * rad, g.y + 2, g.z + Math.sin(ang) * rad), 28 + i * 2, 2.3f, 12f, 1));
				}
			}
		}
		if (t == 62) {
			for (ServerPlayer p : Fx.players(l, b.position(), 70)) b.strikes.add(new Strike(groundAt(l, p), 22, 3.4f, 15f, 1));
		}
	}

	// ---------- 3. Seelenfeuer-Welle ----------
	private static void shockwave(DaemonenlordEntity b, ServerLevel l, int t) {
		Vec3 g = ground(l, b.getX(), b.getY(), b.getZ());
		if (t < 22) {
			Fx.ring(l, Fx.SOUL, g, 3 + t * 0.3, 24, 0.2);
			if (t % 4 == 0) Fx.p(l, Fx.ROD, g.x, g.y + 1, g.z, 10, 1.5, 0.5, 1.5, 0.1);
		}
		if (t == 24) {
			Fx.sound(l, g, "minecraft:entity.warden.sonic_boom", 5.0f, 0.7f);
			b.shocks.add(new Shock(g, 0.9, 28, 14f, 1));
		}
		if (t == 44) b.shocks.add(new Shock(g, 0.9, 28, 14f, 0));
		if (b.phase >= 3 && t == 56) b.shocks.add(new Shock(g, 1.1, 28, 14f, 1));
	}

	// ---------- 4. Sternenfall ----------
	private static void starfall(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		charge(b, l, t, 10);
		if (t >= 10 && t < 85 && t % 3 == 0) {
			Vec3 base;
			if (R.nextInt(100) < 60 && target != null) base = groundAt(l, target);
			else base = ground(l, b.getX() + (R.nextDouble() - 0.5) * 36, b.getY(), b.getZ() + (R.nextDouble() - 0.5) * 36);
			Vec3 pos = ground(l, base.x + (R.nextDouble() - 0.5) * 6, base.y + 2, base.z + (R.nextDouble() - 0.5) * 6);
			b.strikes.add(new Strike(pos, 24, 3f, 9f, 2));
			if (t % 9 == 0) Fx.sound(l, pos, "minecraft:entity.firework_rocket.launch", 2.0f, 0.8f);
		}
	}

	// ---------- 5. Dunkler Sog ----------
	private static void voidPull(DaemonenlordEntity b, ServerLevel l, int t) {
		Vec3 g = ground(l, b.getX(), b.getY(), b.getZ());
		Vec3 c = core(b);
		if (t < 60) {
			if (t % 10 == 0) Fx.sound(l, c, "minecraft:block.portal.ambient", 4.0f, 0.5f);
			for (int i = 0; i < 6; i++) {
				double ang = R.nextDouble() * Math.PI * 2, rad = 10 + R.nextDouble() * 10;
				Vec3 o = new Vec3(Math.cos(ang) * rad, 2 + R.nextDouble() * 6, Math.sin(ang) * rad);
				Vec3 at = g.add(o);
				Fx.dir(l, Fx.PORTAL, at, new Vec3(-o.x, -o.y + 5, -o.z).scale(0.06), 1.0);
			}
			Fx.ring(l, Fx.SOUL, g, 12 - t * 0.15, 30, 0.2);
			for (ServerPlayer p : Fx.players(l, g, 40)) {
				Vec3 to = new Vec3(g.x - p.getX(), 0, g.z - p.getZ());
				if (to.length() > 3.5) Fx.push(p, to.normalize().scale(0.10 + 0.0015 * t));
			}
		}
		if (t == 62) {
			Fx.sound(l, g, "minecraft:entity.generic.explode", 6.0f, 0.5f);
			Fx.p(l, Fx.BOOM, g.x, g.y + 2, g.z, 3, 2, 1, 2, 0);
			Fx.p(l, Fx.ROD, g.x, g.y + 3, g.z, 200, 3, 3, 3, 0.8);
			float scale = 1.0f + 0.2f * (b.phase - 1);
			for (ServerPlayer p : Fx.players(l, g, 8)) {
				Fx.damage(l, p, b, 18f * scale, true);
				Fx.push(p, new Vec3(p.getX() - g.x, 0, p.getZ() - g.z).normalize().scale(1.2).add(0, 0.8, 0));
			}
			b.shocks.add(new Shock(g, 0.8, 14, 10f, 1));
		}
	}

	// ---------- 6. Schattenbeschwoerung ----------
	private static void summon(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		if (t == 0) b.lockPos = target == null ? b.position() : groundAt(l, target);
		if (t < 22) {
			Vec3 c = b.lockPos;
			Fx.ring(l, Fx.SOUL, c, 9, 40, 0.2);
			for (int i = 0; i < 4; i++) {
				double ang = Math.PI * 2 * i / 4 + t * 0.2;
				Fx.p(l, Fx.SOUL, c.x + Math.cos(ang) * 9, c.y + t * 0.3, c.z + Math.sin(ang) * 9, 4, 0.2, 0.8, 0.2, 0.02);
			}
		}
		if (t == 22) {
			Fx.sound(l, b.position(), "minecraft:entity.evoker.prepare_summon", 4.0f, 0.6f);
			int existing = b.minionCount(l);
			int want = Math.min(b.phase + 2, 6 - Math.min(existing, 6));
			for (int i = 0; i < want; i++) {
				double ang = Math.PI * 2 * i / Math.max(1, want) + R.nextDouble();
				Vec3 g = ground(l, b.lockPos.x + Math.cos(ang) * 8, b.lockPos.y + 3, b.lockPos.z + Math.sin(ang) * 8);
				Fx.cmd(l, g, String.format(Locale.ROOT,
						"summon minecraft:wither_skeleton %.2f %.2f %.2f {Tags:[\"%s\"],CustomName:\"Schattendiener\",PersistenceRequired:1b}",
						g.x, g.y, g.z, Fx.MINION_TAG));
				Fx.p(l, Fx.SOUL, g.x, g.y + 1, g.z, 40, 0.5, 1.2, 0.5, 0.05);
				Fx.p(l, Fx.ROD, g.x, g.y + 1, g.z, 20, 0.5, 1.5, 0.5, 0.3);
			}
		}
		if (t == 24) {
			Fx.cmd(l, b.position(), "effect give @e[tag=" + Fx.MINION_TAG + ",distance=..90] minecraft:resistance 600 1 true");
			Fx.cmd(l, b.position(), "effect give @e[tag=" + Fx.MINION_TAG + ",distance=..90] minecraft:speed 600 0 true");
		}
	}

	// ---------- 7. Strahl des Urteils ----------
	private static void beam(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		Vec3 c = core(b);
		if (t < 45) {
			if (target != null) b.beamDir = target.getEyePosition().subtract(c).normalize();
			charge(b, l, t, 45);
			if (t % 3 == 0) {
				Fx.line(l, Fx.CRIT, c, c.add(b.beamDir.scale(40)), 2.0);
				Fx.p(l, Fx.ROD, c, 8, 0.6, 0.1);
			}
			if (t == 20) Fx.sound(l, c, "minecraft:block.beacon.ambient", 5.0f, 0.5f);
		} else if (t < 105) {
			if (t == 45) Fx.sound(l, c, "minecraft:entity.warden.sonic_boom", 6.0f, 0.5f);
			double ang = Math.toRadians(1.7 * b.beamSweep);
			double cs = Math.cos(ang), sn = Math.sin(ang);
			b.beamDir = new Vec3(b.beamDir.x * cs - b.beamDir.z * sn, b.beamDir.y * 0.995 - 0.0025, b.beamDir.x * sn + b.beamDir.z * cs).normalize();
			Vec3 end = c.add(b.beamDir.scale(48));
			Fx.line(l, Fx.ROD, c, end, 0.7);
			if (t % 2 == 0) Fx.line(l, Fx.FLAME, c, end, 1.6);
			if (t % 4 == 0) {
				float scale = 1.0f + 0.2f * (b.phase - 1);
				for (ServerPlayer p : Fx.players(l, c, 55)) {
					Vec3 q = p.position().add(0, 1, 0).subtract(c);
					double proj = Math.max(0, Math.min(48, q.dot(b.beamDir)));
					double dist = q.subtract(b.beamDir.scale(proj)).length();
					if (dist < 2.0) Fx.damage(l, p, b, 6f * scale, true);
				}
				Vec3 hitPt = c.add(b.beamDir.scale(30));
				Fx.sound(l, hitPt, "minecraft:entity.lightning_bolt.thunder", 1.2f, 1.8f);
			}
			// Aufprall-Funken am Boden
			Vec3 gp = ground(l, end.x, end.y + 10, end.z);
			Fx.p(l, Fx.SPARK, gp.x, gp.y + 0.5, gp.z, 6, 0.5, 0.3, 0.5, 0.3);
		}
	}

	// ---------- 8. Himmelsbruch ----------
	private static void slam(DaemonenlordEntity b, ServerLevel l, int t, ServerPlayer target) {
		b.freezeHover = true;
		if (t < 30) {
			b.setDeltaMovement(0, 0.55, 0);
			if (t % 3 == 0) Fx.p(l, Fx.ROD, b.getX(), b.getY() + 1, b.getZ(), 6, 1.5, 0.2, 1.5, 0.1);
			if (target != null) b.lockPos = groundAt(l, target);
			Fx.ring(l, Fx.FLAME, b.lockPos, 9 * (t / 30.0), 24, 0.2);
		} else if (t < 40) {
			b.setDeltaMovement(0, 0, 0);
			Fx.ring(l, Fx.ROD, b.lockPos, 9, 40, 0.2);
			Fx.ring(l, Fx.FLAME, b.lockPos, 9, 40, 0.2);
			if (t == 30) Fx.sound(l, b.position(), "minecraft:entity.ender_dragon.growl", 5.0f, 1.0f);
		} else if (t == 40) {
			b.setPos(b.lockPos.x, b.lockPos.y + 16, b.lockPos.z);
			b.setDeltaMovement(0, -2.3, 0);
		} else if (t < 70) {
			b.setDeltaMovement(0, -2.3, 0);
			Fx.p(l, Fx.FLAME, b.getX(), b.getY() + 3, b.getZ(), 15, 1.2, 2, 1.2, 0.05);
			Fx.p(l, Fx.ROD, b.getX(), b.getY() + 6, b.getZ(), 6, 0.6, 3, 0.6, 0.0);
			if (b.getY() <= b.lockPos.y + 3.2 || t == 69) {
				Vec3 g = b.lockPos;
				b.setDeltaMovement(0, 0, 0);
				b.setPos(g.x, g.y + 3.0, g.z);
				Fx.sound(l, g, "minecraft:entity.generic.explode", 8.0f, 0.5f);
				Fx.sound(l, g, "minecraft:entity.iron_golem.death", 8.0f, 0.5f);
				Fx.p(l, Fx.BOOM, g.x, g.y + 2, g.z, 4, 3, 0.5, 3, 0);
				Fx.p(l, Fx.ROD, g.x, g.y + 2, g.z, 250, 4, 2, 4, 0.9);
				Fx.p(l, Fx.FLAME, g.x, g.y + 1, g.z, 200, 5, 0.5, 5, 0.3);
				float scale = 1.0f + 0.2f * (b.phase - 1);
				for (ServerPlayer p : Fx.players(l, g, 11)) {
					Fx.damage(l, p, b, 22f * scale, false);
					Fx.push(p, new Vec3(p.getX() - g.x, 0, p.getZ() - g.z).normalize().scale(1.1).add(0, 0.9, 0));
				}
				b.shocks.add(new Shock(g, 1.0, 30, 14f, 0));
				b.atkTick = Attack.SLAM.duration;
			}
		}
	}

	// ---------- 9. ULTIMATE: Das Juengste Gericht der Asche ----------
	private static void ultimate(DaemonenlordEntity b, ServerLevel l, int t) {
		Vec3 cc = b.ultCenter;
		Vec3 c = core(b);
		b.freezeHover = true;
		if (t < 90) {
			double vy = Math.max(-0.4, Math.min(0.5, (b.ultBaseY - b.getY()) * 0.08));
			b.setDeltaMovement(0, vy, 0);
			// Energie sammeln
			for (int i = 0; i < 6; i++) {
				double th = R.nextDouble() * Math.PI * 2, ph = Math.acos(2 * R.nextDouble() - 1);
				double rad = 16 - t * 0.12;
				Vec3 o = new Vec3(Math.sin(ph) * Math.cos(th), Math.cos(ph), Math.sin(ph) * Math.sin(th));
				Fx.dir(l, Fx.ROD, c.add(o.scale(rad)), o.scale(-1), 0.5 + t * 0.006);
			}
			// rotierende Lichtsaeulen
			if (t % 2 == 0) {
				for (int k = 0; k < 8; k++) {
					double ang = Math.PI * 2 * k / 8 + t * 0.03;
					double x = cc.x + Math.cos(ang) * 22, z = cc.z + Math.sin(ang) * 22;
					for (double y = 0; y < 34; y += 2.5) Fx.p(l, k % 2 == 0 ? Fx.ROD : Fx.FLAME, x, cc.y + y, z, 1, 0.12, 0, 0.12, 0);
				}
			}
			Fx.ring(l, Fx.FLAME, cc, 22, 60, 0.2);
			Fx.ring(l, Fx.ROD, cc, 12 + Math.sin(t * 0.2) * 1.5, 40, 0.25);
			if (t % 12 == 0) Fx.sound(l, c, "minecraft:block.beacon.power_select", 6.0f, 0.5f + t * 0.01f);
			if (t == 30 || t == 60) {
				for (ServerPlayer p : Fx.players(l, cc, 60)) {
					Vec3 g = groundAt(l, p);
					for (int i = 0; i < 6; i++) {
						double ang = Math.PI * 2 * i / 6;
						b.strikes.add(new Strike(ground(l, g.x + Math.cos(ang) * 5, g.y + 2, g.z + Math.sin(ang) * 5), 25 + i * 2, 2.5f, 12f, 1));
					}
				}
			}
		} else if (t == 90) {
			b.setDeltaMovement(0, 0, 0);
			Fx.flash(l, c, 110, 50);
			for (ServerPlayer p : Fx.players(l, cc, 70)) Fx.effect(l, p, "minecraft:blindness", 3, 0);
			Fx.sound(l, c, "minecraft:entity.generic.explode", 10.0f, 0.5f);
			Fx.sound(l, c, "minecraft:entity.lightning_bolt.thunder", 10.0f, 0.5f);
			Fx.sound(l, c, "minecraft:entity.ender_dragon.growl", 10.0f, 0.4f);
			Fx.p(l, Fx.BOOM, c, 6, 4, 0);
			Fx.p(l, Fx.ROD, c, 400, 3, 1.2);
			Fx.p(l, Fx.FLAME, c, 300, 3, 0.8);
			Fx.p(l, Fx.TOTEM, c, 300, 4, 1.0);
			float scale = 1.0f + 0.2f * (b.phase - 1);
			for (ServerPlayer p : Fx.players(l, c, 10)) {
				Fx.damage(l, p, b, 24f * scale, true);
				Fx.push(p, new Vec3(p.getX() - c.x, 0, p.getZ() - c.z).normalize().scale(1.5).add(0, 1.0, 0));
			}
		} else if (t >= 92 && t < 150) {
			if (t == 95 || t == 107 || t == 119) {
				b.shocks.add(new Shock(cc, 1.15, 46, 18f, t == 107 ? 1 : 0));
				Fx.sound(l, cc, "minecraft:entity.warden.sonic_boom", 8.0f, 0.6f);
			}
			// Lichtsaeulen-Gericht
			if (t >= 100 && t % 4 == 0 && t < 140) {
				for (ServerPlayer p : Fx.players(l, cc, 60)) b.strikes.add(new Strike(groundAt(l, p), 14, 3f, 15f, 3));
			}
			if (t % 3 == 0) {
				double ang = R.nextDouble() * Math.PI * 2, rad = R.nextDouble() * 40;
				Vec3 g = ground(l, cc.x + Math.cos(ang) * rad, cc.y + 3, cc.z + Math.sin(ang) * rad);
				Fx.p(l, Fx.ROD, g.x, g.y + 1, g.z, 30, 0.3, 4, 0.3, 0.2);
			}
			if (t < 130) Fx.ring(l, Fx.ROD, cc, (t - 92) * 1.2, 80, 0.4);
			double vy = Math.max(-0.3, Math.min(0.3, (b.ultBaseY - b.getY()) * 0.05));
			b.setDeltaMovement(0, vy, 0);
		} else if (t >= 150) {
			if (t == 150) {
				Fx.title(l, c, 110, "DIE ASCHE LEGT SICH", "Der Richter ist erschöpft – schlagt zu!", "gold");
				b.endAttack();
				b.stun = 110;
			}
		}
	}
}
