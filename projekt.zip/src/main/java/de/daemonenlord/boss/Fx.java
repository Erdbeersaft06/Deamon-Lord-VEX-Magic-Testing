package de.daemonenlord.boss;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import de.daemonenlord.entity.ModEntities;

/**
 * Alle riskanten / versionsabhaengigen Aufrufe (Partikel, Sounds, Schaden, Titel, Befehle) liegen hier.
 * Falls sich eine API in 26.2 anders verhaelt, muss nur diese Datei angepasst werden.
 */
public final class Fx {
	private Fx() {}

	// ---- Partikel-Konstanten (alles SimpleParticleType) ----
	public static final SimpleParticleType FLAME = ParticleTypes.FLAME;
	public static final SimpleParticleType SOUL = ParticleTypes.SOUL_FIRE_FLAME;
	public static final SimpleParticleType ROD = ParticleTypes.END_ROD;
	public static final SimpleParticleType BOOM = ParticleTypes.EXPLOSION_EMITTER;
	public static final SimpleParticleType CRIT = ParticleTypes.CRIT;
	public static final SimpleParticleType SPARK = ParticleTypes.ELECTRIC_SPARK;
	public static final SimpleParticleType SMOKE = ParticleTypes.LARGE_SMOKE;
	public static final SimpleParticleType LAVA = ParticleTypes.LAVA;
	public static final SimpleParticleType PORTAL = ParticleTypes.PORTAL;
	public static final SimpleParticleType TOTEM = ParticleTypes.TOTEM_OF_UNDYING;

	/** Wird vom Boss pro Tick gesetzt: neu erzeugte Effekte sind rot (nach der Wiederbelebung). */
	public static boolean currentRed = false;

	public static final String MINION_TAG = "dl_minion";
	public static final char FLASH_GLYPH = '';

	// ---- Blockbench-Effektmodelle ----
	public static final int K_RING = 0, K_SEAL = 1, K_BLADE = 2, K_PILLAR = 3, K_CORE = 4, K_BLADERING = 5, K_BEAM = 6;

	public static FxEntity fx(ServerLevel l, int kind, Vec3 pos, int life, float sxz, float sy) {
		FxEntity e = new FxEntity(ModEntities.FX, l);
		e.setup(kind, life, sxz, sy);
		e.setRed(currentRed);
		e.setPos(pos.x, pos.y, pos.z);
		l.addFreshEntity(e);
		return e;
	}

	// ---- Befehle ----
	public static void cmd(ServerLevel level, Vec3 at, String command) {
		MinecraftServer server = level.getServer();
		CommandSourceStack src = server.createCommandSourceStack().withLevel(level).withPosition(at).withSuppressedOutput();
		server.getCommands().performPrefixedCommand(src, command);
	}

	// ---- Partikel ----
	public static void p(ServerLevel l, ParticleOptions type, double x, double y, double z, int n, double dx, double dy, double dz, double speed) {
		l.sendParticles(type, x, y, z, n, dx, dy, dz, speed);
	}

	public static void p(ServerLevel l, ParticleOptions type, Vec3 v, int n, double spread, double speed) {
		l.sendParticles(type, v.x, v.y, v.z, n, spread, spread, spread, speed);
	}

	/** Partikel mit gerichteter Geschwindigkeit (count=0 => dx,dy,dz sind die Richtung). */
	public static void dir(ServerLevel l, ParticleOptions type, Vec3 at, Vec3 velocity, double speed) {
		l.sendParticles(type, at.x, at.y, at.z, 0, velocity.x, velocity.y, velocity.z, speed);
	}

	public static void ring(ServerLevel l, ParticleOptions type, Vec3 c, double r, int points, double yOff) {
		for (int i = 0; i < points; i++) {
			double a = Math.PI * 2 * i / points;
			l.sendParticles(type, c.x + Math.cos(a) * r, c.y + yOff, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
		}
	}

	public static void line(ServerLevel l, ParticleOptions type, Vec3 a, Vec3 b, double step) {
		Vec3 d = b.subtract(a);
		double len = d.length();
		if (len < 0.01) return;
		Vec3 n = d.scale(1.0 / len);
		for (double t = 0; t <= len; t += step) {
			l.sendParticles(type, a.x + n.x * t, a.y + n.y * t, a.z + n.z * t, 1, 0, 0, 0, 0);
		}
	}

	// ---- Sound ----
	public static void sound(ServerLevel l, Vec3 at, String soundId, float vol, float pitch) {
		cmd(l, at, String.format(java.util.Locale.ROOT, "playsound %s hostile @a %.2f %.2f %.2f %.2f %.2f", soundId, at.x, at.y, at.z, vol, pitch));
	}

	// ---- Spieler ----
	public static List<ServerPlayer> players(ServerLevel l, Vec3 c, double r) {
		List<ServerPlayer> out = new ArrayList<>();
		for (ServerPlayer p : l.players()) {
			if (p.isAlive() && !p.isSpectator() && p.position().distanceTo(c) <= r) out.add(p);
		}
		return out;
	}

	/** Schaden ueber /damage (versionsstabil). pierce=true -> ignoriert Ruestung (magic). */
	public static void damage(ServerLevel l, Entity victim, Entity attacker, float amount, boolean pierce) {
		if (attacker instanceof DaemonenlordEntity boss) amount *= boss.damageMultiplier();
		String type = pierce ? "minecraft:magic" : "minecraft:mob_attack";
		String by = (attacker != null && !pierce) ? " by " + attacker.getStringUUID() : "";
		cmd(l, victim.position(), String.format(java.util.Locale.ROOT, "damage %s %.1f %s%s", victim.getStringUUID(), amount, type, by));
	}

	/** Schaden ohne Boss-Multiplikator (z. B. Prozent der max. HP). */
	public static void damageRaw(ServerLevel l, Entity victim, float amount) {
		cmd(l, victim.position(), String.format(java.util.Locale.ROOT, "damage %s %.1f minecraft:magic", victim.getStringUUID(), amount));
	}

	public static void effect(ServerLevel l, Entity e, String effectId, int seconds, int amp) {
		cmd(l, e.position(), "effect give " + e.getStringUUID() + " " + effectId + " " + seconds + " " + amp + " true");
	}

	/** Impuls + Client-Sync (Reflection, falls das Feld in 26.2 anders heisst). */
	public static void push(Entity e, Vec3 v) {
		e.push(v.x, v.y, v.z);
		try {
			Field f = Entity.class.getField("hurtMarked");
			f.setBoolean(e, true);
		} catch (Throwable ignored) {
			// kein Sync noetig / Feld nicht vorhanden
		}
	}

	// ---- Titel / Blendeffekt ----
	private static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

	public static void title(ServerLevel l, Vec3 c, double r, String title, String subtitle, String color) {
		String sel = "@a[distance=.." + (int) r + "]";
		cmd(l, c, "title " + sel + " times 10 60 25");
		cmd(l, c, "title " + sel + " subtitle {\"text\":\"" + esc(subtitle) + "\",\"color\":\"gray\",\"italic\":true}");
		cmd(l, c, "title " + sel + " title {\"text\":\"" + esc(title) + "\",\"color\":\"" + color + "\",\"bold\":true}");
	}

	public static void actionbar(ServerLevel l, Vec3 c, double r, String text, String color) {
		cmd(l, c, "title @a[distance=.." + (int) r + "] actionbar {\"text\":\"" + esc(text) + "\",\"color\":\"" + color + "\",\"bold\":true}");
	}

	/** Weisser Vollbild-Blitz ueber das Font-Glyph (assets/daemonenlord/font/flash.json). */
	public static void flash(ServerLevel l, Vec3 c, double r, int fadeOutTicks) {
		String sel = "@a[distance=.." + (int) r + "]";
		cmd(l, c, "title " + sel + " times 0 6 " + fadeOutTicks);
		cmd(l, c, "title " + sel + " subtitle {\"text\":\"\"}");
		cmd(l, c, "title " + sel + " title {\"text\":\"" + FLASH_GLYPH + "\",\"font\":\"daemonenlord:flash\",\"color\":\"#FFFFFF\"}");
	}

	// ---- Boden ----
	public static double groundY(ServerLevel l, double x, double y, double z) {
		int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
		int iy = (int) Math.floor(y);
		for (int i = 0; i < 64; i++) {
			if (!l.getBlockState(new BlockPos(ix, iy - i, iz)).isAir()) return iy - i + 1.0;
		}
		return y - 8;
	}

	// ---- Bossleiste (ServerBossEvent-Konstruktor wechselt zwischen Versionen -> Reflection) ----
	public static ServerBossEvent bossEvent(Component name) {
		for (Constructor<?> c : ServerBossEvent.class.getConstructors()) {
			Class<?>[] pt = c.getParameterTypes();
			Object[] args = new Object[pt.length];
			boolean ok = true;
			for (int i = 0; i < pt.length; i++) {
				if (pt[i] == UUID.class) args[i] = UUID.randomUUID();
				else if (pt[i].isAssignableFrom(Component.class) && pt[i] != Object.class) args[i] = name;
				else if (pt[i] == BossEvent.BossBarColor.class) args[i] = BossEvent.BossBarColor.YELLOW;
				else if (pt[i] == BossEvent.BossBarOverlay.class) args[i] = BossEvent.BossBarOverlay.PROGRESS;
				else ok = false;
			}
			if (!ok) continue;
			try {
				return (ServerBossEvent) c.newInstance(args);
			} catch (ReflectiveOperationException ignored) {
				// naechsten Konstruktor probieren
			}
		}
		throw new IllegalStateException("Kein passender ServerBossEvent-Konstruktor gefunden");
	}
}
