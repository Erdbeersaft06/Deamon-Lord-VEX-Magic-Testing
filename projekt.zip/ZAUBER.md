# Dämonenlord – Zauberliste

Test-Befehl: `/daemonenlord attack <name>` (Name in Klammern)

## Phase 1 (über 66 % HP)
- **Höllenfeuer-Salve** (`hoellenfeuer`) – Feuerkerne schlagen mit Warnkreis im Gebiet der Spieler ein. Schaden nur innerhalb des sichtbaren Kreises (3,2 Blöcke); Kreise überlappen sich nie.
- **Klingenhagel** (`klingenhagel`) – Klingen regnen vom Himmel auf markierte Stellen.
- **Seelenfeuer-Welle** (`seelenwelle`) – Ring-Schockwelle um den Boss; man muss darüberspringen.
- **Schattenbeschwörung** (`schatten`) – Beschwört Schattendiener (Phase 1: 5–10, Phase 2: 11–15, Phase 3: 20–30; 30 HP, schwach, sterben >50 Blöcke vom Boss).

## Phase 2 (unter 66 % HP) – neu: Sternenfall, Dunkler Sog, Strahl, Strahlenkranz
- **Sternenfall** (`sternenfall`) – Viele Einschläge nacheinander rund um die Spieler.
- **Dunkler Sog** (`sog`) – Zieht alle Spieler zum Boss, danach Explosion.
- **Strahl des Urteils** (`strahl`) – Dünner Strahl (30 Blöcke), der über die Spieler schwenkt.
- **Strahlenkranz** (`strahlenkranz`) – 8 rotierende Strahlen (22 Blöcke) um den Boss.

## Phase 3 (unter 33 % HP) – neu: Himmelsbruch, Schwertgericht, Aderlass, Hinrichtung
- **Himmelsbruch** (`himmelsbruch`) – Boss springt hoch und schlägt mit Schockwelle ein.
- **Schwertgericht** (`schwerter`) – Magiekreis über dem Boss, Schwerter regnen und bleiben stecken; nach 5–15 s Schockwelle (35 % max. HP).
- **Seelenaderlass** (`aderlass`) – Spieler werden festgehalten, Magiekreise um sie herum, Strahlen saugen HP und heilen den Boss. Boss ist währenddessen unverwundbar.
- **Arkane Hinrichtung** (`hinrichtung`) – Ein Spieler wird ~6 Blöcke hochgehoben und festgehalten. 8 Magiekreise schweben in verschiedenen Abständen, zielen auf ihn und feuern Projektile, die gleichzeitig treffen: **50 % max. HP**.
- **Seelenbund** (`seelenbund`) – Nur einmal, bei ≤15 % HP, zufällig in Leben 1 oder 2. Spawnt 60–120 Schattendiener, Strahlen zu jedem heilen den Boss (0,5 % pro Diener).

Zu Beginn jeder neuen Phase wird als Erstes einer der neuen Zauber eingesetzt.

## Besondere Fähigkeiten
- **Das Jüngste Gericht der Asche** (`juengstes_gericht`) – Ultimate bei 50 % und 15 % HP. Der Boss ist unverwundbar, der Magiekreis (Radius 22) hält alle Spieler gefangen. Über dem Boss erscheint eine große Waage, die sich bewegt und Lichtblitze abgibt (wie eine sich öffnende Tür). Wird das Licht gleißend hell, explodiert der ganze Kreis (65 % max. HP + Fixschaden). Danach 5 s erschöpft.
- **Pforte der Auslöschung** (`ausloeschung`) – Am Ende von Leben 2 (≤15 % HP) und in Leben 3 bei 50 % HP. Der Boss zeichnet ~80 Blöcke über sich einen gigantischen Magiekreis, darunter 13 kleinere (teleskopartig bis ~25 Blöcke über dem Boden); Runen fliegen in den Himmel. Die Kreise sind bunt und drehen sich in unterschiedliche Richtungen. Dann prescht ein grellweißer Strahl durch die Mitte in den Boden, es folgt der Pastell-Regenbogen-Flash: **jeder Spieler in der 60-Block-Zone stirbt sofort – nur ein Totem der Unsterblichkeit rettet** – man muss die Zone verlassen. Danach 7,5 s erschöpft.
- **Wiederbelebung 1** – Boss fällt, steigt rot wieder auf (60 % HP, +35 % Schaden).
- **Wiederbelebung 2** – Blau-Schwarz, 300 Max-HP, doppelt so viel Schaden, Angriffe 50 % schneller, danach **Domäne**.
- **Domäne** (`/daemonenlord domain <radius> [sekunden]`) – Schrumpfender Kreis, folgt dem Boss, niemand kommt raus. Bei 0: Boss heilt 50 %, Explosion = 80 % max. HP der Spieler.

Zauber-Häufigkeit: Höllenfeuer ist am häufigsten; Aderlass und Hinrichtung sind selten und haben danach mehrere Angriffe Pause.

Alle Prozent-Schäden (Schwertgericht, Hinrichtung, Domäne, Ultimate-Explosion) wirken auch auf Absorptionsherzen.
