# Dämonenlord – Zauberliste

Test-Befehl: `/daemonenlord attack <name>` (Name in Klammern)

## Phase 1 (über 66 % HP)
- **Höllenfeuer-Salve** (`hoellenfeuer`) – Feuerkerne schlagen mit Warnkreis im Gebiet der Spieler ein. Schaden nur innerhalb des sichtbaren Kreises (3,2 Blöcke); Kreise überlappen sich nie.
- **Klingenhagel** (`klingenhagel`) – Klingen regnen vom Himmel auf markierte Stellen.
- **Seelenfeuer-Welle** (`seelenwelle`) – Ring-Schockwelle um den Boss; man muss darüberspringen.
- **Schattenbeschwörung** (`schatten`) – Beschwört Schattendiener (Phase 1: 5–10, Phase 2: 11–15, Phase 3: 20–30; 30 HP, schwach, sterben >50 Blöcke vom Boss).

## Phase 2 (unter 66 % HP) – neu: Sternenfall, Dunkler Sog, Strahl, Strahlenkranz
- **Sternenfall** (`sternenfall`) – Viele Einschläge nacheinander rund um die Spieler.
- **Dunkler Sog** (`sog`) – Zieht alle Spieler zum Boss, danach Explosion.
- **Strahl des Urteils** (`strahl`) – Dünner Strahl (30 Blöcke), der über die Spieler schwenkt.
- **Strahlenkranz** (`strahlenkranz`) – 8 rotierende Strahlen (22 Blöcke) um den Boss.

## Phase 3 (unter 33 % HP) – neu: Himmelsbruch, Schwertgericht, Aderlass, Hinrichtung
- **Himmelsbruch** (`himmelsbruch`) – Boss springt hoch und schlägt mit Schockwelle ein.
- **Schwertgericht** (`schwerter`) – Magiekreis über dem Boss, Schwerter regnen und bleiben stecken; nach 5–15 s Schockwelle (35 % max. HP).
- **Seelenaderlass** (`aderlass`) – Spieler werden festgehalten, Magiekreise schweben in der Luft um sie herum und zielen auf sie, Strahlen saugen HP und heilen den Boss. Boss ist währenddessen unverwundbar.
- **Arkane Hinrichtung** (`hinrichtung`) – **Alle Spieler** im Bereich werden ~6 Blöcke hochgehoben und festgehalten. Pro Spieler schweben 5–8 Magiekreise in verschiedenen Abständen, zielen auf ihn und feuern Projektile, die gleichzeitig treffen: **50 % max. HP** (je Spieler).
- **Zorn der Sonne** (`sonnenzorn`) – Selten, Boss unverwundbar und am Boden (ca. 17 s). Ein goldener Magiekreis breitet sich auf 60 Blöcke aus, am Rand steht ein gelblicher Lichtschleier. Über dem Boss bauen sich 5 Kreise übereinander auf (unten groß und detailreich, oben kleiner und schlichter). 12 schräge 45°-Kreise (8 unten, 4 oben, gegenläufig) umkreisen die Säule. Eine Sonne lädt sich auf, der Himmel verdunkelt sich, bei voller Ladung gibt es **Blindheit I**. Lichtstrahlen laufen von Kreis zu Kreis nach unten und werden mit jeder Ebene dicker; die schrägen Kreise speisen den Hauptstrahl (jeder macht ihn dicker). Einschlag: **100 % max. HP im Zentrum, 60 % ganz außen** (linear). Danach 7,5 s erschöpft.
- **Seelenbund** (`seelenbund`) – Nur einmal, bei ≤15 % HP, zufällig in Leben 1 oder 2. Der Boss ist währenddessen unverwundbar. Spawnt 60–120 Schattendiener, Strahlen zu jedem heilen den Boss (0,5 % pro Diener).

Zu Beginn jeder neuen Phase wird als Erstes einer der neuen Zauber eingesetzt.

## Besondere Fähigkeiten
- **Das Jüngste Gericht der Asche** (`juengstes_gericht`) – Ultimate bei 50 % und 15 % HP. Der Boss ist unverwundbar, der Magiekreis (Radius 22) hält alle Spieler gefangen. Über dem Boss erscheint eine große Waage, die sich bewegt und Lichtblitze abgibt (wie eine sich öffnende Tür). Wird das Licht gleißend hell, explodiert der ganze Kreis (65 % max. HP + Fixschaden). Danach 5 s erschöpft.
- **Pforte der Auslöschung** (`ausloeschung`) – Am Ende von Leben 2 (≤15 % HP) und in Leben 3 bei 50 % HP. Der Boss zeichnet ~80 Blöcke über sich einen gigantischen Magiekreis, darunter 13 kleinere (teleskopartig bis ~25 Blöcke über dem Boden); Sehr viele Runen (Glyphen) fliegen gleichzeitig in den Himmel und bauen die Kreise sichtbar auf. Die Kreise sind bunt und drehen sich in unterschiedliche Richtungen. Dann prescht ein grellweißer Strahl durch die Mitte in den Boden, es folgt der Pastell-Regenbogen-Flash: **jeder Spieler in der 60-Block-Zone stirbt sofort – nur ein Totem der Unsterblichkeit rettet** – man muss die Zone verlassen. Danach 7,5 s erschöpft.
- **Wiederbelebung 1** – Boss fällt, steigt rot wieder auf (60 % HP, +35 % Schaden).
- **Wiederbelebung 2** – Blau-Schwarz, 300 Max-HP, doppelt so viel Schaden, Angriffe 50 % schneller, danach **Domäne**.
- **Domäne** (`/daemonenlord domain <radius> [sekunden]`) – Schrumpfender Kreis, folgt dem Boss, niemand kommt raus. Bei 0: Boss heilt 50 %, Explosion = 80 % max. HP der Spieler.

Zauber-Häufigkeit: Höllenfeuer ist in Leben 1–2 am häufigsten. In Leben 3 werden starke Zauber (Himmelsbruch, Schwertgericht, Sog, Strahl, Strahlenkranz, Aderlass, Hinrichtung) bevorzugt; Salve und Sternenfall sind seltener. Aderlass und Hinrichtung haben danach mehrere Angriffe Pause.

Alle Prozent-Schäden (Schwertgericht, Hinrichtung, Domäne, Ultimate-Explosion) wirken auch auf Absorptionsherzen.

Schattendiener (Wither-Skelette) tragen eine eigene Gold-Schwarze Sense (langer Stiel) und droppen keinen Loot. Boss ist während Pforte, Gericht, Aderlass und Seelenbund unverwundbar.

Erschöpft (nach Jüngstem Gericht und Pforte) nimmt der Boss 80 % mehr Schaden. Schadensfaktor je Leben: 1,6× / 2,0× / 2,7×.

---

# Solara & Lunara (Duo-Boss, `/solunar spawn`)

Zwei Göttinnen, die immer **gleichzeitig** kämpfen (auch solo, nicht abgeschwächt). Eigener Kampf, der Dämonenlord bleibt Solo-Boss.

- **Solara** (Sonne, Gold/Orange): Angriff, schnell, Hitze und Licht. **Lunara** (Mond, Silber/Blau): Kontrolle, Zug, Frost, Dunkelheit.
- **Lebenspunkte:** je Göttin 900 HP × Faktor nach Spielerzahl im Umkreis (1 = 100 %, 2 = 170 %, 3 = 240 %, dann +70 % je Spieler). Zwei Bossleisten.
- **Bund:** 15 % jedes Treffers auf eine Göttin trifft auch die andere. Fällt eine, wird die andere zur **Wüterin** (+30 % Schaden, kürzere Pausen).
- **Schaden** (Magie, ignoriert Rüstung; Zahlen für volle Netherite + Protection V): Hauptangriff **4 Herzen**, Zone 2,5 Herzen, Schwer 7 Herzen, Ultimate 11+ Herzen. Roh-Schaden = 10 je Herz.
- Die beiden versetzen ihre Angriffe: Die zweite Göttin startet erst, wenn die erste ihren Zauber eingeleitet hat.

## Balance v3 (Duo-Kampf)
- Bewegung der Göttinnen −80 % (Kreisen, Anflug bei Duo-Zaubern).
- Angriffstempo +60 %: Zauber laufen 1,6× schneller ab (Warnzeiten, Wellen), Pausen zwischen Zaubern durch 1,6 geteilt.
- Schaden: Zone 34 (3,4♥), Hauptangriff 54 (5,4♥), Schwer 95 (9,5♥) bei roher Rechnung 10 pro Herz; Ultimates 150 % der max. HP.
- Mehr Projektile: Speerregen +70 %, Sonnenscheibe 4 Scheiben, Flammenflügel 4 Fächer, Strahlenkranz 12 Strahlen, Läuterndes Feuer 5 Sonnen, Silbersicheln 10, Mondsturz ~2× Einschläge, Schattenschleier dichter, Sternenreigen 50 Sterne, Zwielichtlanze 5 Salven, Morgenröte/Frostmond mit zweiter Welle.
- Optik: Aufladungs-Siegel + Kern bei jedem Zauber (Ultimates größer, mit Ringwelle), Ring-Schockwelle bei jedem Einschlag, Bildschirm-Blitz bei schweren Treffern, Strahlen mit Ladekern an der Mündung.
- Lunaspiegel: echte Lunara erscheint sofort am Platz (kein Anflug mehr, der sie verrät).

## Phasen
Nach durchschnittlicher Lebensenergie beider Göttinnen: **Tag/Nacht** (>66 %), **Dämmerung** (>33 %, Schaden ×1,2, Titel), **Finsternis** (≤33 %, Schaden ×1,4). Ultimates ab Dämmerung (alle ~75 s), Zwillingsgestirn nur in der Finsternis (einmal). Duo-Zauber werden mit 12 % / 30 % / 45 % Chance je Zyklus gewählt.
Heilung: Morgenröte heilt Lunara um 3 %, Gezeitenzug heilt Solara um 3 %.

## Solara (Befehl: `/solunar attack <name>`)
- `speerregen` Goldener Speerregen – Lichtspeere schlagen mit Warnkreis ein (4♥).
- `lanze` Gleißende Lanze – Zielstrahl, fixiert, dann Treffer (4♥).
- `morgenroete` Morgenröte – Lichtwelle über den Boden, überspringbar (4♥); heilt Lunara.
- `sonnenscheibe` – zwei rotierende Lichtscheiben prallen an der Arenakante ab (4♥ je Berührung).
- `flammenfluegel` – zwei Flammenfächer entstehen schräg nach außen; sicher: Mitte oder weit außen (4♥).
- `strahlenkranz` – 3 Wellen aus je 8 waagerechten Strahlen, versetzt (4♥).
- `laeuterndes_feuer` – drei kleine Sonnen jagen langsam die Spieler, Bodenhitze (2,5♥/s).
- `zenit` – ein Spieler wird markiert und verfolgt, dann fällt eine Lichtsäule an die fixierte Stelle (7♥).
- `glutschwur` – ein Spieler wird markiert (leuchtet), nach 3 s große Explosion um ihn: Abstand halten (7♥).
- `sonnenkrone` – ULTIMATE: lange Aufladung, alle ohne Dach über dem Kopf verlieren 150 % ihrer max. HP (tödlich).

## Lunara
- `mondsturz` (4♥ + Verlangsamung), `gezeitenzug` (Sog + Explosion 2,5♥; heilt Solara), `frostmond` (Eiswelle 2,5♥).
- `silbersicheln` – 6 Sicheln fliegen hinaus und kehren zurück (4♥).
- `schattenschleier` – Dunkelheit; Einschläge auf die Spielerpositionen, Bewegung hilft (4♥).
- `lunaspiegel` – zwei Trugbilder, die echte Lunara ist unter den dreien. Treffer auf ein Trugbild lässt es platzen, Treffer auf die echte betäubt sie 4 s (+80 % Schaden). Nach ~3 s feuern alle drei.
- `traumfessel` – alle Spieler werden stark verlangsamt (Stufe 4), in weiße Kreise (6,5 Blöcke entfernt) laufen löst die Fessel; währenddessen Einschläge auf Gefesselte (4♥).
- `nachtflut` – vier Lichtinseln; zweimal Flutwelle, wer nicht auf einer Insel steht, nimmt 7♥.
- `sternenreigen` – Sternschnuppen zeichnen einen Fünfzack um die Zielposition (4♥).
- `mondfinsternis` – ULTIMATE: Dunkelheit, nur in den Mondlichtkreisen überlebt man (sonst 150 % max. HP).

## Duo-Zauber (beide Göttinnen, gestartet von Solara)
- `sonnenfinsternis` – Korona-Ring um die Mitte (Kern sicher, 7♥), danach Schlag auf die Mitte: raus.
- `zwielichtlanze` – beide zielen von gegenüber auf denselben Spieler, 3 Salven (je 4♥).
- `tag_nacht_rad` – rotierende Trennlinie; abwechselnd trifft es die Tag- bzw. Nachtseite (4♥), Warnkreise vorher.
- `himmelsbund` – Strahl zwischen den Göttinnen fegt knapp über dem Boden: springen (4♥).
- `zwillingsgestirn` – FINALE (nur Finsternis): erst Sonnenkrone-Prüfung (Dach), dann Mondfinsternis-Prüfung (Mondlichtkreis), je 150 % max. HP.

Befehle: `/solunar spawn [pos]`, `kill`, `heal`, `list`, `attack <name>` (Duo-Zauber brauchen beide Göttinnen).

## Update: Fusion „Eklipsa“, Schwebehöhe, Schaden

- **Schwebehöhe:** Alle Bosse schweben nur noch 1–2 Blöcke über dem Boden.
- **Schaden (−15 %):** Zone 29, Haupt 46, Schwer 81. Ultimates bleiben bei 150 % Max-HP.
- **Fusion:** Sterben beide Göttinnen, werden sie wiederbelebt und verschmelzen zu **Eklipsa** (links hell = Solara, rechts dunkel = Lunara).
  - HP = Summe beider Max-HP, kurze Unverwundbarkeit nach der Verschmelzung.
  - Beide Hälften wirken unabhängig voneinander (ein Licht- und ein Dunkelzauber gleichzeitig), nie zwei Ultimates zugleich.
  - Finale: Zwillingsgestirn. Lunaspiegel und Duo-Zauber entfallen in der Fusion.
- **Befehl:** `/solunar fusion` beschwört Eklipsa direkt (zum Testen); `/solunar attack <name>` funktioniert auch bei ihr.

## Update: Cast-Zeiten
- Alle Zauber-Zeitleisten (Aufladen, Warnungen, Ablauf) laufen 50 % länger (`CAST_MULT = 1.5`). Projektile fliegen unverändert schnell, Abklingzeit zwischen Zaubern bleibt gleich.

## Update: Neue Modelle & Animationen
- Neue Modelle für Solara, Lunara, Eklipsa und den Dämonenlord (Stil nach Fallen Angel / Dread Sovereign Lich): Hörner, Flügel, Waffen, Umhang, Haare, Heiligenschein, kreisende Orbs.
- Animationen in `GoddessModel` / `DaemonenlordModel`: Idle-Schweben, Flügelschlag, Haar/Umhang/Rock-Nachschwingen, Gehen, Armposen je Zauber (Heben, Vorstoßen, Weit/Ultimate).
- Neu erzeugen: `python3 tools/gen/build.py` (numpy + Pillow). Bearbeitbare `.bbmodel`-Dateien liegen in `modelle/`.

## Update: Custom-Ausrüstung & Stats
Befehle (OP): `/gear give tank|glass|all|<item-id>`, `/gear stats` (eigene Werte), `/gear list`.

**Stats:** Stärke (**100 = Vanilla-Schaden**; Schaden = Vanilla × Stärke/100, gilt sobald ein Custom-Item getragen wird, sonst Vanilla) · Crit Chance (Cap 100 = immer Crit) · Crit Schaden (1 = +1 % Crit-Schaden, Schaden × Stärke/100 × (1+CritSchaden/100) bei Crit) · Defense (1 = −1 % erlittener Schaden, Cap 95) · Leben (Rüstung gibt Max-HP, 20 Herzen = 40 HP). Alle Teile sind unzerbrechlich (Netherite-Basis, feuerfest). Void/`/kill` ignoriert Defense.

| Set | Stärke | Crit | Crit-Schaden | Defense | Leben |
|---|---|---|---|---|---|
| **Ehrwürdiger Kriegspanzer** (4 Teile: 25 / 8 / 12 / 80, Set-Bonus +5 Stärke, +10 Defense) + **Midas' Richtspruch** (50 / 10 / 20) | 80 (= 0,8× Vanilla) | 18 | 32 | 90 | +10 Herzen |
| **Himmlischer Mantel** (4 Teile: 70 / 24 / 45 / 8, Set-Bonus +20 Stärke, +10 Crit, +15 Crit-Schaden) + **Bogenklinge des Zenits** (80 / 15 / 30) | 170 (= 1,7× Vanilla) | 49 | 90 | 8 | – |

- Tank-Set „Eidschwur“: unter 40 % Leben +25 Defense und Regeneration (10 s), Abklingzeit 30 s.
- Glas-Set „Sternensturm“: Crits springen als 50 %-Blitz auf bis zu 4 Monster in 5 Blöcken; ein Kill gibt 5 s lang +10 Stärke.
- Rüstung: Vanilla-Rüstungstextur (bewegt sich wie der Körper, im Inventar sichtbar); Umhang, Flügel und Heiligenschein sind 3D-Zubehör.
- Midas' Richtspruch (Rechtsklick, 8 s): goldene Schockwelle (Radius 6), Verlangsamung, heilt 10 % Leben.
- Bogenklinge (Rechtsklick, 6 s): Dash 8 Blöcke, Sichelschnitt trifft alles auf dem Weg.
- Jedes Item hat in der Beschreibung: Stats, Set-Bonus bzw. Fähigkeit und eine kurze Geschichte (kursiv).
- Die 3D-Rüstung zeichnet der Mod selbst (unsichtbare Vanilla-Rüstung + Träger-Entity); in der Ego-Perspektive wird sie ausgeblendet.
- Modelle/Texturen neu erzeugen: `python3 tools/gen/build.py` (`tools/gen/gear.py`); bearbeitbar: `modelle/ruestungen.bbmodel`.

## Party-System
Für alle Spieler (kein OP nötig): `/party create` · `/party invite <Spieler>` · `/party accept` · `/party decline` · `/party leave` · `/party kick <Spieler>` (Anführer) · `/party list` · `/party warp` (Anführer holt alle zu sich) · `/party boss <daemonenlord|solunar>` (Anführer, spawnt den Boss 12 Blöcke vor sich; Solara & Lunara skalieren mit der Spielerzahl in 80 Blöcken).
- **Tank:** Wer in der Party das volle Tank-Set (4/4) trägt, wird als **Tank** der Gruppe geführt (Meldung an alle, `/party list` zeigt `[Tank]`). Er fängt **30 %** des Schadens aller anderen Mitglieder ab (Reichweite 50 Blöcke, gleiche Dimension); der abgefangene Schaden läuft durch seine eigene Defense. Gibt es mehrere Tanks, zählt der erste in der Party-Reihenfolge.
- Kein Friendly Fire zwischen Party-Mitgliedern. Parties werden nicht gespeichert (Serverneustart = aufgelöst); Offline-Spieler verlassen die Party automatisch, der Anführer wechselt dann zum nächsten Mitglied.
