# Dämonenlord – „Das Jüngste Gericht der Asche“ (Fabric-Mod für Minecraft 26.2)

Endboss mit **eigenem Modell aus deiner Blockbench-Datei** (Körper, Flügel, Heiligenschein; Gold/Obsidian), Bossleiste, 3 Phasen,
8 normalen Attacken und dem Ultimate mit Blendeffekt.

## Bauen
Voraussetzung: **Java 25** (JDK) und Internet beim ersten Build.

```
./gradlew build          (Windows: gradlew.bat build)
```
Die fertige Mod liegt dann in `build/libs/daemonenlord-1.0.0.jar` (die Datei **ohne** `-sources`).
In den `mods`-Ordner legen, zusammen mit **Fabric Loader ≥ 0.20.1** und **Fabric API 0.161.0+26.2**.
Zum Testen in der IDE: `./gradlew runClient`.

## Befehle (Rechte: Gamemaster/OP)
| Befehl | Wirkung |
|---|---|
| `/daemonenlord spawn [x y z]` | Boss beschwören (Standard: an deiner Position) |
| `/daemonenlord kill` | Boss + Schattendiener entfernen |
| `/daemonenlord heal` | Boss voll heilen |
| `/daemonenlord phase <1-3>` | Lebenspunkte auf Phase setzen |
| `/daemonenlord attack <name>` | Attacke sofort erzwingen (Tab-Vervollständigung) |
| `/daemonenlord list` | Alle Attacken anzeigen |

## Attacken
| Name (Befehl) | Ab Phase | Idee |
|---|---|---|
| Höllenfeuer-Salve (`hoellenfeuer`) | 1 | Feuereinschläge mit Warnring, zielen auf deine Laufrichtung |
| Klingenhagel (`klingenhagel`) | 1 | Goldene Klingen fallen im Ring um dich, dann eine direkt auf dich |
| Seelenfeuer-Welle (`seelenwelle`) | 1 | Ring am Boden – **springen**! (Phase 3: drei Wellen) |
| Sternenfall (`sternenfall`) | 1 | Dauerregen aus Sternen im ganzen Raum |
| Schattenbeschwörung (`schatten`) | 1 | Wither-Skelette (Tag `dl_minion`) mit Resistenz/Speed |
| Dunkler Sog (`sog`) | 2 | Zieht alle ein, Explosion am Ende + Welle |
| Strahl des Urteils (`strahl`) | 2 | Warn-Linie, dann schwenkender Lichtstrahl |
| Himmelsbruch (`himmelsbruch`) | 2 | Boss steigt auf, stürzt auf deine Position, Schockwelle |
| **Das Jüngste Gericht der Asche** (`juengstes_gericht`) | bei 50 % und 15 % HP | Unverwundbar, 8 rotierende Lichtsäulen, Energie sammelt sich, **weißer Blendblitz**, drei riesige Wellen, Licht-Gericht auf jeden Spieler, danach 5 s erschöpft |

Schaden skaliert mit der Phase (+20 % pro Phase). Beute: Nether-Sterne, Netherit, verzauberte Goldäpfel, Totem u. a.
(`data/daemonenlord/loot_table/entities/daemonenlord.json`). Werte (HP 1500, Rüstung 14) in `DaemonenlordEntity.createAttributes()`.

## WICHTIG – ehrlicher Hinweis
Diese Mod wurde in einer Umgebung ohne Zugriff auf die Minecraft-/Gradle-Server geschrieben. Sie ist **nicht kompiliert und nicht
im Spiel getestet**; Syntax wurde geprüft, die API-Aufrufe stammen aus den offiziellen 26.x-Beispielen. Es kann deshalb beim ersten
`gradlew build` kleine Compile-Fehler geben (Methodennamen, die sich in 26.2 geändert haben). Alle riskanten Stellen sind gebündelt:
* `boss/Fx.java` – Partikel, Sounds, Schaden (per `/damage`), Titel/Blitz, Bossleiste (per Reflection)
* `boss/DaemonenlordEntity.java` – `die`, `startSeenByPlayer`, `remove`, `isPushable`, Save-Daten
* `client/DaemonenlordRenderer.java` – `state.lightCoords` (Vollhelligkeit)

Schick mir die Fehlermeldung einfach, dann passe ich genau die Zeile an.

## Modell
`src/client/resources/assets/daemonenlord/boss_model.json` + `textures/entity/daemonenlord.png` wurden per
`tools/gen_model.py` aus der Blockbench-Datei erzeugt (Skalierung 0,5; ca. 7 Blöcke hoch, Flügel ca. 8 Blöcke breit).
Der Blitz nutzt die Schrift `assets/daemonenlord/font/flash.json` (weißes Glyph als Vollbild-Titel).

## Auf GitHub hochladen (wichtig: Ordnerstruktur!)
ZIP entpacken und den **kompletten Inhalt inkl. Ordner** (`src`, `gradle`, `.github`, `build.gradle` …) hochladen – nicht einzelne Dateien.
Am einfachsten per Git: `git init && git add . && git commit -m "Mod" && git push`.
Danach baut GitHub automatisch (Reiter **Actions** → Lauf öffnen → unten **Artifacts → Daemonenlord-Mod**).
